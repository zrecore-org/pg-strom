/*
 * arrow_fdw.c
 *
 * Routines to map Apache Arrow files as PG's Foreign-Table.
 * ----
 * Copyright 2011-2026 (C) KaiGai Kohei <kaigai@kaigai.gr.jp>
 * Copyright 2014-2026 (C) PG-Strom Developers Team
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the PostgreSQL License.
 */
#include "pg_strom.h"
#include "arrow_fdw.h"
#include "xpu_numeric.h"

/*
 * min/max statistics datum
 */
#define MINMAX_STAT_BYTESZ	32
typedef struct
{
	bool		isnull;
	union {
		Datum	datum;
		NumericData	numeric;	/* if NUMERICOID */
		char	string[MINMAX_STAT_BYTESZ];		/* if TEXTOID */
	} min;
	union {
		Datum	datum;
		NumericData numeric;	/* if NUMERICOID */
		char	string[MINMAX_STAT_BYTESZ];		/* if TEXTOID */
	} max;
} MinMaxStatDatum;

/*
 * RecordBatchState
 */
typedef struct RecordBatchFieldState
{
	/* common fields with cache */
	char		attname[NAMEDATALEN];
	Oid			atttypid;
	int			atttypmod;
	ArrowTypeOptions attopts;
	int64		nitems;				/* usually, same with rb_nitems */
	int64		null_count;
	off_t		nullmap_offset;
	size_t		nullmap_length;
	off_t		values_offset;
	size_t		values_length;
	off_t		extra_offset;
	size_t		extra_length;
	size_t		disk_length;
	MinMaxStatDatum stat_datum;
	/* sub-fields if any */
	int			num_children;
	struct RecordBatchFieldState *children;
} RecordBatchFieldState;

typedef struct RecordBatchState
{
	struct ArrowFileState *af_state;	/* reference to ArrowFileState */
	int			rb_index;	/* index number in a file */
	off_t		rb_offset;	/* offset from the head */
	size_t		rb_length;	/* length of the entire RecordBatch */
	int64		rb_nitems;	/* number of items */
	/* virtual column per record-batch */
	int			virtual_nitems;
	Datum	   *virtual_values;
	bool	   *virtual_isnull;
	/* per column information */
	int			nfields;
	RecordBatchFieldState fields[FLEXIBLE_ARRAY_MEMBER];
} RecordBatchState;

typedef struct virtualColumnDef
{
	char		kind;
	char	   *key;
	char	   *value;
	char		buf[FLEXIBLE_ARRAY_MEMBER];
} virtualColumnDef;

/*
 * MEMO: virtual columns have special field-index on the ArrowFileState.
 * if __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE, virtual columns are immutable in this file,
 * and the value is stored in the ArrowFileState.
 * if a negative value less then __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE, virtual columns
 * are per-record-batch basis, and stored in the RecordBatchState. Its virtual_values[]
 * index can be calculated by __FIELD_INDEX_SPECIAL__VIRTUAL_PER_RECORD_BATCH.
 */
#define __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE				(-1)
#define __FIELD_INDEX_SPECIAL__VIRTUAL_PER_RECORD_BATCH(k)	(-(k)-2)

typedef struct ArrowFileState
{
	const char *filename;
	struct stat	stat_buf;
	gpumask_t	optimal_gpus;
	ArrowMetadataVersion version; /* used to determine whether Arrow or Parquet */
	int			parquet_cache; /* foreign-table option */
	List	   *rb_list;	/* list of RecordBatchState */
	uint32_t	ncols;
	struct {
		int		field_index;		/* PG-column <-> Arrow-field mapping */
		bool	virtual_isnull;		/* virtual isnull, if any */
		Datum	virtual_datum;		/* virtual datum, if any */
	} attrs[FLEXIBLE_ARRAY_MEMBER];
} ArrowFileState;

/*
 * ArrowFdwState - executor state to run apache arrow
 */
typedef struct
{
	Bitmapset	   *stat_attrs;
	Bitmapset	   *load_attrs;
	List		   *orig_quals;		/* for EXPLAIN */
	List		   *eval_quals;
	ExprState	   *eval_state;
	ExprContext	   *econtext;
} arrowStatsHint;

struct ArrowFdwState
{
	Bitmapset		   *referenced;		/* referenced columns */
	arrowStatsHint	   *stats_hint;		/* min/max statistics, if any */
	pg_atomic_uint32   *rbatch_index;
	pg_atomic_uint32	__rbatch_index_local;	/* if single process */
	pg_atomic_uint32   *rbatch_nload;
	pg_atomic_uint32	__rbatch_nload_local;	/* if single process */
	pg_atomic_uint32   *rbatch_nskip;
	pg_atomic_uint32	__rbatch_nskip_local;	/* if single process */
	pg_atomic_uint32   *nchunks_parquet_read;
	pg_atomic_uint32	__nchunks_parquet_read;	/* if single process */
	pg_atomic_uint32   *ncaches_parquet_load;
	pg_atomic_uint32	__ncaches_parquet_load;	/* if single process */
	LargeStringInfoData	chunk_buffer;	/* buffer to load record-batch */
	File				curr_filp;		/* current arrow file to read */
	kern_data_store	   *curr_kds;		/* current chunk to read */
	uint32_t			curr_index;		/* current index on the chunk */
	List			   *af_states_list;	/* list of ArrowFileState */
	uint32_t			rb_nitems;		/* number of record-batches */
	RecordBatchState   *rb_states[FLEXIBLE_ARRAY_MEMBER]; /* flatten RecordBatchState */
};

/*
 * Metadata Cache (on shared memory)
 */
typedef struct arrowMetadataCacheBlock	arrowMetadataCacheBlock;
typedef struct arrowMetadataCache		arrowMetadataCache;
typedef struct arrowMetadataFieldCache	arrowMetadataFieldCache;
typedef struct arrowMetadataKeyValueCache arrowMetadataKeyValueCache;

/*
 * arrowMetadataKeyValueCache
 */
struct arrowMetadataKeyValueCache
{
	arrowMetadataKeyValueCache *next;
	const char *key;
	const char *value;
	int			_key_len;
	int			_value_len;
	char		data[FLEXIBLE_ARRAY_MEMBER];
};

/*
 * arrowMetadataFieldCache - metadata for a particular field in record-batch
 */
struct arrowMetadataFieldCache
{
	dlist_node	chain;				/* link to free/fields[children] list */
	/* common fields with cache */
	char		attname[NAMEDATALEN];
	Oid			atttypid;
	int			atttypmod;
	ArrowTypeOptions attopts;
	int64		nitems;				/* usually, same with rb_nitems */
	int64		null_count;
	off_t		nullmap_offset;
	size_t		nullmap_length;
	off_t		values_offset;
	size_t		values_length;
	off_t		extra_offset;
	size_t		extra_length;
	size_t		disk_length;
	MinMaxStatDatum stat_datum;
	arrowMetadataKeyValueCache *custom_metadata;	/* valid only in RecordBatch-0 */
	/* sub-fields if any */
	int			num_children;
	dlist_head	children;
};

/*
 * arrowMetadataCache - metadata for a particular record-batch
 */
struct arrowMetadataCache
{
	arrowMetadataCache *next; /* next record-batch if any */
	int			rb_index;	/* index number in a file */
	off_t		rb_offset;	/* offset from the head */
	size_t		rb_length;	/* length of the entire RecordBatch */
	int64		rb_nitems;	/* number of items */
	/* per column information */
	int			nfields;
	dlist_head	fields;		/* list of arrowMetadataFieldCache */
};

/*
 * arrowMetadataCacheBlock - metadata for a particular arrow file, and
 *                           allocation unit
 */
#define ARROW_METADATA_BLOCKSZ		(128 * 1024)	/* 128kB */
typedef struct arrowMetadataCacheBlock
{
	arrowMetadataCacheBlock *next;
	uint32_t	usage;
	/* <---- the fields below are valid only the first block ----> */
	dlist_node	chain;		/* link to free/hash list */
	dlist_node	lru_chain;	/* link to lru_list */
	struct timeval lru_tv;	/* last access time */
	struct stat	stat_buf;	/* result of stat(2) */
	ArrowMetadataVersion version; /* used to determine whether Arrow or Parquet */
	arrowMetadataKeyValueCache *custom_metadata;
	arrowMetadataCache mcache_head;	/* the first arrowMetadataCache (record batch)
									 * in this file */
} arrowMetadataCacheBlock;

/*
 * Metadata cache management
 */
#define ARROW_METADATA_HASH_NSLOTS		2000
typedef struct
{
	LWLock		mutex;
	slock_t		lru_lock;		/* protect lru related stuff */
	dlist_head	lru_list;
	dlist_head	free_blocks;	/* list of arrowMetadataCacheBlock */
	dlist_head	hash_slots[ARROW_METADATA_HASH_NSLOTS];
	/* statistics */
	size_t		total_cache_usage;
	uint32_t	num_active_blocks;
	uint32_t	num_file_entries;
	struct timeval tm_last_allocate;
	struct timeval tm_last_reclaimed;
} arrowMetadataCacheHead;

/*
 * Static variables
 */
static FdwRoutine	pgstrom_arrow_fdw_routine;
static shmem_request_hook_type shmem_request_next = NULL;
static shmem_startup_hook_type shmem_startup_next = NULL;
static arrowMetadataCacheHead *arrow_metadata_cache = NULL;
static bool			arrow_fdw_enabled;	/* GUC */
static bool			arrow_fdw_stats_hint_enabled;	/* GUC */
int					arrow_metadata_cache_size_kb;	/* GUC */
static int			parquet_parallel_read_threshold;/* GUC */
static bool			default_parquet_cache_enabled;	/* GUC */

/* ----------------------------------------------------------------
 *
 * Apache Arrow <--> PG Types Mapping Routines
 *
 * ----------------------------------------------------------------
 */

/*
 * arrowFieldGetPGTypeHint
 */
static Oid
arrowFieldGetPGTypeHint(const ArrowField *field)
{
	for (int i=0; i < field->_num_custom_metadata; i++)
	{
		ArrowKeyValue *kv = &field->custom_metadata[i];
		Oid			extension_oid = InvalidOid;
		Oid			namespace_oid = InvalidOid;
		Oid			hint_oid;
		char	   *namebuf, *pos;

		/* pg_type = NAMESPACE.TYPENAME@EXTENSION */
		if (strcmp(kv->key, "pg_type") != 0)
			continue;
		namebuf = alloca(kv->_value_len + 10);
		strcpy(namebuf, kv->value);
		pos = strchr(namebuf, '.');
		if (pos)
		{
			*pos++ = '\0';
			namespace_oid = get_namespace_oid(namebuf, true);
			if (!OidIsValid(namespace_oid))
				continue;
			namebuf = pos;
		}
		pos = strchr(namebuf, '@');
		if (pos)
		{
			*pos++ = '\0';
			extension_oid = get_extension_oid(pos, true);
			if (!OidIsValid(extension_oid))
				continue;
		}

		if (OidIsValid(namespace_oid))
		{
			hint_oid = GetSysCacheOid2(TYPENAMENSP,
									   Anum_pg_type_oid,
									   CStringGetDatum(namebuf),
									   ObjectIdGetDatum(namespace_oid));
			if (OidIsValid(hint_oid))
			{
				if (!OidIsValid(extension_oid) ||
					getExtensionOfObject(TypeRelationId,
										 hint_oid) == extension_oid)
					return hint_oid;
			}
		}
		else
		{
			CatCList   *typelist;
			HeapTuple	htup;

			/* 1st try: 'pg_catalog' + typname */
			hint_oid = GetSysCacheOid2(TYPENAMENSP,
									   Anum_pg_type_oid,
									   CStringGetDatum(namebuf),
									   ObjectIdGetDatum(PG_CATALOG_NAMESPACE));
			if (OidIsValid(hint_oid))
			{
				if (!OidIsValid(extension_oid) ||
					getExtensionOfObject(TypeRelationId,
										 hint_oid) == extension_oid)
					return hint_oid;
			}
			/* 2nd try: any other namespaces */
			typelist = SearchSysCacheList1(TYPENAMENSP,
										   CStringGetDatum(namebuf));
			for (int k=0; k < typelist->n_members; k++)
			{
				htup = &typelist->members[k]->tuple;
				hint_oid = ((Form_pg_type) GETSTRUCT(htup))->oid;

				if (!OidIsValid(extension_oid) ||
					getExtensionOfObject(TypeRelationId,
										 hint_oid) == extension_oid)
				{
					ReleaseCatCacheList(typelist);
					return hint_oid;
				}
			}
			ReleaseCatCacheList(typelist);
		}
	}
	return InvalidOid;
}

/* ------------------------------------------------
 * Metadata Cache Management Routines
 *
 * MEMO: all of them requires the caller must have exclusive lock
 *       on the arrowMetadataCache::mutex
 * ------------------------------------------------
 */
static void
__releaseMetadataCacheBlock(arrowMetadataCacheBlock *mc_block_curr)
{
	while (mc_block_curr)
	{
		arrowMetadataCacheBlock *mc_block_next = mc_block_curr->next;

		/* must be already detached */
		Assert(!mc_block_curr->chain.prev &&
			   !mc_block_curr->chain.prev &&
			   !mc_block_curr->lru_chain.prev  &&
			   !mc_block_curr->lru_chain.next);
		/* update statistics */
		arrow_metadata_cache->total_cache_usage -= mc_block_curr->usage;
		arrow_metadata_cache->num_active_blocks--;
		/* back to the free list */
		dlist_push_head(&arrow_metadata_cache->free_blocks,
						&mc_block_curr->chain);
		mc_block_curr = mc_block_next;
	}
}

static bool
__reclaimMetadataCacheBlock(void)
{
	SpinLockAcquire(&arrow_metadata_cache->lru_lock);
	if (!dlist_is_empty(&arrow_metadata_cache->lru_list))
	{
		arrowMetadataCacheBlock *mc_block;
		dlist_node	   *dnode;
		struct timeval	curr_tv;
		int64_t			elapsed;

		gettimeofday(&curr_tv, NULL);
		dnode = dlist_tail_node(&arrow_metadata_cache->lru_list);
		mc_block = dlist_container(arrowMetadataCacheBlock, lru_chain, dnode);
		elapsed = ((curr_tv.tv_sec - mc_block->lru_tv.tv_sec) * 1000000 +
				   (curr_tv.tv_usec - mc_block->lru_tv.tv_usec));
		if (elapsed > 30000000UL)	/* > 30s */
		{
			dlist_delete(&mc_block->lru_chain);
			memset(&mc_block->lru_chain, 0, sizeof(dlist_node));
			SpinLockRelease(&arrow_metadata_cache->lru_lock);
			dlist_delete(&mc_block->chain);
			memset(&mc_block->chain, 0, sizeof(dlist_node));

			__releaseMetadataCacheBlock(mc_block);
			/* update statistics */
			arrow_metadata_cache->num_file_entries--;
			gettimeofday(&arrow_metadata_cache->tm_last_reclaimed, NULL);
			return true;
		}
	}
	SpinLockRelease(&arrow_metadata_cache->lru_lock);
	return false;
}

static arrowMetadataCacheBlock *
__allocMetadataCacheBlock(void)
{
	arrowMetadataCacheBlock *mc_block;
	dlist_node	   *dnode;

	if (dlist_is_empty(&arrow_metadata_cache->free_blocks))
	{
		if (!__reclaimMetadataCacheBlock())
			return NULL;
		Assert(!dlist_is_empty(&arrow_metadata_cache->free_blocks));
	}
	dnode = dlist_pop_head_node(&arrow_metadata_cache->free_blocks);
	mc_block = dlist_container(arrowMetadataCacheBlock, chain, dnode);
	memset(mc_block, 0, offsetof(arrowMetadataCacheBlock, chain));
	/* update statistics */
	arrow_metadata_cache->num_active_blocks++;
	gettimeofday(&arrow_metadata_cache->tm_last_allocate, NULL);
	return mc_block;
}

static void *
__allocMetadataCacheCommon(arrowMetadataCacheBlock **p_mc_block, size_t sz)
{
	arrowMetadataCacheBlock *mc_block = *p_mc_block;
	char	   *pos;

	sz = MAXALIGN(sz);
	if (mc_block->usage + sz > ARROW_METADATA_BLOCKSZ)
	{
		if (offsetof(arrowMetadataCacheBlock,
					 chain) + sz > ARROW_METADATA_BLOCKSZ)
			return NULL;	/* too large */
		mc_block = __allocMetadataCacheBlock();
		if (!mc_block)
			return NULL;
		mc_block->next = NULL;
		mc_block->usage = offsetof(arrowMetadataCacheBlock, chain);
		Assert(!(*p_mc_block)->next);
		(*p_mc_block)->next = mc_block;
		(*p_mc_block) = mc_block;
		/* update statistics */
		arrow_metadata_cache->total_cache_usage += mc_block->usage;
	}
	pos = ((char *)mc_block + mc_block->usage);
	mc_block->usage += sz;
	/* update statistics */
	arrow_metadata_cache->total_cache_usage += sz;

	return pos;
}

static arrowMetadataKeyValueCache *
__allocMetadataKeyValueCache(arrowMetadataCacheBlock **p_mc_block,
							 ArrowKeyValue *kv)
{
	arrowMetadataKeyValueCache *mc_kv;
	size_t		sz = (offsetof(arrowMetadataKeyValueCache,data)
					  + kv->_key_len + 1
					  + kv->_value_len + 1);
	mc_kv = __allocMetadataCacheCommon(p_mc_block, sz);
	if (mc_kv)
	{
		char   *pos = mc_kv->data;

		mc_kv->next = NULL;
		mc_kv->key = pos;
		mc_kv->_key_len = kv->_key_len;
		strncpy(pos, kv->key, kv->_key_len);
		pos[kv->_key_len] = '\0';
		pos += kv->_key_len + 1;

		mc_kv->value = pos;
		mc_kv->_value_len = kv->_value_len;
		strncpy(pos, kv->value, kv->_value_len);
		pos[kv->_value_len] = '\0';
   }
   return mc_kv;
}

static arrowMetadataFieldCache *
__allocMetadataFieldCache(arrowMetadataCacheBlock **p_mc_block)
{
	return (arrowMetadataFieldCache *)
		__allocMetadataCacheCommon(p_mc_block, sizeof(arrowMetadataFieldCache));
}

static arrowMetadataCache *
__allocMetadataCache(arrowMetadataCacheBlock **p_mc_block)
{
	return (arrowMetadataCache *)
		__allocMetadataCacheCommon(p_mc_block, sizeof(arrowMetadataCache));
}

/*
 * lookupArrowMetadataCache
 *
 * caller must hold "at least" shared lock on the arrow_metadata_cache->mutex.
 * if exclusive lock is held, it may invalidate legacy cache if any.
 */
static inline uint32_t
arrowMetadataHashIndex(struct stat *stat_buf)
{
	struct {
		dev_t	st_dev;
		ino_t	st_ino;
	} hkey;
	uint32_t	hash;

	hkey.st_dev = stat_buf->st_dev;
	hkey.st_ino = stat_buf->st_ino;
	hash = hash_bytes((unsigned char *)&hkey, sizeof(hkey));
	return hash % ARROW_METADATA_HASH_NSLOTS;
}

static arrowMetadataCacheBlock *
lookupArrowMetadataCache(struct stat *stat_buf, bool has_exclusive)
{
	uint32_t	hindex = arrowMetadataHashIndex(stat_buf);
	dlist_mutable_iter iter;

	dlist_foreach_modify(iter, &arrow_metadata_cache->hash_slots[hindex])
	{
		arrowMetadataCacheBlock *mc_block
			= dlist_container(arrowMetadataCacheBlock, chain, iter.cur);

		if (stat_buf->st_dev == mc_block->stat_buf.st_dev &&
			stat_buf->st_ino == mc_block->stat_buf.st_ino)
		{
			/*
			 * Is the metadata cache still valid?
			 */
			if (stat_buf->st_mtim.tv_sec < mc_block->stat_buf.st_mtim.tv_sec ||
				(stat_buf->st_mtim.tv_sec == mc_block->stat_buf.st_mtim.tv_sec &&
				 stat_buf->st_mtim.tv_nsec <= mc_block->stat_buf.st_mtim.tv_nsec))
			{
				/* ok, found */
				SpinLockAcquire(&arrow_metadata_cache->lru_lock);
				gettimeofday(&mc_block->lru_tv, NULL);
				dlist_move_head(&arrow_metadata_cache->lru_list,
								&mc_block->lru_chain);
				SpinLockRelease(&arrow_metadata_cache->lru_lock);
				return mc_block;
			}
			else if (has_exclusive)
			{
				/*
				 * Unfortunatelly, metadata cache is already invalid.
				 * If caller has exclusive lock, we release it.
				 */
				SpinLockAcquire(&arrow_metadata_cache->lru_lock);
				dlist_delete(&mc_block->lru_chain);
				memset(&mc_block->lru_chain, 0, sizeof(dlist_node));
				SpinLockRelease(&arrow_metadata_cache->lru_lock);
				dlist_delete(&mc_block->chain);
				memset(&mc_block->chain, 0, sizeof(dlist_node));

				__releaseMetadataCacheBlock(mc_block);
			}
		}
	}
	return NULL;
}

/* ----------------------------------------------------------------
 *
 * buildArrowStatsBinary
 *
 * ...and, routines related to Arrow Min/Max statistics
 *
 * (generated by 1st gen of the pg2arrow; will be deprecated in the future version)
 * ----------------------------------------------------------------
 */
typedef struct arrowFieldStatsBinary
{
	uint32	nrooms;		/* number of record-batches */
	MinMaxStatDatum *stat_values;
	int		nfields;	/* if List/Struct data type */
	struct arrowFieldStatsBinary *subfields;
} arrowFieldStatsBinary;

typedef struct
{
	int		nitems;		/* number of record-batches */
	int		nfields;	/* number of columns */
	arrowFieldStatsBinary fields[FLEXIBLE_ARRAY_MEMBER];
} arrowStatsBinary;

static void
__releaseArrowFieldStatsBinary(arrowFieldStatsBinary *bstats)
{
	if (bstats->subfields)
	{
		for (int j=0; j < bstats->nfields; j++)
			__releaseArrowFieldStatsBinary(&bstats->subfields[j]);
		pfree(bstats->subfields);
	}
	if (bstats->stat_values)
		pfree(bstats->stat_values);
}

static void
releaseArrowStatsBinary(arrowStatsBinary *arrow_bstats)
{
	if (arrow_bstats)
	{
		for (int j=0; j < arrow_bstats->nfields; j++)
			__releaseArrowFieldStatsBinary(&arrow_bstats->fields[j]);
		pfree(arrow_bstats);
	}
}

static int128_t
__atoi128(const char *tok, bool *p_isnull)
{
	int128_t	ival = 0;
	bool		is_minus = false;

	if (*tok == '-')
	{
		is_minus = true;
		tok++;
	}
	while (isdigit(*tok))
	{
		ival = 10 * ival + (*tok - '0');
		tok++;
	}

	if (*tok != '\0')
		*p_isnull = true;
	if (is_minus)
	{
		if (ival == 0)
			*p_isnull = true;
		ival = -ival;
	}
	return ival;
}

static bool
__parseArrowFieldStatsBinary(arrowFieldStatsBinary *bstats,
							 ArrowField *field,
							 const char *min_tokens,
							 const char *max_tokens)
{
	MinMaxStatDatum *stat_values;
	char	   *min_buffer;
	char	   *max_buffer;
	char	   *tok1, *pos1;
	char	   *tok2, *pos2;
	uint32_t	index;

	/* parse the min_tokens/max_tokens */
	min_buffer = alloca(strlen(min_tokens) + 1);
	max_buffer = alloca(strlen(max_tokens) + 1);
	strcpy(min_buffer, min_tokens);
	strcpy(max_buffer, max_tokens);

	stat_values = palloc0(sizeof(MinMaxStatDatum) * bstats->nrooms);
	for (tok1 = strtok_r(min_buffer, ",", &pos1),
		 tok2 = strtok_r(max_buffer, ",", &pos2), index = 0;
		 tok1 != NULL && tok2 != NULL && index < bstats->nrooms;
		 tok1 = strtok_r(NULL, ",", &pos1),
		 tok2 = strtok_r(NULL, ",", &pos2), index++)
	{
		bool		__isnull = false;
		int128_t	__min = __atoi128(__trim(tok1), &__isnull);
		int128_t	__max = __atoi128(__trim(tok2), &__isnull);
		int64_t		__drift;

		if (__isnull)
		{
			stat_values[index].isnull = true;
			continue;
		}

		switch (field->type.node.tag)
		{
			case ArrowNodeTag__Int:
			case ArrowNodeTag__FloatingPoint:
				stat_values[index].min.datum = (Datum)__min;
				stat_values[index].max.datum = (Datum)__max;
				break;

			case ArrowNodeTag__Decimal:
				__decimal_to_varlena((char *)&stat_values[index].min.numeric,
									 XPU_NUMERIC_KIND__VALID,
									 field->type.Decimal.scale,
									 __min);
				__decimal_to_varlena((char *)&stat_values[index].max.numeric,
									 XPU_NUMERIC_KIND__VALID,
									 field->type.Decimal.scale,
									 __max);
				break;

			case ArrowNodeTag__Date:
				switch (field->type.Date.unit)
				{
					case ArrowDateUnit__Day:
						stat_values[index].min.datum = __min
							- (POSTGRES_EPOCH_JDATE - UNIX_EPOCH_JDATE);
						stat_values[index].max.datum = __max
							- (POSTGRES_EPOCH_JDATE - UNIX_EPOCH_JDATE);
						break;
					case ArrowDateUnit__MilliSecond:
						stat_values[index].min.datum = __min / (SECS_PER_DAY * 1000)
							- (POSTGRES_EPOCH_JDATE - UNIX_EPOCH_JDATE);
						stat_values[index].max.datum = __max / (SECS_PER_DAY * 1000)
							- (POSTGRES_EPOCH_JDATE - UNIX_EPOCH_JDATE);
						break;
					default:
						goto bailout;
				}
				break;

			case ArrowNodeTag__Time:
				switch (field->type.Time.unit)
				{
					case ArrowTimeUnit__Second:
						stat_values[index].min.datum = __min * 1000000L;
						stat_values[index].max.datum = __max * 1000000L;
						break;
					case ArrowTimeUnit__MilliSecond:
						stat_values[index].min.datum = __min * 1000L;
						stat_values[index].max.datum = __max * 1000L;
						break;
					case ArrowTimeUnit__MicroSecond:
						stat_values[index].min.datum = __min;
						stat_values[index].max.datum = __max;
						break;
					case ArrowTimeUnit__NanoSecond:
						stat_values[index].min.datum = __min / 1000;
						stat_values[index].max.datum = __max / 1000;
						break;
					default:
						goto bailout;
				}
				break;

			case ArrowNodeTag__Timestamp:
				__drift = (POSTGRES_EPOCH_JDATE - UNIX_EPOCH_JDATE) * USECS_PER_DAY;
				switch (field->type.Timestamp.unit)
				{
					case ArrowTimeUnit__Second:
						stat_values[index].min.datum = __min * 1000000L - __drift;
						stat_values[index].max.datum = __max * 1000000L - __drift;
						break;
					case ArrowTimeUnit__MilliSecond:
						stat_values[index].min.datum = __min * 1000L - __drift;
						stat_values[index].max.datum = __max * 1000L - __drift;
						break;
					case ArrowTimeUnit__MicroSecond:
						stat_values[index].min.datum = __min - __drift;
						stat_values[index].max.datum = __max - __drift;
						break;
					case ArrowTimeUnit__NanoSecond:
						stat_values[index].min.datum = __min / 1000 - __drift;
						stat_values[index].max.datum = __max / 1000 - __drift;
						break;
					default:
						goto bailout;
				}
				break;
			default:
				goto bailout;
		}
	}
	/* sanity checks */
	if (!tok1 && !tok2 && index == bstats->nrooms)
	{
		bstats->stat_values = stat_values;
		return true;
	}
bailout:
	pfree(stat_values);
	return false;
}

static bool
__buildArrowFieldStatsBinary(arrowFieldStatsBinary *bstats,
							 ArrowField *field,
							 uint32 numRecordBatches)
{
	const char *min_tokens = NULL;
	const char *max_tokens = NULL;
	int			j, k;
	bool		retval = false;

	for (k=0; k < field->_num_custom_metadata; k++)
	{
		ArrowKeyValue *kv = &field->custom_metadata[k];

		if (strcmp(kv->key, "min_values") == 0)
			min_tokens = kv->value;
		else if (strcmp(kv->key, "max_values") == 0)
			max_tokens = kv->value;
	}

	bstats->nrooms = numRecordBatches;
	if (min_tokens && max_tokens)
	{
		if (__parseArrowFieldStatsBinary(bstats, field,
										 min_tokens,
										 max_tokens))
		{
			retval = true;
		}
	}

	if (field->_num_children > 0)
	{
		bstats->nfields = field->_num_children;
		bstats->subfields = palloc0(sizeof(arrowFieldStatsBinary) * bstats->nfields);
		for (j=0; j < bstats->nfields; j++)
		{
			if (__buildArrowFieldStatsBinary(&bstats->subfields[j],
											 &field->children[j],
											 numRecordBatches))
				retval = true;
		}
	}
	return retval;
}

static arrowStatsBinary *
buildArrowStatsBinary(const ArrowFooter *footer, Bitmapset **p_stat_attrs)
{
	arrowStatsBinary *arrow_bstats;
	int		nfields = footer->schema._num_fields;
	bool	found = false;

	arrow_bstats = palloc0(offsetof(arrowStatsBinary,
									fields[nfields]));
	arrow_bstats->nitems = footer->_num_recordBatches;
	arrow_bstats->nfields = nfields;
	for (int j=0; j < nfields; j++)
	{
		if (__buildArrowFieldStatsBinary(&arrow_bstats->fields[j],
										 &footer->schema.fields[j],
										 footer->_num_recordBatches))
		{
			if (p_stat_attrs)
				*p_stat_attrs = bms_add_member(*p_stat_attrs, j);
			found = true;
		}
	}
	if (!found)
	{
		releaseArrowStatsBinary(arrow_bstats);
		return NULL;
	}
	return arrow_bstats;
}

/*
 * applyArrowStatsBinary
 */
static void
__applyArrowFieldStatsBinary(RecordBatchFieldState *rb_field,
							 arrowFieldStatsBinary *bstats,
							 int rb_index)
{
	int		j;

	if (bstats->stat_values)
	{
		memcpy(&rb_field->stat_datum,
			   &bstats->stat_values[rb_index], sizeof(MinMaxStatDatum));
	}
	else
	{
		rb_field->stat_datum.isnull = true;
	}
	Assert(rb_field->num_children == bstats->nfields);
	for (j=0; j < rb_field->num_children; j++)
	{
		RecordBatchFieldState  *__rb_field = &rb_field->children[j];
		arrowFieldStatsBinary  *__bstats = &bstats->subfields[j];

		__applyArrowFieldStatsBinary(__rb_field, __bstats, rb_index);
	}
}

static void
applyArrowStatsBinary(RecordBatchState *rb_state, arrowStatsBinary *arrow_bstats)
{
	Assert(rb_state->nfields == arrow_bstats->nfields &&
		   rb_state->rb_index < arrow_bstats->nitems);
	for (int j=0; j < rb_state->nfields; j++)
	{
		__applyArrowFieldStatsBinary(&rb_state->fields[j],
									 &arrow_bstats->fields[j],
									 rb_state->rb_index);
	}
}

/* ----------------------------------------------------------------
 *
 * assignArrowStatsBinary
 *
 * It assigns per-record-batch min/max statistics generated by 2nd generation of
 * the pg2arrow. It embeds key-value pairs for each target fields.
 * In the future version, only this mechanism will be maintained.
 * ----------------------------------------------------------------
 */
static void
__assignArrowStatsBinaryOne(MinMaxStatDatum *stats,
							ArrowField *field,
							const char *__min_token,
							const char *__max_token)
{
	char   *end1, *end2;

	switch (field->type.node.tag)
	{
		case ArrowNodeTag__Int: {
			int64_t	__min = strtol(__min_token, &end1, 10);
			int64_t	__max = strtol(__max_token, &end2, 10);

			if (*end1 != '\0' && *end2 != '\0')
				stats->isnull = true;
			else
			{
				stats->isnull = false;
				stats->min.datum = Int64GetDatum(__min);
				stats->max.datum = Int64GetDatum(__max);
			}
			break;
		}
		case ArrowNodeTag__FloatingPoint: {
			double	__min = strtod(__min_token, &end1);
			double	__max = strtod(__max_token, &end2);

			if (*end1 != '\0' || *end2 != '\0')
				stats->isnull = true;
			else if (field->type.FloatingPoint.precision == ArrowPrecision__Half)
			{
				stats->isnull    = false;
				stats->min.datum = fp64_to_fp16(__min);
				stats->max.datum = fp64_to_fp16(__max);
			}
			else if (field->type.FloatingPoint.precision == ArrowPrecision__Single)
			{
				stats->isnull    = false;
				stats->min.datum = Float4GetDatum((float)__min);
				stats->max.datum = Float4GetDatum((float)__max);
			}
			else if (field->type.FloatingPoint.precision == ArrowPrecision__Double)
			{
				stats->isnull    = false;
				stats->min.datum = Float8GetDatum(__min);
				stats->max.datum = Float8GetDatum(__max);
			}
			else
			{
				stats->isnull = true;
			}
			break;
		}
		case ArrowNodeTag__Decimal:
			PG_TRY();
			{
				Datum	__min = DirectFunctionCall3(numeric_in,
													CStringGetDatum(__min_token),
													ObjectIdGetDatum(InvalidOid),
													Int32GetDatum(-1));
				Datum	__max = DirectFunctionCall3(numeric_in,
													CStringGetDatum(__max_token),
													ObjectIdGetDatum(InvalidOid),
													Int32GetDatum(-1));
				if (VARSIZE(DatumGetPointer(__min)) <= sizeof(NumericData) &&
					VARSIZE(DatumGetPointer(__max)) <= sizeof(NumericData))
				{
					stats->isnull = false;
					memcpy(&stats->min.numeric, DatumGetPointer(__min), VARSIZE(DatumGetPointer(__min)));
					memcpy(&stats->max.numeric, DatumGetPointer(__max), VARSIZE(DatumGetPointer(__max)));
				}
				else
				{
					stats->isnull = true;
				}
			}
			PG_CATCH();
			{
				FlushErrorState();
				stats->isnull = true;
			}
			PG_END_TRY();
			break;
		case ArrowNodeTag__Date: {
			int64_t	__min = strtol(__min_token, &end1, 10);
			int64_t	__max = strtol(__max_token, &end2, 10);

			if (*end1 != '\0' && *end2 != '\0')
				stats->isnull = true;
			else
			{
				int64_t		__drift = (POSTGRES_EPOCH_JDATE - UNIX_EPOCH_JDATE);

				switch (field->type.Date.unit)
				{
					case ArrowDateUnit__Day:
						stats->isnull = false;
						stats->min.datum = __min - __drift;
						stats->max.datum = __max - __drift;
						break;
					case ArrowDateUnit__MilliSecond:
						stats->isnull = false;
						stats->min.datum = __min / (SECS_PER_DAY * 1000) - __drift;
						stats->max.datum = __max / (SECS_PER_DAY * 1000) - __drift;
						break;
					default:
						stats->isnull = true;
						break;
				}
			}
			break;
		}
		case ArrowNodeTag__Time: {
			int64_t	__min = strtol(__min_token, &end1, 10);
			int64_t	__max = strtol(__max_token, &end2, 10);

			if (*end1 != '\0' && *end2 != '\0')
				stats->isnull = true;
			else
			{
				switch (field->type.Time.unit)
				{
					case ArrowTimeUnit__Second:
						stats->isnull = false;
						stats->min.datum = __min * 1000000L;
						stats->max.datum = __max * 1000000L;
                        break;
                    case ArrowTimeUnit__MilliSecond:
						stats->isnull = false;
						stats->min.datum = __min * 1000L;
						stats->max.datum = __max * 1000L;
                        break;
                    case ArrowTimeUnit__MicroSecond:
						stats->isnull = false;
						stats->min.datum = __min;
						stats->max.datum = __max;
                        break;
                    case ArrowTimeUnit__NanoSecond:
						stats->isnull = false;
						stats->min.datum = __min / 1000L;
						stats->max.datum = __max / 1000L;
						break;
					default:
						stats->isnull = true;
						break;
				}
			}
			break;
		}
		case ArrowNodeTag__Timestamp: {
			int64_t	__min = strtol(__min_token, &end1, 10);
			int64_t	__max = strtol(__max_token, &end2, 10);

			if (*end1 != '\0' && *end2 != '\0')
				stats->isnull = true;
			else
			{
				int64_t		__drift = (POSTGRES_EPOCH_JDATE -
									   UNIX_EPOCH_JDATE) * USECS_PER_DAY;
				switch (field->type.Timestamp.unit)
				{
					case ArrowTimeUnit__Second:
						stats->isnull = false;
						stats->min.datum = __min * 1000000L - __drift;
						stats->max.datum = __max * 1000000L - __drift;
						break;
					case ArrowTimeUnit__MilliSecond:
						stats->isnull = false;
						stats->min.datum = __min * 1000L - __drift;
						stats->max.datum = __max * 1000L - __drift;
						break;
					case ArrowTimeUnit__MicroSecond:
						stats->isnull = false;
						stats->min.datum = __min - __drift;
						stats->max.datum = __max - __drift;
						break;
					case ArrowTimeUnit__NanoSecond:
						stats->isnull = false;
						stats->min.datum = __min / 1000L - __drift;
						stats->max.datum = __max / 1000L - __drift;
						break;
					default:
						stats->isnull = true;
						break;
				}
			}
			break;
		}
		case ArrowNodeTag__Utf8:
		case ArrowNodeTag__LargeUtf8: {
			size_t	min_sz = strlen(__min_token);
			size_t	max_sz = strlen(__max_token);

			if (min_sz >= MINMAX_STAT_BYTESZ)
				min_sz = MINMAX_STAT_BYTESZ - 1;
			memcpy(stats->min.string+1, __min_token, min_sz);
			SET_VARSIZE_SHORT(stats->min.string, min_sz+1);
			if (max_sz >= MINMAX_STAT_BYTESZ)
				max_sz = MINMAX_STAT_BYTESZ - 1;
			memcpy(stats->max.string+1, __max_token, max_sz);
			SET_VARSIZE_SHORT(stats->max.string, max_sz+1);
			stats->isnull = false;
			break;
		}
		default:
			/* not supported */
			stats->isnull = true;
			break;
	}
}

static inline void
assignArrowStatsBinary(RecordBatchState *rb_state,
					   Bitmapset **p_stat_attrs,
					   ArrowSchema *schema,
					   int num_custom_metadata,
					   ArrowKeyValue *custom_metadata)
{
	char   *__min_token = NULL;
	char   *__max_token = NULL;
	size_t	bufsz = 0;

	for (int i=0; i < num_custom_metadata; i++)
	{
		ArrowKeyValue *kv = &custom_metadata[i];

		if (kv->key && kv->value && strncmp(kv->key, "min_max_stats.", 14) == 0)
		{
			const char *field_name = (kv->key + 14);

			for (int j=0; j < schema->_num_fields; j++)
			{
				RecordBatchFieldState *rb_field = &rb_state->fields[j];
				ArrowField	   *field = &schema->fields[j];

				if (strcmp(field_name, field->name) == 0)
				{
					size_t	len = strlen(kv->value);

					if (len >= bufsz)
					{
						bufsz = len * 2 + 100;
						__min_token = alloca(bufsz);
					}
					strcpy(__min_token, kv->value);
					__max_token = strchr(__min_token, ',');
					if (__max_token)
					{
						*__max_token++ = '\0';
						__assignArrowStatsBinaryOne(&rb_field->stat_datum,
													field,
													__min_token,
													__max_token);
						if (!rb_field->stat_datum.isnull)
							*p_stat_attrs = bms_add_member(*p_stat_attrs, j);
						break;
					}
				}
			}
		}
	}
}

/*
 * execInitArrowStatsHint / execCheckArrowStatsHint / execEndArrowStatsHint
 *
 * ... are executor routines for min/max statistics.
 */
static bool
__buildArrowStatsOper(arrowStatsHint *as_hint,
					  ScanState *ss,
					  OpExpr *op,
					  bool reverse)
{
	Scan	   *scan = (Scan *)ss->ps.plan;
	Oid			opcode;
	Var		   *var;
	Node	   *arg;
	Expr	   *expr;
	Oid			opfamily = InvalidOid;
	StrategyNumber strategy = InvalidStrategy;
	CatCList   *catlist;
	int			i, anum;

	/* quick bailout if not binary operator */
	if (list_length(op->args) != 2)
		return false;

	if (!reverse)
	{
		opcode = op->opno;
		var = linitial(op->args);
		arg = lsecond(op->args);
	}
	else
	{
		opcode = get_commutator(op->opno);
		var = lsecond(op->args);
		arg = linitial(op->args);
	}

	/*
	 * Is it VAR <OPER> ARG form?
	 *
	 * MEMO: expression nodes (like Var) might be rewritten to INDEX_VAR +
	 * resno on the custom_scan_tlist by setrefs.c, so we should reference
	 * Var::varnosyn and ::varattnosyn, instead of ::varno and ::varattno.
	 */
	if (!IsA(var, Var) || !OidIsValid(opcode))
		return false;
	if (var->varnosyn != scan->scanrelid)
		return false;
	anum = var->varattnosyn - FirstLowInvalidHeapAttributeNumber;
	if (!bms_is_member(anum, as_hint->stat_attrs))
		return false;
	if (contain_var_clause(arg) ||
		contain_volatile_functions(arg))
		return false;

	catlist = SearchSysCacheList1(AMOPOPID, ObjectIdGetDatum(opcode));
	for (i=0; i < catlist->n_members; i++)
	{
		HeapTuple	tuple = &catlist->members[i]->tuple;
		Form_pg_amop amop = (Form_pg_amop) GETSTRUCT(tuple);

		if (amop->amopmethod == BRIN_AM_OID)
		{
			opfamily = amop->amopfamily;
			strategy = amop->amopstrategy;
			break;
		}
	}
	ReleaseSysCacheList(catlist);

	if (strategy == BTLessStrategyNumber ||
		strategy == BTLessEqualStrategyNumber)
	{
		/* NOTE: min/max statistics of string data is not collation aware; it is
		 * generated based on simple byte comparison. Thus, it is not reliable to
		 * use as a hint for '<' or '<=' operator.
		 */
		if (var->vartype == TEXTOID)
			return false;

		/* if (VAR < ARG) --> (Min >= ARG), can be skipped */
		/* if (VAR <= ARG) --> (Min > ARG), can be skipped */
		opcode = get_negator(opcode);
		if (!OidIsValid(opcode))
			return false;
		expr = make_opclause(opcode,
							 op->opresulttype,
							 op->opretset,
							 (Expr *)makeVar(INNER_VAR,
											 var->varattno,
											 var->vartype,
											 var->vartypmod,
											 var->varcollid,
											 0),
							 (Expr *)copyObject(arg),
							 op->opcollid,
							 op->inputcollid);
		set_opfuncid((OpExpr *)expr);
		as_hint->eval_quals = lappend(as_hint->eval_quals, expr);
	}
	else if (strategy == BTGreaterEqualStrategyNumber ||
			 strategy == BTGreaterStrategyNumber)
	{
		/* NOTE: min/max statistics of string data is not collation aware; it is
		 * generated based on simple byte comparison. Thus, it is not reliable to
		 * use as a hint for '>' or '>=' operator.
		 */
		if (var->vartype == TEXTOID)
			return false;

		/* if (VAR > ARG) --> (Max <= ARG), can be skipped */
		/* if (VAR >= ARG) --> (Max < ARG), can be skipped */
		opcode = get_negator(opcode);
		if (!OidIsValid(opcode))
			return false;
		expr = make_opclause(opcode,
							 op->opresulttype,
							 op->opretset,
							 (Expr *)makeVar(OUTER_VAR,
											 var->varattno,
											 var->vartype,
											 var->vartypmod,
											 var->varcollid,
											 0),
							 (Expr *)copyObject(arg),
							 op->opcollid,
							 op->inputcollid);
		set_opfuncid((OpExpr *)expr);
		as_hint->eval_quals = lappend(as_hint->eval_quals, expr);
	}
	else if (strategy == BTEqualStrategyNumber)
	{
		/* (VAR = ARG) --> (Min > ARG) || (Max < ARG), can be skipped */
		opcode = get_opfamily_member(opfamily, var->vartype,
									 exprType((Node *)arg),
									 BTGreaterStrategyNumber);
		expr = make_opclause(opcode,
							 op->opresulttype,
							 op->opretset,
							 (Expr *)makeVar(INNER_VAR,
											 var->varattno,
											 var->vartype,
											 var->vartypmod,
											 var->varcollid,
											 0),
							 (Expr *)copyObject(arg),
							 C_COLLATION_OID,
							 C_COLLATION_OID);
		set_opfuncid((OpExpr *)expr);
		as_hint->eval_quals = lappend(as_hint->eval_quals, expr);

		opcode = get_opfamily_member(opfamily, var->vartype,
									 exprType((Node *)arg),
									 BTLessStrategyNumber);
		expr = make_opclause(opcode,
							 op->opresulttype,
							 op->opretset,
							 (Expr *)makeVar(OUTER_VAR,
											 var->varattno,
											 var->vartype,
											 var->vartypmod,
											 var->varcollid,
											 0),
							 (Expr *)copyObject(arg),
							 C_COLLATION_OID,
							 C_COLLATION_OID);
		set_opfuncid((OpExpr *)expr);
		as_hint->eval_quals = lappend(as_hint->eval_quals, expr);
	}
	else
	{
		return false;
	}
	as_hint->load_attrs = bms_add_member(as_hint->load_attrs, var->varattno);

	return true;
}

static bool
__buildArrowStatsBoolOp(arrowStatsHint *as_hint,
						ScanState *ss, Expr *expr)
{
	Scan   *scan = (Scan *)ss->ps.plan;

	if (IsA(expr, BoolExpr))
	{
		BoolExpr   *b = (BoolExpr *)expr;

		if (b->boolop == NOT_EXPR && list_length(b->args) == 1)
		{
			Var	   *var = (Var *)linitial(b->args);

			if (IsA(var, Var) &&
				var->vartype == BOOLOID &&
				var->varnosyn == scan->scanrelid)
			{
				/*
				 * WHERE NOT <BOOL_VAL>
				 *  --> If MIN_VALUE == true, no chance to match
				 */
				int		anum = var->varattnosyn - FirstLowInvalidHeapAttributeNumber;

				if (!bms_is_member(anum, as_hint->stat_attrs))
					return false;
				expr = (Expr *)makeVar(INNER_VAR,
									   var->varattno,
									   var->vartype,
									   var->vartypmod,
									   var->varcollid, 0);
				as_hint->eval_quals = lappend(as_hint->eval_quals, expr);
				as_hint->load_attrs = bms_add_member(as_hint->load_attrs, var->varattno);
				return true;
			}
		}
	}
	else if (IsA(expr, Var))
	{
		Var	   *var = (Var *)expr;

		if (IsA(var, Var) &&
			var->vartype == BOOLOID &&
			var->varnosyn == scan->scanrelid)
		{
			/*
			 * WHERE <BOOL_VAL>
			 *  --> If MAX_VALUE == false, no change to match
			 */
			int		anum = var->varattnosyn - FirstLowInvalidHeapAttributeNumber;

			if (!bms_is_member(anum, as_hint->stat_attrs))
				return false;
			expr = make_notclause((Expr *)makeVar(OUTER_VAR,
												  var->varattno,
												  var->vartype,
												  var->vartypmod,
												  var->varcollid, 0));
			as_hint->eval_quals = lappend(as_hint->eval_quals, expr);
			as_hint->load_attrs = bms_add_member(as_hint->load_attrs, var->varattno);
			return true;
		}
	}
	return false;
}

static bool
__buildArrowStatsScalarArrayOp(arrowStatsHint *as_hint,
							   ScanState *ss,
							   ScalarArrayOpExpr *sa_op)
{
	Oid			opcode = sa_op->opno;
	Var		   *var;
	Const	   *con;
	TypeCacheEntry *tcache;
	Oid			elem_oid;
	Datum		elem_datum;
	bool		elem_isnull;
	Datum		min_datum;
	Datum		max_datum;
	bool		has_minmax = false;
	StrategyNumber strategy = InvalidStrategy;
	ArrayType  *arr;
	ArrayIterator iter;
	CatCList   *catlist;
	int			anum;
	bool		retval = false;

	if (list_length(sa_op->args) != 2)
		return false;
	var = linitial(sa_op->args);
	con = lsecond(sa_op->args);

	/*
	 * Is it VAR <OPER> ARRAY form?
	 *
	 * MEMO: expression nodes (like Var) might be rewritten to INDEX_VAR +
	 * resno on the custom_scan_tlist by setrefs.c, so we should reference
	 * Var::varnosyn and ::varattnosyn, instead of ::varno and ::varattno.
	 */
	if (!OidIsValid(opcode) ||
		!sa_op->useOr ||	/* right now, only OPER ANY supported */
		!IsA(var, Var) ||
		!IsA(con, Const) ||
		con->constisnull)
		return false;
	/* min/max stats available? */
	anum = var->varattnosyn - FirstLowInvalidHeapAttributeNumber;
	if (!bms_is_member(anum, as_hint->stat_attrs))
		return false;
	/* pick up type cache */
	elem_oid = get_element_type(con->consttype);
	if (!OidIsValid(elem_oid))
		return false;
	tcache = lookup_type_cache(elem_oid, (TYPECACHE_LT_OPR |
										  TYPECACHE_GT_OPR |
										  TYPECACHE_CMP_PROC));
	if (!tcache || !OidIsValid(tcache->cmp_proc))
		return false;
	/*
	 * Identify the comparison strategy
	 */
	catlist = SearchSysCacheList1(AMOPOPID, ObjectIdGetDatum(sa_op->opno));
	for (int i=0; i < catlist->n_members; i++)
	{
		HeapTuple	tuple = &catlist->members[i]->tuple;
		Form_pg_amop amop = (Form_pg_amop) GETSTRUCT(tuple);

		if (amop->amopmethod == BRIN_AM_OID)
		{
			strategy = amop->amopstrategy;
			break;
		}
	}
	ReleaseSysCacheList(catlist);

	/*
	 * fetch min/max value from the const array arguments
	 */
	arr = DatumGetArrayTypeP(con->constvalue);
	iter = array_create_iterator(arr, 0, NULL);
	while (array_iterate(iter, &elem_datum, &elem_isnull))
	{
		if (elem_isnull)
			goto bailout;
		if (!has_minmax)
		{
			min_datum = elem_datum;
			max_datum = elem_datum;
			has_minmax = true;
		}
		else
		{
			Datum	status;

			status = OidFunctionCall2Coll(tcache->cmp_proc,
										  C_COLLATION_OID,
										  elem_datum,
										  min_datum);
			if (DatumGetInt32(status) < 0)
				min_datum = elem_datum;
			status = OidFunctionCall2Coll(tcache->cmp_proc,
										  C_COLLATION_OID,
										  elem_datum,
										  max_datum);
			if (DatumGetInt32(status) > 0)
				max_datum = elem_datum;
		}
	}
	/*
	 * build the result expression
	 */
	if (!has_minmax)
		goto bailout;
	if (strategy == BTLessStrategyNumber ||
		strategy == BTLessEqualStrategyNumber)
	{
		/*
		 * if (VAR <  ANY ARRAY) --> (Vmin >= Cmax), can be skipped
		 * if (VAR <= ANY ARRAY) --> (Vmin >  Cmax), can be skipped
		 */
		Oid		negator = get_negator(opcode);
		Expr   *expr;

		if (!OidIsValid(negator))
			goto bailout;
		expr = make_opclause(negator,
							 get_op_rettype(negator),
							 false,
							 (Expr *)makeVar(INNER_VAR,
											 var->varattno,
											 var->vartype,
											 var->vartypmod,
											 var->varcollid,
											 0),
							 (Expr *)makeConst(elem_oid,
											   -1,
											   C_COLLATION_OID,
											   tcache->typlen,
											   min_datum,
											   false,
											   tcache->typbyval),
							 C_COLLATION_OID,
							 C_COLLATION_OID);
		set_opfuncid((OpExpr *)expr);
		as_hint->eval_quals = lappend(as_hint->eval_quals, expr);
	}
	else if (strategy == BTGreaterEqualStrategyNumber ||
			 strategy == BTGreaterStrategyNumber)
	{
		/*
		 * if (VAR >  ANY ARRAY) --> (Vmax <= Cmin), can be skipped
		 * if (VAR >= ANY ARRAY) --> (Vmax <  Cmin), can be skipped
		 */
		Oid		negator = get_negator(opcode);
		Expr   *expr;

		if (!OidIsValid(negator))
			goto bailout;
		expr = make_opclause(negator,
							 get_op_rettype(negator),
							 false,
							 (Expr *)makeVar(OUTER_VAR,
											 var->varattno,
											 var->vartype,
											 var->vartypmod,
											 var->varcollid,
											 0),
							 (Expr *)makeConst(elem_oid,
											   -1,
											   C_COLLATION_OID,
											   tcache->typlen,
											   max_datum,
											   false,
											   tcache->typbyval),
							 C_COLLATION_OID,
							 C_COLLATION_OID);
		set_opfuncid((OpExpr *)expr);
		as_hint->eval_quals = lappend(as_hint->eval_quals, expr);
	}
	else if (strategy == BTEqualStrategyNumber)
	{
		/*
		 * if (VAR = ANY ARRAY) --> (Vmax < Cmin || Vmin > Cmax), can be skipped
		 */
		Expr   *expr;

		/* Vmax < Cmin */
		expr = make_opclause(tcache->lt_opr,
							 get_op_rettype(tcache->lt_opr),
							 false,
							 (Expr *)makeVar(OUTER_VAR,
											 var->varattno,
											 var->vartype,
											 var->vartypmod,
											 var->varcollid,
											 0),
							 (Expr *)makeConst(elem_oid,
											   -1,
											   var->varcollid,
											   tcache->typlen,
											   min_datum,
											   false,
											   tcache->typbyval),
							 C_COLLATION_OID,
							 C_COLLATION_OID);
		set_opfuncid((OpExpr *)expr);
		as_hint->eval_quals = lappend(as_hint->eval_quals, expr);
		/* Vmin > Cmax */
		expr = make_opclause(tcache->gt_opr,
							 get_op_rettype(tcache->gt_opr),
							 false,
							 (Expr *)makeVar(INNER_VAR,
											 var->varattno,
											 var->vartype,
											 var->vartypmod,
											 var->varcollid,
											 0),
							 (Expr *)makeConst(elem_oid,
											   -1,
											   var->varcollid,
											   tcache->typlen,
											   max_datum,
											   false,
											   tcache->typbyval),
							 C_COLLATION_OID,
							 C_COLLATION_OID);
		set_opfuncid((OpExpr *)expr);
		as_hint->eval_quals = lappend(as_hint->eval_quals, expr);
	}
	else
	{
		goto bailout;
	}
	as_hint->load_attrs = bms_add_member(as_hint->load_attrs, var->varattno);
	retval = true;
bailout:
	array_free_iterator(iter);

	return retval;
}

static arrowStatsHint *
execInitArrowStatsHint(ScanState *ss, List *outer_quals, Bitmapset *stat_attrs)
{
	Relation		relation = ss->ss_currentRelation;
	TupleDesc		tupdesc = RelationGetDescr(relation);
	arrowStatsHint *as_hint;
	ExprContext	   *econtext;
	Expr		   *eval_expr;
	ListCell	   *lc;

	outer_quals = fixup_scanstate_quals(ss, outer_quals);
	as_hint = palloc0(sizeof(arrowStatsHint));
	as_hint->stat_attrs = stat_attrs;
	foreach (lc, outer_quals)
	{
		Expr   *expr = lfirst(lc);

		if (IsA(expr, OpExpr) &&
			(__buildArrowStatsOper(as_hint, ss, (OpExpr *)expr, false) ||
			 __buildArrowStatsOper(as_hint, ss, (OpExpr *)expr, true)))
		{
			as_hint->orig_quals = lappend(as_hint->orig_quals, expr);
		}
		else if (IsA(expr, ScalarArrayOpExpr) &&
				 __buildArrowStatsScalarArrayOp(as_hint, ss,
												(ScalarArrayOpExpr *)expr))
		{
			as_hint->orig_quals = lappend(as_hint->orig_quals, expr);
		}
		else if (__buildArrowStatsBoolOp(as_hint, ss, expr))
		{
			as_hint->orig_quals = lappend(as_hint->orig_quals, expr);
		}
	}
	if (as_hint->eval_quals == NIL)
		return NULL;
	if (list_length(as_hint->eval_quals) == 1)
		eval_expr = linitial(as_hint->eval_quals);
	else
		eval_expr = make_orclause(as_hint->eval_quals);

	econtext = CreateExprContext(ss->ps.state);
	econtext->ecxt_innertuple = MakeSingleTupleTableSlot(tupdesc, &TTSOpsVirtual);
	econtext->ecxt_outertuple = MakeSingleTupleTableSlot(tupdesc, &TTSOpsVirtual);

	as_hint->eval_state = ExecInitExpr(eval_expr, &ss->ps);
	as_hint->econtext = econtext;

	return as_hint;
}

static bool
execCheckArrowStatsHint(arrowStatsHint *stats_hint,
						RecordBatchState *rb_state)
{
	ArrowFileState *af_state = rb_state->af_state;
	ExprContext	   *econtext = stats_hint->econtext;
	TupleTableSlot *min_values = econtext->ecxt_innertuple;
	TupleTableSlot *max_values = econtext->ecxt_outertuple;
	int				anum;
	Datum			datum;
	bool			isnull;

	/* load the min/max statistics */
	ExecStoreAllNullTuple(min_values);
	ExecStoreAllNullTuple(max_values);
	for (anum = bms_next_member(stats_hint->load_attrs, -1);
		 anum >= 0;
		 anum = bms_next_member(stats_hint->load_attrs, anum))
	{
		int		field_index;

		Assert(anum > 0 && anum <= af_state->ncols);
		field_index = af_state->attrs[anum-1].field_index;
		if (field_index >= 0)
		{
			RecordBatchFieldState *rb_field = &rb_state->fields[field_index];

			Assert(field_index < rb_state->nfields);
			if (rb_field->stat_datum.isnull)
				return false;	/* unable to determine */
			min_values->tts_isnull[anum-1] = false;
			max_values->tts_isnull[anum-1] = false;
			if (rb_field->atttypid == NUMERICOID)
			{
				min_values->tts_values[anum-1]
					= PointerGetDatum(&rb_field->stat_datum.min.numeric);
				max_values->tts_values[anum-1]
					= PointerGetDatum(&rb_field->stat_datum.max.numeric);
			}
			else if (rb_field->atttypid == TEXTOID)
			{
				min_values->tts_values[anum-1]
					= PointerGetDatum(rb_field->stat_datum.min.string);
				max_values->tts_values[anum-1]
					= PointerGetDatum(rb_field->stat_datum.max.string);
			}
			else
			{
				min_values->tts_values[anum-1] = rb_field->stat_datum.min.datum;
				max_values->tts_values[anum-1] = rb_field->stat_datum.max.datum;
			}
		}
		else if (field_index == __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE)
		{
			bool	virtual_isnull = af_state->attrs[anum-1].virtual_isnull;
			Datum	virtual_datum  = af_state->attrs[anum-1].virtual_datum;

			if (virtual_isnull)
				return false;	/* unable to determine */
			min_values->tts_isnull[anum-1] = virtual_isnull;
			max_values->tts_isnull[anum-1] = virtual_isnull;
			min_values->tts_values[anum-1] = virtual_datum;
			max_values->tts_values[anum-1] = virtual_datum;
		}
		else if (field_index < __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE)
		{
			int		k = __FIELD_INDEX_SPECIAL__VIRTUAL_PER_RECORD_BATCH(field_index);
			if (k < rb_state->virtual_nitems)
			{
				bool	virtual_isnull = rb_state->virtual_isnull[k];
				Datum	virtual_datum  = rb_state->virtual_values[k];

				if (virtual_isnull)
					return false;	/* unable to determine */
				min_values->tts_isnull[anum-1] = virtual_isnull;
				max_values->tts_isnull[anum-1] = virtual_isnull;
				min_values->tts_values[anum-1] = virtual_datum;
				max_values->tts_values[anum-1] = virtual_datum;
			}
			else
			{
				elog(ERROR, "Bug? unexpected virtual-field-index (%d)", field_index);
			}
		}
		else
		{
			elog(ERROR, "Bug? unexpected field-index (%d)", field_index);
		}
	}
	datum = ExecEvalExprSwitchContext(stats_hint->eval_state, econtext, &isnull);
//	elog(INFO, "file [%s] rb_index=%u datum=%lu isnull=%d",
//		 FilePathName(rb_state->fdesc), rb_state->rb_index, datum, (int)isnull);
	if (!isnull && DatumGetBool(datum))
		return true;	/* ok, skip this record-batch */
	return false;
}

static void
execEndArrowStatsHint(arrowStatsHint *stats_hint)
{
	ExprContext	   *econtext = stats_hint->econtext;

	ExecDropSingleTupleTableSlot(econtext->ecxt_innertuple);
	ExecDropSingleTupleTableSlot(econtext->ecxt_outertuple);
	econtext->ecxt_innertuple = NULL;
	econtext->ecxt_outertuple = NULL;

	FreeExprContext(econtext, true);
}


/* ----------------------------------------------------------------
 *
 * BuildArrowFileState
 *
 * It build RecordBatchState based on the metadata-cache, or raw Arrow files.
 * ----------------------------------------------------------------
 */
static void
__buildRecordBatchFieldStateByCache(RecordBatchFieldState *rb_field,
									arrowMetadataFieldCache *fcache)
{
	strcpy(rb_field->attname, fcache->attname);
	rb_field->atttypid       = fcache->atttypid;
	rb_field->atttypmod      = fcache->atttypmod;
	rb_field->attopts        = fcache->attopts;
	rb_field->nitems         = fcache->nitems;
	rb_field->null_count     = fcache->null_count;
	rb_field->nullmap_offset = fcache->nullmap_offset;
	rb_field->nullmap_length = fcache->nullmap_length;
	rb_field->values_offset  = fcache->values_offset;
	rb_field->values_length  = fcache->values_length;
	rb_field->extra_offset   = fcache->extra_offset;
	rb_field->extra_length   = fcache->extra_length;
	rb_field->disk_length    = fcache->disk_length;
	memcpy(&rb_field->stat_datum,
		   &fcache->stat_datum, sizeof(MinMaxStatDatum));
	if (fcache->num_children > 0)
	{
		dlist_iter	iter;
		int			j = 0;

		rb_field->num_children = fcache->num_children;
		rb_field->children = palloc0(sizeof(RecordBatchFieldState) *
									 fcache->num_children);
		dlist_foreach(iter, &fcache->children)
		{
			arrowMetadataFieldCache *__fcache
				= dlist_container(arrowMetadataFieldCache, chain, iter.cur);
			__buildRecordBatchFieldStateByCache(&rb_field->children[j++], __fcache);
		}
		Assert(j == rb_field->num_children);
	}
	else
	{
		Assert(dlist_is_empty(&fcache->children));
	}
}

static bool
__setupArrowFileStateByCache(ArrowFileState *af_state,
							 const char *filename,
							 arrowMetadataCacheBlock *mc_block,
							 Bitmapset **p_stat_attrs)
{
	arrowMetadataCache *mcache = &mc_block->mcache_head;

	/* restore the ArrowMetadataVersion (may be Parquet file) */
	af_state->version = mc_block->version;
	while (mcache)
	{
		RecordBatchState *rb_state;
		dlist_iter	iter;
		int			j = 0;

		rb_state = palloc0(offsetof(RecordBatchState,
									fields[mcache->nfields]));
		rb_state->af_state  = af_state;
		rb_state->rb_index  = mcache->rb_index;
		rb_state->rb_offset = mcache->rb_offset;
		rb_state->rb_length = mcache->rb_length;
		rb_state->rb_nitems = mcache->rb_nitems;
		rb_state->nfields   = mcache->nfields;
		dlist_foreach(iter, &mcache->fields)
		{
			arrowMetadataFieldCache *fcache;

			fcache = dlist_container(arrowMetadataFieldCache, chain, iter.cur);
			if (p_stat_attrs && !fcache->stat_datum.isnull)
				*p_stat_attrs = bms_add_member(*p_stat_attrs, j);
			__buildRecordBatchFieldStateByCache(&rb_state->fields[j++], fcache);
		}
		Assert(j == rb_state->nfields);
		af_state->rb_list = lappend(af_state->rb_list, rb_state);

		mcache = mcache->next;
	}
	return true;
}

/*
 * Routines to setup RecordBatchState by raw-file
 */
typedef struct
{
	ArrowMetadataVersion version;
	ArrowBuffer	   *buffer_curr;
	ArrowBuffer	   *buffer_tail;
	ArrowFieldNode *fnode_curr;
	ArrowFieldNode *fnode_tail;
} setupRecordBatchContext;

static Oid
__lookupCompositePGType(int nattrs, Oid *type_oids, Oid hint_oid)
{
	Relation	rel;
	ScanKeyData	skeys[3];
	SysScanDesc	sscan;
	Oid			comp_oid = InvalidOid;

	rel = table_open(RelationRelationId, AccessShareLock);
	ScanKeyInit(&skeys[0],
				Anum_pg_class_relkind,
				BTEqualStrategyNumber, F_CHAREQ,
				CharGetDatum(RELKIND_COMPOSITE_TYPE));
	ScanKeyInit(&skeys[1],
				Anum_pg_class_relnatts,
				BTEqualStrategyNumber, F_INT2EQ,
				Int16GetDatum(nattrs));
	ScanKeyInit(&skeys[2],
				Anum_pg_class_oid,
				BTEqualStrategyNumber, F_OIDNE,
				ObjectIdGetDatum(hint_oid));
	sscan = systable_beginscan(rel, InvalidOid, false, NULL,
							   OidIsValid(hint_oid) ? 3 : 2, skeys);
	for (;;)
	{
		HeapTuple	htup;
		TupleDesc	tupdesc;
		int			j;

		if (OidIsValid(hint_oid))
		{
			comp_oid = hint_oid;
			hint_oid = InvalidOid;
		}
		else
		{
			htup = systable_getnext(sscan);
			if (!HeapTupleIsValid(htup))
				break;
			comp_oid = ((Form_pg_class) GETSTRUCT(htup))->reltype;
		}

		if (pg_type_aclcheck(comp_oid,
							 GetUserId(),
							 ACL_USAGE) != ACLCHECK_OK)
			continue;

		tupdesc = lookup_rowtype_tupdesc_noerror(comp_oid, -1, true);
		if (!tupdesc)
			continue;
		if (tupdesc->natts == nattrs)
		{
			for (j=0; j < tupdesc->natts; j++)
			{
				Form_pg_attribute attr = TupleDescAttr(tupdesc, j);

				if (attr->atttypid != type_oids[j])
					break;
			}
			if (j == tupdesc->natts)
			{
				ReleaseTupleDesc(tupdesc);
				goto found;
			}
		}
		ReleaseTupleDesc(tupdesc);
	}
	comp_oid = InvalidOid;	/* not found */
found:
	systable_endscan(sscan);
	table_close(rel, AccessShareLock);

	return comp_oid;
}

static void
__arrowFieldTypeToPGType(const ArrowField *field,
						 Oid *p_type_oid,
						 int32_t *p_type_mod,
						 ArrowTypeOptions *p_attopts)
{
	const ArrowType *t = &field->type;
	Oid			type_oid = InvalidOid;
	int32_t		type_mod = -1;
	Oid			hint_oid = arrowFieldGetPGTypeHint(field);
	ArrowTypeOptions attopts;

	memset(&attopts, 0, sizeof(ArrowTypeOptions));
	attopts.align = MAXIMUM_ALIGNOF;	/* some data types expand the alignment */
	switch (t->node.tag)
	{
		case ArrowNodeTag__Int:
			attopts.tag = ArrowType__Int;
			switch (t->Int.bitWidth)
			{
				case 8:
					attopts.unitsz = sizeof(int8_t);
					type_oid = get_int1_type_oid(false);
					break;
				case 16:
					attopts.unitsz = sizeof(int16_t);
					type_oid = INT2OID;
					break;
				case 32:
					attopts.unitsz = sizeof(int32_t);
					type_oid = INT4OID;
					break;
				case 64:
					attopts.unitsz = sizeof(int64_t);
					type_oid = INT8OID;
					break;
				default:
					elog(ERROR, "Arrow::Int bitWidth=%d is not supported",
						 t->Int.bitWidth);
			}
			attopts.integer.bitWidth  = t->Int.bitWidth;
			attopts.integer.is_signed = t->Int.is_signed;
			break;

		case ArrowNodeTag__FloatingPoint:
			attopts.tag = ArrowType__FloatingPoint;
			switch (t->FloatingPoint.precision)
			{
				case ArrowPrecision__Half:
					attopts.unitsz = sizeof(float2_t);
					type_oid = get_float2_type_oid(false);
					break;
				case ArrowPrecision__Single:
					attopts.unitsz = sizeof(float4_t);
					type_oid = FLOAT4OID;
					break;
				case ArrowPrecision__Double:
					attopts.unitsz = sizeof(float8_t);
					type_oid = FLOAT8OID;
					break;
				default:
					elog(ERROR, "Arrow::FloatingPoint unknown precision (%d)",
						 (int)t->FloatingPoint.precision);
			}
			attopts.floating_point.precision = t->FloatingPoint.precision;
			break;

		case ArrowNodeTag__Bool:
			attopts.tag = ArrowType__Bool;
			attopts.unitsz = -1;		/* values is bitmap */
			type_oid = BOOLOID;
			break;

		case ArrowNodeTag__Decimal:
			if (t->Decimal.bitWidth != 128)
				elog(ERROR, "Arrow::Decimal%u is not supported", t->Decimal.bitWidth);
			attopts.tag               = ArrowType__Decimal;
			attopts.unitsz            = sizeof(int128_t);
			attopts.align             = sizeof(int128_t);
			attopts.decimal.precision = t->Decimal.precision;
			attopts.decimal.scale     = t->Decimal.scale;
			attopts.decimal.bitWidth  = t->Decimal.bitWidth;
			type_oid = NUMERICOID;
			break;

		case ArrowNodeTag__Date:
			attopts.tag = ArrowType__Date;
			switch (t->Date.unit)
			{
				case ArrowDateUnit__Day:
					attopts.unitsz = sizeof(int32_t);
					break;
				case ArrowDateUnit__MilliSecond:
					attopts.unitsz = sizeof(int32_t);
					break;
				default:
					elog(ERROR, "Arrow::Date unknown unit (%d)",
						 (int)t->Date.unit);
			}
			attopts.date.unit = t->Date.unit;
			type_oid = DATEOID;
			break;

		case ArrowNodeTag__Time:
			attopts.tag = ArrowType__Time;
			switch (t->Time.unit)
			{
				case ArrowTimeUnit__Second:
				case ArrowTimeUnit__MilliSecond:
					attopts.unitsz = sizeof(int32_t);
					break;
				case ArrowTimeUnit__MicroSecond:
				case ArrowTimeUnit__NanoSecond:
					attopts.unitsz = sizeof(int64_t);
					break;
				default:
					elog(ERROR, "unknown Time::unit (%d)",
						 (int)t->Time.unit);
			}
			attopts.time.unit = t->Time.unit;
			type_oid = TIMEOID;
			break;

		case ArrowNodeTag__Timestamp:
			attopts.tag = ArrowType__Timestamp;
			switch (t->Timestamp.unit)
			{
				case ArrowTimeUnit__Second:
				case ArrowTimeUnit__MilliSecond:
				case ArrowTimeUnit__MicroSecond:
				case ArrowTimeUnit__NanoSecond:
					attopts.unitsz = sizeof(int64_t);
					break;
				default:
					elog(ERROR, "unknown Timestamp::unit (%d)",
						 (int)t->Timestamp.unit);
			}
			attopts.timestamp.unit = t->Timestamp.unit;
			type_oid = (t->Timestamp.timezone
						? TIMESTAMPTZOID
						: TIMESTAMPOID);
			break;

		case ArrowNodeTag__Interval:
			attopts.tag = ArrowType__Interval;
			switch (t->Interval.unit)
			{
				case ArrowIntervalUnit__Year_Month:
					attopts.unitsz = sizeof(int32_t);
					break;
				case ArrowIntervalUnit__Day_Time:
					attopts.unitsz = sizeof(int64_t);
					break;
				default:
					elog(ERROR, "unknown Interval::unit (%d)",
                         (int)t->Interval.unit);
			}
			attopts.interval.unit = t->Interval.unit;
			type_oid = INTERVALOID;
			break;

		case ArrowNodeTag__FixedSizeBinary:
			attopts.tag = ArrowType__FixedSizeBinary;
			attopts.unitsz = t->FixedSizeBinary.byteWidth;
			attopts.fixed_size_binary.byteWidth = t->FixedSizeBinary.byteWidth;
			if (t->FixedSizeBinary.byteWidth <= 0 ||
				t->FixedSizeBinary.byteWidth > BLCKSZ)
				elog(ERROR, "arrow_fdw: %s with byteWidth=%d is not supported", 
					 t->node.tagName,
					 t->FixedSizeBinary.byteWidth);
			if (hint_oid == MACADDROID &&
				t->FixedSizeBinary.byteWidth == 6)
			{
				type_oid = MACADDROID;
			}
			else if (hint_oid == INETOID &&
					 (t->FixedSizeBinary.byteWidth == 4 ||
                      t->FixedSizeBinary.byteWidth == 16))
			{
				type_oid = INETOID;
			}
			else
			{
				type_oid = BPCHAROID;
				type_mod = VARHDRSZ + t->FixedSizeBinary.byteWidth;
			}
			break;

		case ArrowNodeTag__Utf8:
			attopts.tag = ArrowType__Utf8;
			attopts.unitsz = sizeof(uint32_t);
			type_oid = TEXTOID;
			break;

		case ArrowNodeTag__LargeUtf8:
			attopts.tag = ArrowType__LargeUtf8;
			attopts.unitsz = sizeof(uint64_t);
			type_oid = TEXTOID;
			break;

		case ArrowNodeTag__Binary:
			attopts.tag = ArrowType__Binary;
			attopts.unitsz = sizeof(uint32_t);
			if (OidIsValid(hint_oid) &&
				hint_oid == get_cube_type_oid(true))
				type_oid = hint_oid;
			else
				type_oid = BYTEAOID;
			break;

		case ArrowNodeTag__LargeBinary:
			attopts.tag = ArrowType__LargeBinary;
			attopts.unitsz = sizeof(uint64_t);
			if (OidIsValid(hint_oid) &&
				hint_oid == get_cube_type_oid(true))
				type_oid = hint_oid;
			else
				type_oid = BYTEAOID;
			break;

		case ArrowNodeTag__List:
		case ArrowNodeTag__LargeList:
			if (field->_num_children != 1)
				elog(ERROR, "Bug? List of arrow type is corrupted");
			else
			{
				Oid			__type_oid = InvalidOid;

				attopts.tag = ArrowType__List;
				attopts.unitsz = (t->node.tag == ArrowNodeTag__List
								  ? sizeof(uint32_t)
								  : sizeof(uint64_t));
				__arrowFieldTypeToPGType(&field->children[0],
										 &__type_oid,
										 NULL,
										 NULL);
				type_oid = get_array_type(__type_oid);
				if (!OidIsValid(type_oid))
					elog(ERROR, "arrow_fdw: no array type for '%s'",
						 format_type_be(__type_oid));
			}
			break;

		case ArrowNodeTag__Struct:
			{
				Oid	   *__type_oids;

				attopts.tag = ArrowType__Struct;
				attopts.unitsz = 0;		/* only nullmap */
				__type_oids = alloca(sizeof(Oid) * (field->_num_children + 1));
				for (int j=0; j < field->_num_children; j++)
				{
					__arrowFieldTypeToPGType(&field->children[j],
											 &__type_oids[j],
											 NULL,
											 NULL);
				}
				type_oid = __lookupCompositePGType(field->_num_children,
												   __type_oids,
												   hint_oid);
				if (!OidIsValid(type_oid))
					elog(ERROR, "arrow_fdw: no suitable composite type");
			}
			break;

		default:
			elog(ERROR, "Bug? ArrowSchema contains unsupported types");
	}

	if (p_type_oid)
		*p_type_oid = type_oid;
	if (p_type_mod)
		*p_type_mod = type_mod;
	if (p_attopts)
		memcpy(p_attopts, &attopts, sizeof(ArrowTypeOptions));
}

static void
__buildRecordBatchFieldState(setupRecordBatchContext *con,
							 RecordBatchFieldState *rb_field,
							 ArrowField *field, int depth)
{
	ArrowFieldNode *fnode;
	ArrowBuffer	   *buffer_curr;
	size_t			least_values_length = 0;
	bool			has_extra_buffer = false;

	if (con->fnode_curr >= con->fnode_tail)
		elog(ERROR, "RecordBatch has less ArrowFieldNode than expected");
	fnode = con->fnode_curr++;
	strncpy(rb_field->attname, field->name, NAMEDATALEN);
	rb_field->attname[NAMEDATALEN-1] = '\0';
	rb_field->atttypid    = InvalidOid;
	rb_field->atttypmod   = -1;
	rb_field->nitems      = fnode->length;
	rb_field->null_count  = fnode->null_count;
	rb_field->stat_datum.isnull = true;
	__arrowFieldTypeToPGType(field,
							 &rb_field->atttypid,
							 &rb_field->atttypmod,
							 &rb_field->attopts);
	/* assign buffers */
	switch (field->type.node.tag)
	{
		case ArrowNodeTag__Bool:
			least_values_length = BITMAPLEN(rb_field->nitems);
			break;
		case ArrowNodeTag__Int:
		case ArrowNodeTag__FloatingPoint:
		case ArrowNodeTag__Decimal:
		case ArrowNodeTag__Date:
		case ArrowNodeTag__Time:
		case ArrowNodeTag__Timestamp:
		case ArrowNodeTag__Interval:
		case ArrowNodeTag__FixedSizeBinary:
			least_values_length = rb_field->attopts.unitsz * rb_field->nitems;
			break;

		case ArrowNodeTag__Utf8:
		case ArrowNodeTag__LargeUtf8:
		case ArrowNodeTag__Binary:
		case ArrowNodeTag__LargeBinary:
			least_values_length = rb_field->attopts.unitsz * (rb_field->nitems + 1);
			has_extra_buffer = true;
			break;

		case ArrowNodeTag__List:
        case ArrowNodeTag__LargeList:
			if (depth > 0)
				elog(ERROR, "nested array type is not supported");
			least_values_length = rb_field->attopts.unitsz * (rb_field->nitems + 1);
			break;

		case ArrowNodeTag__Struct:
			if (depth > 0)
				elog(ERROR, "nested composite type is not supported");
			/* no values and extra buffer, only nullmap */
			break;
		default:
			elog(ERROR, "Bug? ArrowSchema contains unsupported types");
	}

	if (ArrowMetadataVersionIsParquet(con->version))
	{
		/*
		 * If the ArrowFileInfo is a parsed Parquet file (i.e., you are using
		 * emulation mode that converts to Arrow at runtime), Buffer does not
		 * contain any meaningful content. It simply has a Buffer array with
		 * the same number of Fields as it does, and stores the compressed chunk
		 * positions and self-reported sizes, so there is no point in checking
		 * consistency like when reading Arrow.
		 */
		Assert(con->buffer_curr == NULL &&
			   con->buffer_tail == NULL);

		/*
		 * Parquet embeds min/max statistics in FieldNode. If available, it
		 * shall be assigned on the RecordBatchFieldState.
		 */
		if (fnode->stat_min_value && fnode->stat_max_value)
		{
			__assignArrowStatsBinaryOne(&rb_field->stat_datum,
										field,
										fnode->stat_min_value,
										fnode->stat_max_value);
		}
		rb_field->disk_length = fnode->parquet.total_compressed_size;
	}
	else
	{
		/* setup nullmap buffer */
		buffer_curr = con->buffer_curr++;
		if (buffer_curr >= con->buffer_tail)
			elog(ERROR, "RecordBatch has less buffers than expected");
		if (rb_field->null_count > 0)
		{
			rb_field->nullmap_offset = buffer_curr->offset;
			rb_field->nullmap_length = buffer_curr->length;
			if (rb_field->nullmap_length < BITMAPLEN(rb_field->nitems))
				elog(ERROR, "nullmap length is smaller than expected");
			if (rb_field->nullmap_offset != MAXALIGN(rb_field->nullmap_offset))
				elog(ERROR, "nullmap is not aligned well");
			rb_field->disk_length += buffer_curr->length;
		}

		/* setup values buffer */
		if (least_values_length > 0)
		{
			buffer_curr = con->buffer_curr++;
			if (buffer_curr >= con->buffer_tail)
				elog(ERROR, "RecordBatch has less buffers than expected");
			rb_field->values_offset = buffer_curr->offset;
			rb_field->values_length = buffer_curr->length;
			if (rb_field->values_length < least_values_length)
				elog(ERROR, "values array is smaller than expected");
			if (rb_field->values_offset != MAXALIGN(rb_field->values_offset))
				elog(ERROR, "values array is not aligned well");
			rb_field->disk_length += buffer_curr->length;
		}

		/* setup extra buffer */
		if (has_extra_buffer)
		{
			Assert(least_values_length > 0);
			buffer_curr = con->buffer_curr++;
			if (buffer_curr >= con->buffer_tail)
				elog(ERROR, "RecordBatch has less buffers than expected");
			rb_field->extra_offset = buffer_curr->offset;
			rb_field->extra_length = buffer_curr->length;
			if (rb_field->extra_offset != MAXALIGN(rb_field->extra_offset))
				elog(ERROR, "extra buffer is not aligned well");
			rb_field->disk_length += buffer_curr->length;
		}
	}

	/* child fields, if any */
	if (field->_num_children > 0)
	{
		rb_field->children = palloc0(sizeof(RecordBatchFieldState) *
									 field->_num_children);
		for (int j=0; j < field->_num_children; j++)
		{
			__buildRecordBatchFieldState(con,
										 &rb_field->children[j],
										 &field->children[j],
										 depth+1);
			rb_field->disk_length += rb_field->children[j].disk_length;
		}
	}
	rb_field->num_children = field->_num_children;
}

static RecordBatchState *
__buildRecordBatchStateOne(ArrowSchema *schema,
						   ArrowFileState *af_state,
						   int rb_index,
						   ArrowBlock *block,
						   ArrowRecordBatch *rbatch,
						   Bitmapset **p_stat_attrs)
{
	setupRecordBatchContext con;
	RecordBatchState *rb_state;
	int			nfields = schema->_num_fields;

	if (rbatch->compression)
		elog(ERROR, "arrow_fdw: right now, compressed record-batche is not supported");

	rb_state = palloc0(offsetof(RecordBatchState, fields[nfields]));
	rb_state->af_state = af_state;
	rb_state->rb_index = rb_index;
	rb_state->rb_offset = block->offset + block->metaDataLength;
	rb_state->rb_length = block->bodyLength;
	rb_state->rb_nitems = rbatch->length;
	rb_state->nfields   = nfields;

	memset(&con, 0, sizeof(setupRecordBatchContext));
	con.version     = af_state->version;
	con.buffer_curr = rbatch->buffers;
	con.buffer_tail = rbatch->buffers + rbatch->_num_buffers;
	con.fnode_curr  = rbatch->nodes;
	con.fnode_tail  = rbatch->nodes + rbatch->_num_nodes;
	for (int j=0; j < nfields; j++)
	{
		RecordBatchFieldState *rb_field = &rb_state->fields[j];
		ArrowField	   *field = &schema->fields[j];

		__buildRecordBatchFieldState(&con, rb_field, field, 0);
		if (!rb_field->stat_datum.isnull)
			*p_stat_attrs = bms_add_member(*p_stat_attrs, j);
	}
	if (con.buffer_curr != con.buffer_tail ||
		con.fnode_curr  != con.fnode_tail)
		elog(ERROR, "arrow_fdw: RecordBatch may be corrupted");
	return rb_state;
}

/*
 * readArrowFile
 */
static bool
readArrowFile(const char *filename, ArrowFileInfo *af_info, bool missing_ok)
{
	int		status = readArrowFileInfo(filename, af_info);

	if (status != 0)
	{
		if (missing_ok && status == ENOENT)
			return false;
		ereport(ERROR,
				(errcode_for_file_access(),
				 errmsg("could not open file \"%s\"", filename)));
	}
	if (af_info->dictionaries != NULL)
		elog(ERROR, "DictionaryBatch is not supported at '%s'", filename);
	Assert(af_info->footer._num_dictionaries == 0);
	return true;
}

static bool
__setupArrowFileStateByFile(ArrowFileState *af_state,
							const char *filename,
							ArrowFileInfo *af_info,
							Bitmapset **p_stat_attrs)
{
	arrowStatsBinary *arrow_bstats;

	if (!readArrowFile(filename, af_info, true))
	{
		elog(DEBUG2, "file '%s' is missing: %m", filename);
		return false;
	}
	if (af_info->recordBatches == NULL)
	{
		elog(DEBUG2, "arrow file '%s' contains no RecordBatch", filename);
		return false;
	}
	/* save the version to determine whether Arrow or Parquet */
	af_state->version = af_info->footer.version;
	/* set up ArrowFileState */
	arrow_bstats = buildArrowStatsBinary(&af_info->footer, p_stat_attrs);
	for (int i=0; i < af_info->footer._num_recordBatches; i++)
	{
		ArrowBlock		   *block  = &af_info->footer.recordBatches[i];
		ArrowMessage	   *message = &af_info->recordBatches[i];
		ArrowRecordBatch   *rbatch = &message->body.recordBatch;
		RecordBatchState   *rb_state;

		rb_state = __buildRecordBatchStateOne(&af_info->footer.schema,
											  af_state, i, block, rbatch,
											  p_stat_attrs);
		if (arrow_bstats)
			applyArrowStatsBinary(rb_state, arrow_bstats);		/* stats v1 */
		else
			assignArrowStatsBinary(rb_state, p_stat_attrs,		/* stats v2 */
								   &af_info->footer.schema,
								   message->_num_custom_metadata,
								   message->custom_metadata);
		/* ok, built */
		af_state->rb_list = lappend(af_state->rb_list, rb_state);
	}
	releaseArrowStatsBinary(arrow_bstats);

	return true;
}

static arrowMetadataFieldCache *
__buildArrowMetadataFieldCache(RecordBatchFieldState *rb_field,
							   ArrowField *arrow_field,
							   arrowMetadataFieldCache *fcache_prev,
							   arrowMetadataCacheBlock **p_mc_block)
{
	arrowMetadataFieldCache *fcache;
	dlist_node	   *__dnode_prev = NULL;

	fcache = __allocMetadataFieldCache(p_mc_block);
	if (!fcache)
		return NULL;
	strcpy(fcache->attname, rb_field->attname);
	fcache->atttypid = rb_field->atttypid;
	fcache->atttypmod = rb_field->atttypmod;
	memcpy(&fcache->attopts, &rb_field->attopts, sizeof(ArrowTypeOptions));
	fcache->nitems = rb_field->nitems;
	fcache->null_count = rb_field->null_count;
	fcache->nullmap_offset = rb_field->nullmap_offset;
	fcache->nullmap_length = rb_field->nullmap_length;
	fcache->values_offset = rb_field->values_offset;
	fcache->values_length = rb_field->values_length;
	fcache->extra_offset = rb_field->extra_offset;
	fcache->extra_length = rb_field->extra_length;
	fcache->disk_length = rb_field->disk_length;
	memcpy(&fcache->stat_datum,
		   &rb_field->stat_datum, sizeof(MinMaxStatDatum));
	/* custom-metadata can be reused for the record-batch > 0 */
	if (fcache_prev)
		fcache->custom_metadata = fcache_prev->custom_metadata;
	else
	{
		arrowMetadataKeyValueCache *mc_kv_prev = NULL;
		arrowMetadataKeyValueCache *mc_kv;

		fcache->custom_metadata = NULL;
		for (int k=0; k < arrow_field->_num_custom_metadata; k++)
		{
			mc_kv = __allocMetadataKeyValueCache(p_mc_block,
												 &arrow_field->custom_metadata[k]);
			if (!mc_kv)
				return NULL;
			if (mc_kv_prev)
				mc_kv_prev->next = mc_kv;
			else
				fcache->custom_metadata = mc_kv;
			mc_kv_prev = mc_kv;
		}
	}

	/* walk down the child fields if any */
	fcache->num_children = rb_field->num_children;
		dlist_init(&fcache->children);
	for (int j=0; j < rb_field->num_children; j++)
	{
		arrowMetadataFieldCache *__fcache_prev = NULL;
		arrowMetadataFieldCache *__fcache;

		if (fcache_prev)
		{
			if (!__dnode_prev)
				__dnode_prev = dlist_head_node(&fcache_prev->children);
			else
				__dnode_prev = dlist_next_node(&fcache_prev->children,
											   __dnode_prev);
			__fcache_prev = dlist_container(arrowMetadataFieldCache,
											chain, __dnode_prev);
		}
		__fcache = __buildArrowMetadataFieldCache(&rb_field->children[j],
												  &arrow_field->children[j],
												  __fcache_prev,
												  p_mc_block);
		if (!__fcache)
			return NULL;
		dlist_push_tail(&fcache->children, &__fcache->chain);
	}
	return fcache;
}

/*
 * __buildArrowMetadataCacheNoLock
 *
 * it builds arrowMetadataCache entries according to the supplied
 * ArrowFileState
 */
static arrowMetadataCacheBlock *
__buildArrowMetadataCacheNoLock(ArrowFileState *af_state,
								ArrowFileInfo *af_info)
{
	ArrowSchema	   *schema = &af_info->footer.schema;
	arrowMetadataCacheBlock *mc_block_head = NULL;
	arrowMetadataCacheBlock *mc_block_curr;
	arrowMetadataCache *mcache_prev = NULL;
	arrowMetadataCache *mcache;
	uint32_t	hindex;
	ListCell   *lc;

	Assert(list_length(af_state->rb_list) > 0);
	foreach (lc, af_state->rb_list)
	{
		RecordBatchState *rb_state = lfirst(lc);
		dlist_node	   *dnode_prev = NULL;

		if (!mc_block_head)
		{
			arrowMetadataKeyValueCache *mc_kv_prev = NULL;
			arrowMetadataKeyValueCache *mc_kv;

			mc_block_head = __allocMetadataCacheBlock();
			if (!mc_block_head)
				goto bailout;
			memcpy(&mc_block_head->stat_buf,
				   &af_state->stat_buf, sizeof(struct stat));
			mc_block_head->version = af_info->footer.version;
			mc_block_head->usage = MAXALIGN(offsetof(arrowMetadataCacheBlock,
													 mcache_head) +
											sizeof(arrowMetadataCache));
			arrow_metadata_cache->total_cache_usage += mc_block_head->usage;
			mc_block_curr = mc_block_head;

			/* custom-metadata; must be setup after usage assignment */
			for (int k=0; k < schema->_num_custom_metadata; k++)
			{
				mc_kv = __allocMetadataKeyValueCache(&mc_block_curr,
													 &schema->custom_metadata[k]);
				if (!mc_kv)
					goto bailout;
				if (mc_kv_prev)
					mc_kv_prev->next = mc_kv;
				else
					mc_block_head->custom_metadata = mc_kv;
				mc_kv_prev = mc_kv;
			}
			/* metadata-cache for the first record-batch */
			mcache = &mc_block_head->mcache_head;
		}
		else
		{
			mcache = __allocMetadataCache(&mc_block_curr);
			if (!mcache)
				goto bailout;
		}
		memset(mcache, 0, sizeof(arrowMetadataCache));
		mcache->rb_index  = rb_state->rb_index;
		mcache->rb_offset = rb_state->rb_offset;
		mcache->rb_length = rb_state->rb_length;
		mcache->rb_nitems = rb_state->rb_nitems;
		mcache->nfields   = rb_state->nfields;
		dlist_init(&mcache->fields);
		if (mcache_prev)
			mcache_prev->next = mcache;
		for (int j=0; j < rb_state->nfields; j++)
		{
			arrowMetadataFieldCache *fcache_prev = NULL;
			arrowMetadataFieldCache *fcache;

			if (mcache_prev)
			{
				if (!dnode_prev)
					dnode_prev = dlist_head_node(&mcache_prev->fields);
				else
					dnode_prev = dlist_next_node(&mcache_prev->fields,
												 dnode_prev);
				fcache_prev = dlist_container(arrowMetadataFieldCache,
											  chain, dnode_prev);
			}
			Assert(j < schema->_num_fields);
			fcache = __buildArrowMetadataFieldCache(&rb_state->fields[j],
													&schema->fields[j],
													fcache_prev,
													&mc_block_curr);
			if (!fcache)
				goto bailout;
			dlist_push_tail(&mcache->fields, &fcache->chain);
		}
		mcache_prev = mcache;
	}
	/* chain to the list */
	hindex = arrowMetadataHashIndex(&af_state->stat_buf);
	dlist_push_tail(&arrow_metadata_cache->hash_slots[hindex],
					&mc_block_head->chain );
	SpinLockAcquire(&arrow_metadata_cache->lru_lock);
	gettimeofday(&mc_block_head->lru_tv, NULL);
	dlist_push_head(&arrow_metadata_cache->lru_list, &mc_block_head->lru_chain);
	SpinLockRelease(&arrow_metadata_cache->lru_lock);
	/* update statistics */
	arrow_metadata_cache->num_file_entries++;
	return mc_block_head;

bailout:
	if (mc_block_head)
		__releaseMetadataCacheBlock(mc_block_head);
	return NULL;
}

/*
 * __processVirtualColumn - process one token of the virtual token cstring
 */
static Datum
__processVirtualColumn(Form_pg_attribute attr,
					   char *vc_key,
					   char *vc_value,
					   Relation frel,
					   const char *filename)
{
	MemoryContext oldcxt = CurrentMemoryContext;
	Oid		type_input;
	Oid		type_ioparam;
	Datum	datum;

	getTypeInputInfo(attr->atttypid,
					 &type_input,
					 &type_ioparam);
	PG_TRY();
	{
		datum = OidInputFunctionCall(type_input,
									 vc_value,
									 type_ioparam,
									 attr->atttypmod);
	}
	PG_CATCH();
	{
		MemoryContext errcxt = MemoryContextSwitchTo(oldcxt);
		ErrorData  *edata = CopyErrorData();

		ereport(Max(ERROR, edata->elevel),
				errmsg("(%s:%d) %s",
					   edata->filename,
					   edata->lineno,
					   edata->message),
				errdetail("arrow_fdw: processing virtual column '%s' of the file '%s' at the attribute '%s' of foreign table '%s'",
						  vc_key, filename,
						  NameStr(attr->attname),
						  RelationGetRelationName(frel)));
		MemoryContextSwitchTo(errcxt);
	}
	PG_END_TRY();

	return datum;
}

static inline const char *
__fetchVirtualSourceSpecial(ArrowFileState *af_state, const char *key)
{
	if (*key == '@')
	{
		if (strcmp(key, "@pathname") == 0)
			return af_state->filename;
		else if (strcmp(key, "@filename") == 0)
		{
			const char *pos = strrchr(af_state->filename, '/');

			if (pos)
				return pos+1;
			return af_state->filename;
		}
	}
	return NULL;
}

static List *
__fetchVirtualSourceByCache(ArrowFileState *af_state,
							arrowMetadataCacheBlock *mc_block,
							List *virtual_columns,
							List *source_fields)
{
	List	   *results = NIL;
	ListCell   *lc1, *lc2;

	foreach (lc1, source_fields)
	{
		const char *src = lfirst(lc1);
		const char *value = NULL;

		if (strncmp(src, "virtual:", 8) == 0)
		{
			const char *key = src + 8;

			value = __fetchVirtualSourceSpecial(af_state, key);
			if (value)
				goto found;
			foreach (lc2, virtual_columns)
			{
				virtualColumnDef *vcdef = lfirst(lc2);

				if (strcmp(key, vcdef->key) == 0)
				{
					value = vcdef->value;
					goto found;
				}
			}
		}
		else if (strncmp(src, "metadata:", 9) == 0 ||
				 strncmp(src, "metadata-split:", 15) == 0)
		{
			char   *key = alloca(strlen(src));
			char   *pos;

			strcpy(key, strchr(src, ':') + 1);
			pos = strchr(key, '.');
			if (pos)
				*pos++ = '\0';
			if (!pos)
			{
				/* fetch custom-metadata from Schema */
				arrowMetadataKeyValueCache *mc_kv = mc_block->custom_metadata;

				while (mc_kv)
				{
					if (strcmp(mc_kv->key, key) == 0)
					{
						value = mc_kv->value;
						goto found;
					}
					mc_kv = mc_kv->next;
				}
			}
			else
			{
				/* fetch custom-metadata from Fields */
				dlist_iter	iter;

				dlist_foreach (iter, &mc_block->mcache_head.fields)
				{
					arrowMetadataFieldCache *fcache = dlist_container(arrowMetadataFieldCache,
																	  chain, iter.cur);
					if (strcmp(fcache->attname, key) == 0)
					{
						arrowMetadataKeyValueCache *mc_kv = fcache->custom_metadata;

						while (mc_kv)
						{
							if (strcmp(mc_kv->key, pos) == 0)
							{
								value = mc_kv->value;
								goto found;
							}
							mc_kv = mc_kv->next;
						}
					}
				}
			}
		}
	found:
		results = lappend(results, value ? pstrdup(value) : NULL);
	}
	return results;
}

static List *
__fetchVirtualSourceByFile(ArrowFileState *af_state,
						   ArrowFileInfo *af_info,
						   List *virtual_columns,
						   List *source_fields)
{
	List	   *results = NIL;
	ListCell   *lc1, *lc2;

	foreach (lc1, source_fields)
	{
		const char *src = lfirst(lc1);
		const char *value = NULL;

		if (strncmp(src, "virtual:", 8) == 0)
		{
			const char *key = src + 8;

			value = __fetchVirtualSourceSpecial(af_state, key);
			if (value)
				goto found;
			foreach (lc2, virtual_columns)
			{
				virtualColumnDef *vcdef = lfirst(lc2);

				if (strcmp(key, vcdef->key) == 0)
				{
					value = vcdef->value;
					goto found;
				}
			}
		}
		else if (strncmp(src, "metadata:", 9) == 0 ||
				 strncmp(src, "metadata-split:", 15) == 0)
		{
			ArrowSchema	*schema = &af_info->footer.schema;
			char   *key = alloca(strlen(src));
			char   *pos;

			strcpy(key, strchr(src, ':') + 1);
			pos = strchr(key, '.');
			if (pos)
				*pos++ = '\0';

			if (!pos)
			{
				/* fetch custom-metadata from Schema */
				for (int i=0; i < schema->_num_custom_metadata; i++)
				{
					ArrowKeyValue  *kv = &schema->custom_metadata[i];

					if (strcmp(kv->key, key) == 0)
					{
						value = kv->value;
						goto found;
					}
				}
			}
			else
			{
				/* fetch custom-metadata from Fields */
				for (int i=0; i < schema->_num_fields; i++)
				{
					ArrowField *field = &schema->fields[i];

					if (strcmp(field->name, key) == 0)
					{
						for (int k=0; k < field->_num_custom_metadata; k++)
						{
							ArrowKeyValue  *kv = &field->custom_metadata[k];

							if (strcmp(kv->key, pos) == 0)
							{
								value = kv->value;
								goto found;
							}
						}
					}
				}
			}
		}
	found:
		results = lappend(results, value ? pstrdup(value) : NULL);
	}
	return results;
}

static ArrowFileState *
BuildArrowFileState(Relation frel,
					const char *filename,
					List *source_fields,
					List *virtual_columns,
					int parquet_cache,
					Bitmapset **p_stat_pg_attrs)
{
	TupleDesc		tupdesc = RelationGetDescr(frel);
	arrowMetadataCacheBlock *mc_block;
	ArrowFileState *af_state;
	RecordBatchState *rb_state;
	Bitmapset	   *stat_arrow_attrs = NULL;
	Bitmapset	   *stat_pg_attrs = NULL;
	struct stat		stat_buf;
	List		   *virtual_sources = NIL;
	ListCell	   *lc1, *lc2;
	gpumask_t		optimal_gpus;
	int				j;

	if (stat(filename, &stat_buf) != 0)
		elog(ERROR, "failed on stat('%s'): %m", filename);
	optimal_gpus = GetOptimalGpuForFile(filename);
	if (optimal_gpus == INVALID_GPUMASK)
		optimal_gpus = 0;
	af_state = palloc0(offsetof(ArrowFileState, attrs[tupdesc->natts]));
	af_state->filename = pstrdup(filename);
	af_state->optimal_gpus = optimal_gpus;
	memcpy(&af_state->stat_buf, &stat_buf, sizeof(struct stat));
	af_state->parquet_cache = parquet_cache;
	af_state->ncols = tupdesc->natts;

	LWLockAcquire(&arrow_metadata_cache->mutex, LW_SHARED);
	mc_block = lookupArrowMetadataCache(&stat_buf, false);
	if (mc_block)
	{
		/* found a valid metadata-cache */
		__setupArrowFileStateByCache(af_state,
									 filename,
									 mc_block,
									 &stat_arrow_attrs);
		/* extract virtual column source info */
		virtual_sources = __fetchVirtualSourceByCache(af_state,
													  mc_block,
													  virtual_columns,
													  source_fields);
	}
	else
	{
		ArrowFileInfo af_info;

		LWLockRelease(&arrow_metadata_cache->mutex);
		/* here is no valid metadata-cache, so build it from the raw file */
		if (!__setupArrowFileStateByFile(af_state,
										 filename,
										 &af_info,
										 &stat_arrow_attrs))
			return NULL;	/* file not found? */
		/* extract virtual column source info */
		virtual_sources = __fetchVirtualSourceByFile(af_state,
													 &af_info,
													 virtual_columns,
													 source_fields);
		LWLockAcquire(&arrow_metadata_cache->mutex, LW_EXCLUSIVE);
		mc_block = lookupArrowMetadataCache(&af_state->stat_buf, true);
		if (!mc_block)
			__buildArrowMetadataCacheNoLock(af_state, &af_info);
	}
	LWLockRelease(&arrow_metadata_cache->mutex);

	/*
	 * Maps PG-attribute on a particular Arrow-field, or virtual-column
	 * according to the column option
	 */
	rb_state = linitial(af_state->rb_list);
	Assert(tupdesc->natts == af_state->ncols &&
		   tupdesc->natts == list_length(source_fields) &&
		   tupdesc->natts == list_length(virtual_sources));
	j = 0;
	forboth (lc1, source_fields,
			 lc2, virtual_sources)
	{
		Form_pg_attribute attr = TupleDescAttr(tupdesc, j);
		char	   *sfield = lfirst(lc1);
		char	   *vsource = lfirst(lc2);

		if (attr->attisdropped)
		{
			af_state->attrs[j].field_index = __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE;
			af_state->attrs[j].virtual_isnull = true;
			af_state->attrs[j].virtual_datum = 0;
		}
		else if (strncmp(sfield, "field-missing-null:", 19) == 0 ||
				 strncmp(sfield, "field-missing-fail:", 19) == 0)
		{
			const char *field_name = (sfield + 19);
			int			field_index = -1;

			for (int k=0; k < rb_state->nfields; k++)
			{
				RecordBatchFieldState *field = &rb_state->fields[k];

				if (strcmp(field->attname, field_name) == 0)
				{
					/* also checks data type compatibility */
					if (IsBinaryCoercible(field->atttypid,
										  attr->atttypid))
					{
						field_index = k;
						break;
					}
					elog(ERROR, "arrow_fdw: foreign table '%s' of '%s' is not compatible to '%s' of '%s'",
						 NameStr(attr->attname),
						 RelationGetRelationName(frel),
						 field->attname,
						 filename);
				}
			}
			if (field_index < 0)
			{
				if (strncmp(sfield, "field-missing-fail:", 19) == 0)
					elog(ERROR, "arrow_fdw: foreign table '%s' of '%s' could not find out the field '%s' on the arrow file '%s'",
						 NameStr(attr->attname),
						 RelationGetRelationName(frel),
						 field_name,
						 filename);
				af_state->attrs[j].field_index = __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE;
				af_state->attrs[j].virtual_isnull = true;
				af_state->attrs[j].virtual_datum = 0;
			}
			else
			{
				af_state->attrs[j].field_index = field_index;

				if (bms_is_member(field_index, stat_arrow_attrs))
					stat_pg_attrs = bms_add_member(stat_pg_attrs, attr->attnum -
												   FirstLowInvalidHeapAttributeNumber);
			}
		}
		else if (vsource && (strncmp(sfield, "virtual:", 8) == 0 ||
							 strncmp(sfield, "metadata:", 9) == 0))
		{
			Datum	datum = __processVirtualColumn(attr,
												   sfield,
												   vsource,
												   frel, filename);
			af_state->attrs[j].field_index = __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE;
			af_state->attrs[j].virtual_isnull = false;
			af_state->attrs[j].virtual_datum = datum;
			/*
			 * The virtual value is immutable to a particular record-batch,
			 * so we can consider it also works as min/max statistics to skip
			 * obviously unmatched record-batches.
			 */
			stat_pg_attrs = bms_add_member(stat_pg_attrs, attr->attnum -
										   FirstLowInvalidHeapAttributeNumber);
		}
		else if (vsource && strncmp(sfield, "metadata-split:", 15) == 0)
		{
			ListCell   *cell;
			char	   *buffer = pstrdup(vsource);
			char	   *tok, *pos;
			int			vindex = -1;

			tok = strtok_r(buffer, ",", &pos);
			foreach (cell, af_state->rb_list)
			{
				RecordBatchState *__rb_state = lfirst(cell);
				int		__vindex = __rb_state->virtual_nitems++;

				if (vindex < 0)
					vindex = __vindex;
				else
					assert(vindex == __vindex);
				if (!__rb_state->virtual_values)
					__rb_state->virtual_values = palloc(sizeof(Datum) * 4);
				else
					__rb_state->virtual_values = repalloc(__rb_state->virtual_values,
														  sizeof(Datum) * __rb_state->virtual_nitems);
				if (!__rb_state->virtual_isnull)
					__rb_state->virtual_isnull = palloc(sizeof(bool) * 4);
				else
					__rb_state->virtual_isnull = repalloc(__rb_state->virtual_isnull,
														  sizeof(bool) * __rb_state->virtual_nitems);
				if (!tok)
				{
					__rb_state->virtual_isnull[vindex] = true;
					__rb_state->virtual_values[vindex] = 0;
				}
				else
				{
					Datum	datum = __processVirtualColumn(attr,
														   sfield,
														   tok,
														   frel,
														   filename);
					__rb_state->virtual_values[vindex] = datum;
					__rb_state->virtual_isnull[vindex] = false;
					tok = strtok_r(NULL, ",", &pos);
				}
			}
			if (vindex < 0)
				af_state->attrs[j].field_index = __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE;
			else
				af_state->attrs[j].field_index = -(vindex + 2);	/* Per Record-Batch Virtual Column */
			af_state->attrs[j].virtual_isnull = true;
			af_state->attrs[j].virtual_datum = 0;
			/* see the comment above */
			stat_pg_attrs = bms_add_member(stat_pg_attrs, attr->attnum -
										   FirstLowInvalidHeapAttributeNumber);
			/* cleanup */
			pfree(buffer);
		}
		else
		{
			/* just put a virtual NULL */
			af_state->attrs[j].field_index = __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE;
			af_state->attrs[j].virtual_isnull = true;
			af_state->attrs[j].virtual_datum = 0;
		}
		j++;
	}
	bms_free(stat_arrow_attrs);
	if (p_stat_pg_attrs)
		*p_stat_pg_attrs = stat_pg_attrs;
	else
		bms_free(stat_pg_attrs);
	return af_state;
}

/*
 * baseRelIsArrowFdw
 */
bool
baseRelIsArrowFdw(RelOptInfo *baserel)
{
	if ((baserel->reloptkind == RELOPT_BASEREL ||
		 baserel->reloptkind == RELOPT_OTHER_MEMBER_REL) &&
		baserel->rtekind == RTE_RELATION &&
		OidIsValid(baserel->serverid) &&
		baserel->fdwroutine &&
		memcmp(baserel->fdwroutine,
			   &pgstrom_arrow_fdw_routine,
			   sizeof(FdwRoutine)) == 0)
		return true;

	return false;
}

/*
 * arrowFdwGpuScanSupported
 *
 * The Vulkan service reads Arrow record batches itself (arrow_exec.c) and forms the result tuples
 * from the columnar buffers. It supports the Arrow types of the columns that are referenced by the
 * query, if they are: Int (1-8 bytes), FloatingPoint, Bool, Utf8/LargeUtf8, Binary/LargeBinary,
 * Date[day], Time, Timestamp, FixedSizeBinary mapped to bpchar, and virtual columns (Parquet row-groups are decoded by the backend and sent inline). Decimal,
 * interval, list, struct and the rest stay on the CPU path.
 */
static bool
__arrowFieldGpuScanSupported(const RecordBatchFieldState *field)
{
	const ArrowTypeOptions *attopts = &field->attopts;

	switch (attopts->tag)
	{
		case ArrowType__Int:
			return (attopts->unitsz == 1 || attopts->unitsz == 2 ||
					attopts->unitsz == 4 || attopts->unitsz == 8);
		case ArrowType__FloatingPoint:
			return (attopts->unitsz == 2 || attopts->unitsz == 4 || attopts->unitsz == 8);
		case ArrowType__Bool:
		case ArrowType__Utf8:
		case ArrowType__LargeUtf8:
		case ArrowType__Binary:
		case ArrowType__LargeBinary:
		case ArrowType__Time:
		case ArrowType__Timestamp:
			return true;
		case ArrowType__Date:
			return (attopts->date.unit == ArrowDateUnit__Day);
		case ArrowType__FixedSizeBinary:
			return (field->atttypid == BPCHAROID);
		default:
			return false;
	}
}

/*
 * The Arrow loader of the Vulkan service reads integer, float4, bool, date, time, timestamp and string
 * values (utf8, char(n)). A numeric value (Decimal is not a supported Arrow type, but an expression can
 * produce one) may need the backend to evaluate the row again, which an Arrow record batch cannot do:
 * a qual that reads or produces one stays on the CPU.
 */
static bool
__arrowQualNeedsUnsupportedValue(Node *node, void *context)
{
	if (node == NULL)
		return false;
	if (IsA(node, NullTest) && IsA(((NullTest *) node)->arg, Var))
		return false;			/* only the NULL-ness of the column is needed */
	if (IsA(node, RestrictInfo))
		return __arrowQualNeedsUnsupportedValue((Node *)((RestrictInfo *) node)->clause, context);
	if (IsA(node, List))
		return expression_tree_walker(node, __arrowQualNeedsUnsupportedValue, context);
	switch (exprType(node))
	{
		case NUMERICOID:
			return true;
		default:
			break;
	}
	return expression_tree_walker(node, __arrowQualNeedsUnsupportedValue, context);
}

bool
arrowFdwGpuScanSupported(RelOptInfo *baserel)
{
	List	   *af_states;
	Bitmapset  *referenced;
	bool		whole_row;
	ListCell   *lc;

	if (!baseRelIsArrowFdw(baserel) ||
		list_length(baserel->fdw_private) != 2)
		return false;
	if (__arrowQualNeedsUnsupportedValue((Node *) baserel->baserestrictinfo, NULL))
		return false;
	af_states = linitial(baserel->fdw_private);
	referenced = lsecond(baserel->fdw_private);
	whole_row = bms_is_member(-FirstLowInvalidHeapAttributeNumber, referenced);
	foreach (lc, af_states)
	{
		ArrowFileState *af_state = lfirst(lc);
		RecordBatchState *rb_state;

		if (af_state->rb_list == NIL)
			continue;
		rb_state = linitial(af_state->rb_list);
		for (int j=0; j < af_state->ncols; j++)
		{
			int		k = j + 1 - FirstLowInvalidHeapAttributeNumber;
			int		field_index = af_state->attrs[j].field_index;

			if (!whole_row && !bms_is_member(k, referenced))
				continue;
			if (field_index < 0)
				continue;		/* virtual column */
			if (field_index >= rb_state->nfields ||
				!__arrowFieldGpuScanSupported(&rb_state->fields[field_index]))
				return false;
		}
	}
	return true;
}

/*
 * RelationIsArrowFdw
 */
bool
RelationIsArrowFdw(Relation frel)
{
	if (RelationGetForm(frel)->relkind == RELKIND_FOREIGN_TABLE)
	{
		FdwRoutine *routine = GetFdwRoutineForRelation(frel, false);

		if (memcmp(routine, &pgstrom_arrow_fdw_routine, sizeof(FdwRoutine)) == 0)
			return true;
	}
	return false;
}

/*
 * GetOptimalGpusForArrowFdw
 */
gpumask_t
GetOptimalGpusForArrowFdw(PlannerInfo *root, RelOptInfo *baserel)
{
	List	   *priv_list = (List *)baserel->fdw_private;
	gpumask_t	optimal_gpus = 0;

	if (baseRelIsArrowFdw(baserel) &&
		IsA(priv_list, List) && list_length(priv_list) == 2)
	{
		const char *relname = getRelOptInfoName(root, baserel);
		List	   *arrow_files_list = linitial(priv_list);
		ListCell   *lc;

		foreach (lc, arrow_files_list)
		{
			ArrowFileState *af_state = lfirst(lc);
			gpumask_t		__optimal_gpus;

			__optimal_gpus = GetOptimalGpuForFile(af_state->filename);
			if (__optimal_gpus == INVALID_GPUMASK)
				__optimal_gpus = 0;
			if (lc == list_head(arrow_files_list))
			{
				optimal_gpus = __optimal_gpus;
				if (optimal_gpus == 0)
					__Info("foreign-table='%s' arrow-file='%s' has no schedulable GPUs", relname, af_state->filename);
			}
			else
			{
				__optimal_gpus &= optimal_gpus;
				if (optimal_gpus != __optimal_gpus)
					__Info("foreign-table='%s' arrow-file='%s' reduced GPUs-set %08lx => %08lx", relname, af_state->filename, optimal_gpus, __optimal_gpus);
				optimal_gpus = __optimal_gpus;
			}
			if (optimal_gpus == 0)
				break;
		}
	}
	return optimal_gpus;
}

/*
 * arrowFdwExcludeFileNamesByPattern
 */
static List *
arrowFdwExcludeFileNamesByPattern(List *filesList,
								  const char *pattern,
								  List **p_virtAttrsList)
{
	List	   *results = NIL;	/* only valid files */
	List	   *attrsList = NIL;
	ListCell   *lc;

	foreach (lc, filesList)
	{
		String *path = lfirst(lc);
		List   *attrKinds = NIL;
		List   *attrKeys = NIL;
		List   *attrValues = NIL;

		if (pathNameMatchByPattern(strVal(path),
								   pattern,
								   &attrKinds,
								   &attrKeys,
								   &attrValues))
		{
			if (p_virtAttrsList)
			{
				List	   *vcdef_list = NIL;
				ListCell   *lc1, *lc2, *lc3;

				forthree (lc1, attrKinds,
						  lc2, attrKeys,
						  lc3, attrValues)
				{
					int			kind  = lfirst_int(lc1);
					const char *key   = lfirst(lc2);
					const char *value = lfirst(lc3);
					char	   *pos;
					virtualColumnDef *vcdef;

					vcdef = palloc(offsetof(virtualColumnDef, buf) +
								   strlen(key) + strlen(value) + 2);
					vcdef->kind = kind;
					pos = vcdef->buf;
					strcpy(pos, key);
					vcdef->key = pos;

					pos += strlen(key) + 1;
					strcpy(pos, value);
					vcdef->value = pos;

					vcdef_list = lappend(vcdef_list, vcdef);
				}
				attrsList = lappend(attrsList, vcdef_list);
			}
			results = lappend(results, path);

			list_free_deep(attrKeys);
			list_free_deep(attrValues);
		}
	}
	if (p_virtAttrsList)
	{
		Assert(list_length(results) == list_length(attrsList));
		*p_virtAttrsList = attrsList;
	}
	return results;
}

/*
 * arrowFdwExtractFilesList
 */
static List *
arrowFdwExtractFilesList(List *options_list,
						 List **p_virtAttrsList,
						 int *p_parallel_nworkers,
						 int *p_parquet_cache,
						 char *p_on_missing_fields)
{
	List	   *filesList = NIL;
	char	   *dir_path = NULL;
	char	   *dir_suffix = NULL;
	char	   *pattern = NULL;
	int			parallel_nworkers = -1;
	int			parquet_cache = -1;
	char		on_missing_fields = 'n';	/* default: as-null */
	ListCell   *lc;

	foreach (lc, options_list)
	{
		DefElem	   *defel = lfirst(lc);

		Assert(IsA(defel->arg, String));
		if (strcmp(defel->defname, "file") == 0)
		{
			char   *temp = strVal(defel->arg);

			if (access(temp, R_OK) != 0)
				elog(ERROR, "arrow_fdw: unable to access '%s': %m", temp);
			filesList = lappend(filesList, makeString(pstrdup(temp)));
		}
		else if (strcmp(defel->defname, "files") == 0)
		{
			const char *__files = strVal(defel->arg);
			char   *temp = (char *)alloca(strlen(__files) + 1);
			char   *tok, *pos;

			strcpy(temp, __files);
			for (tok = strtok_r(temp, ",", &pos);
				 tok != NULL;
				 tok = strtok_r(NULL, ",", &pos))
			{
				tok = __trim(tok);

				if (*tok != '/')
					elog(ERROR, "arrow_fdw: file '%s' must be absolute path", tok);
				if (access(tok, R_OK) != 0)
					elog(ERROR, "arrow_fdw: unable to access '%s': %m", tok);
				filesList = lappend(filesList, makeString(pstrdup(tok)));
			}
		}
		else if (strcmp(defel->defname, "dir") == 0)
		{
			dir_path = strVal(defel->arg);
			if (*dir_path != '/')
				elog(ERROR, "arrow_fdw: dir '%s' must be absolute path", dir_path);
		}
		else if (strcmp(defel->defname, "suffix") == 0)
		{
			dir_suffix = strVal(defel->arg);
		}
		else if (strcmp(defel->defname, "parallel_workers") == 0)
		{
			if (parallel_nworkers >= 0)
				elog(ERROR, "'parallel_workers' appeared twice");
			parallel_nworkers = defGetInt32(defel);
		}
		else if (strcmp(defel->defname, "pattern") == 0)
		{
			if (pattern)
				elog(ERROR, "'pattern' appeared twice");
			pattern = strVal(defel->arg);
		}
		else if (strcmp(defel->defname, "parquet_cache") == 0)
		{
			if (parquet_cache >= 0)
				elog(ERROR, "'parquet_cache' appeared twice");
			if (defGetBoolean(defel))
				parquet_cache = 1;
			else
				parquet_cache = 0;
		}
		else if (strcmp(defel->defname, "on_missing_fields") == 0)
		{
			const char *sval = defGetString(defel);

			if (strcmp(sval, "error") == 0)
				on_missing_fields = 'e';
			else if (strcmp(sval, "null") == 0)
				on_missing_fields = 'n';
			else
				elog(ERROR, "arrow: 'on_missing_fields' must be either 'error' or 'null'");
		}
		else
			elog(ERROR, "arrow: unknown option (%s)", defel->defname);
	}
	if (dir_suffix && !dir_path)
		elog(ERROR, "arrow: cannot use 'suffix' option without 'dir'");

	if (dir_path)
	{
		struct dirent *dentry;
		DIR	   *dir;
		char   *temp;

		dir = AllocateDir(dir_path);
		while ((dentry = ReadDir(dir, dir_path)) != NULL)
		{
			if (strcmp(dentry->d_name, ".") == 0 ||
				strcmp(dentry->d_name, "..") == 0)
				continue;
			if (dir_suffix)
			{
				char   *pos = strrchr(dentry->d_name, '.');

				if (!pos || strcmp(pos+1, dir_suffix) != 0)
					continue;
			}
			temp = psprintf("%s/%s", dir_path, dentry->d_name);
			if (access(temp, R_OK) != 0)
			{
				elog(DEBUG1, "arrow_fdw: unable to read '%s', so skipped", temp);
				continue;
			}
			filesList = lappend(filesList, makeString(temp));
		}
		FreeDir(dir);
	}
	/* exclude the file names by pattern */
	if (pattern)
	{
		filesList = arrowFdwExcludeFileNamesByPattern(filesList, pattern,
													  p_virtAttrsList);
	}
	else if (p_virtAttrsList)
	{
		/* add empty file attributes list for forboth() macro */
		List   *virtAttrsList = NIL;

		foreach (lc, filesList)
			virtAttrsList = lappend(virtAttrsList, NULL);
		*p_virtAttrsList = virtAttrsList;
	}
	if (p_parallel_nworkers)
		*p_parallel_nworkers = parallel_nworkers;
	if (p_parquet_cache)
		*p_parquet_cache = parquet_cache;
	if (p_on_missing_fields)
		*p_on_missing_fields = on_missing_fields;
	return filesList;
}

/*
 * arrowFdwExtractSourceFields
 */
static List *
arrowFdwExtractSourceFields(Relation frel, char on_missing_fields)
{
	Oid			frelid = RelationGetRelid(frel);
	TupleDesc	tupdesc = RelationGetDescr(frel);
	List	   *results = NIL;

	/* default missing fields policy */
	assert(on_missing_fields == 'e' || on_missing_fields == 'n');
	for (int j=0; j < tupdesc->natts; j++)
	{
		Form_pg_attribute attr = TupleDescAttr(tupdesc, j);
		List	   *options = GetForeignColumnOptions(frelid, attr->attnum);
		ListCell   *lc;
		const char *field_name = NULL;
		const char *virtual_key = NULL;
		const char *virtual_metadata = NULL;
		const char *virtual_metadata_split = NULL;
		char		__on_missing_field = on_missing_fields;	/* default */

		if (attr->attisdropped)
		{
			/* always NULL */
			results = lappend(results, "none");
			continue;
		}
		/* check column options to identify the source */
		foreach (lc, options)
		{
			DefElem *defel = lfirst(lc);

			Assert(IsA(defel->arg, String));
			if (strcmp(defel->defname, "field") == 0)
				field_name = strVal(defel->arg);
			else if (strcmp(defel->defname, "virtual") == 0)
				virtual_key = strVal(defel->arg);
			else if (strcmp(defel->defname, "virtual_metadata") == 0)
				virtual_metadata = strVal(defel->arg);
			else if (strcmp(defel->defname, "virtual_metadata_split") == 0)
				virtual_metadata_split = strVal(defel->arg);
			else if (strcmp(defel->defname, "on_missing_field") == 0)
			{
				const char *sval = strVal(defel->arg);

				if (strcmp(sval, "null") == 0)
					__on_missing_field = 'n';
				else if (strcmp(sval, "error") == 0)
					__on_missing_field = 'e';
				else
					elog(ERROR, "arrow_fdw: column option 'on_missing_field' must be either 'null' or 'error', but '%s' was supplied", sval);
			}
			else
			{
				elog(ERROR, "unknown foreign table options in '%s' of '%s'",
					 NameStr(attr->attname),
					 RelationGetRelationName(frel));
			}
		}
		if ((field_name != NULL ? 1 : 0) +
			(virtual_key != NULL ? 1 : 0) +
			(virtual_metadata != NULL ? 1 : 0) +
			(virtual_metadata_split != NULL ? 1 : 0) > 1)
			elog(ERROR, "arrow_fdw: column option 'field', 'virtual', 'virtual_metadata' and 'virtual_metadata_split' must be mutually exclusive");

		if (virtual_key)
			results = lappend(results, psprintf("virtual:%s", virtual_key));
		else if (virtual_metadata)
			results = lappend(results, psprintf("metadata:%s", virtual_metadata));
		else if (virtual_metadata_split)
			results = lappend(results, psprintf("metadata-split:%s", virtual_metadata_split));
		else
		{
			if (!field_name)
				field_name = NameStr(attr->attname);
			results = lappend(results,
							  psprintf(__on_missing_field == 'n'
									   ? "field-missing-null:%s"
									   : "field-missing-fail:%s", field_name));
		}
	}
	return results;
}

/* ----------------------------------------------------------------
 *
 * arrowFdwLoadRecordBatch() and related routines
 *
 * it setup KDS (ARROW format) with IOvec according to RecordBatchState
 *
 * ----------------------------------------------------------------
 */

/*
 * arrowFdwSetupIOvector
 */
typedef struct
{
	off_t		rb_offset;
	off_t		f_offset;
	off_t		m_offset;
	off_t		kds_head_sz;
	int32_t		depth;
	int32_t		io_index;
	strom_io_chunk ioc[FLEXIBLE_ARRAY_MEMBER];
} arrowFdwSetupIOContext;

static void
__setupIOvectorField(arrowFdwSetupIOContext *con,
					 uint32_t chunk_align,
					 off_t    chunk_offset,
					 size_t   chunk_length,
					 uint64_t *p_cmeta_offset,
					 uint64_t *p_cmeta_length)
{
	off_t		f_pos = con->rb_offset + chunk_offset;
	off_t		f_gap;
	off_t		f_base;
	off_t		m_offset;
	strom_io_chunk *ioc;

	/*
	 * Round up chunk_length to 64bit boundary.
	 * Apache Arrow does not require the chunk_length is aligned to 64bit boundary,
	 * chunk_offset must be aligned to 64bit (512bit recommended).
	 * So, some extra bytes (up to -7bytes) may improve the potency of i/o chunk
	 * consolication.
	 */

	if (f_pos >= con->f_offset &&
		(f_pos & ~PAGE_MASK) == (con->f_offset & ~PAGE_MASK))
	{
		/*
		 * we can consolidate the two i/o chunks, if file position of the next
		 * chunk (f_pos) and the current file tail position (con->f_offset) locate
		 * within the same file page, and gap bytes does not break alignment.
		 */
		f_gap = f_pos - con->f_offset;
		m_offset = con->m_offset + f_gap;

		if (m_offset == TYPEALIGN(chunk_align, con->m_offset))
		{
			/* put the gap bytes, if any */
			if (f_gap > 0)
			{
				con->m_offset += f_gap;
				con->f_offset += f_gap;
			}
			*p_cmeta_offset = con->kds_head_sz + con->m_offset;
			*p_cmeta_length = MAXALIGN(chunk_length);
			con->m_offset += chunk_length;
			con->f_offset += chunk_length;
			return;
		}
	}
	/*
	 * Elsewhere, we have to close the current i/o chunk once, then
	 * restart a new i/o chunk to load the disjoin chunks.
	 */
	if (con->io_index < 0)
		con->io_index = 0;		/* no current active i/o chunk */
	else
	{
		off_t	f_tail = PAGE_ALIGN(con->f_offset);

		ioc = &con->ioc[con->io_index++];
		ioc->nr_pages = (f_tail / PAGE_SIZE) - ioc->fchunk_id;
		con->m_offset += (f_tail - con->f_offset);	/* padding bytes */
	}

	f_base = PAGE_ALIGN_DOWN(f_pos);
	f_gap = f_pos - f_base;
	m_offset = TYPEALIGN(chunk_align, con->m_offset + f_gap);

	ioc = &con->ioc[con->io_index];
	ioc->m_offset = m_offset - f_gap;
	ioc->fchunk_id = f_base / PAGE_SIZE;

	*p_cmeta_offset = con->kds_head_sz + m_offset;
	*p_cmeta_length = MAXALIGN(chunk_length);
	con->m_offset = m_offset + chunk_length;
	con->f_offset = f_pos + chunk_length;
}

static void
arrowFdwSetupIOvectorField(arrowFdwSetupIOContext *con,
						   RecordBatchFieldState *rb_field,
						   kern_data_store *kds,
						   kern_colmeta *cmeta)
{
	//int		index = cmeta - kds->colmeta;

	if (rb_field->nullmap_length > 0)
	{
		Assert(rb_field->null_count > 0);
		__setupIOvectorField(con,
							 sizeof(int64_t),	/* 64bit alignment */
							 rb_field->nullmap_offset,
							 rb_field->nullmap_length,
							 &cmeta->nullmap_offset,
							 &cmeta->nullmap_length);
		//elog(INFO, "D%d att[%d] nullmap=%lu,%lu m_offset=%lu f_offset=%lu", con->depth, index, rb_field->nullmap_offset, rb_field->nullmap_length, con->m_offset, con->f_offset);
	}
	if (rb_field->values_length > 0)
	{
		__setupIOvectorField(con,
							 rb_field->attopts.align,
							 rb_field->values_offset,
							 rb_field->values_length,
							 &cmeta->values_offset,
							 &cmeta->values_length);
		//elog(INFO, "D%d att[%d] values=%lu,%lu m_offset=%lu f_offset=%lu", con->depth, index, rb_field->values_offset, rb_field->values_length, con->m_offset, con->f_offset);
	}
	if (rb_field->extra_length > 0)
	{
		__setupIOvectorField(con,
							 sizeof(int64_t),	/* 64bit alignment */
							 rb_field->extra_offset,
							 rb_field->extra_length,
							 &cmeta->extra_offset,
							 &cmeta->extra_length);
		//elog(INFO, "D%d att[%d] extra=%lu,%lu m_offset=%lu f_offset=%lu", con->depth, index, rb_field->extra_offset, rb_field->extra_length, con->m_offset, con->f_offset);
	}

	/* nested sub-fields if composite types */
	if (cmeta->atttypkind == TYPE_KIND__ARRAY ||
		cmeta->atttypkind == TYPE_KIND__COMPOSITE)
	{
		kern_colmeta *subattr;
		int		j;

		Assert(rb_field->num_children == cmeta->num_subattrs);
		con->depth++;
		for (j=0, subattr = &kds->colmeta[cmeta->idx_subattrs];
			 j < cmeta->num_subattrs;
			 j++, subattr++)
		{
			RecordBatchFieldState *child = &rb_field->children[j];

			arrowFdwSetupIOvectorField(con, child, kds, subattr);
		}
		con->depth--;
	}
}

static strom_io_vector *
arrowFdwSetupIOvector(RecordBatchState *rb_state,
					  Bitmapset *referenced,
					  kern_data_store *kds)
{
	ArrowFileState *af_state = rb_state->af_state;
	arrowFdwSetupIOContext *con;
	strom_io_vector *iovec;
	unsigned int	nr_chunks = 0;

	Assert(kds->format == KDS_FORMAT_ARROW &&
		   kds->ncols <= kds->nr_colmeta);
	con = alloca(offsetof(arrowFdwSetupIOContext,
						  ioc[3 * kds->nr_colmeta]));
	con->rb_offset = rb_state->rb_offset;
	con->f_offset  = ~0UL;	/* invalid offset */
	con->m_offset  = 0;
	con->kds_head_sz = KDS_HEAD_LENGTH(kds) + kds->arrow_virtual_usage;
	con->depth = 0;
	con->io_index = -1;		/* invalid index */
	for (int j=0; j < kds->ncols; j++)
	{
		kern_colmeta *cmeta = &kds->colmeta[j];
		int			attidx = j + 1 - FirstLowInvalidHeapAttributeNumber;

		if (bms_is_member(attidx, referenced) ||
			bms_is_member(-FirstLowInvalidHeapAttributeNumber, referenced))
		{
			int		field_index = af_state->attrs[j].field_index;

			if (field_index < 0)
			{
				/* !!!virtual column!!! */
				Assert(cmeta->virtual_offset != 0);
			}
			else
			{
				RecordBatchFieldState *rb_field = &rb_state->fields[field_index];

				arrowFdwSetupIOvectorField(con, rb_field, kds, cmeta);
			}
		}
		else
			cmeta->atttypkind = TYPE_KIND__NULL;	/* unreferenced */
	}
	if (con->io_index >= 0)
	{
		/* close the last I/O chunks */
		strom_io_chunk *ioc = &con->ioc[con->io_index++];

		ioc->nr_pages = (PAGE_ALIGN(con->f_offset) / PAGE_SIZE - ioc->fchunk_id);
		con->m_offset += PAGE_SIZE * ioc->nr_pages;
		nr_chunks = con->io_index;
	}
	kds->length = con->kds_head_sz + con->m_offset;

	iovec = palloc0(offsetof(strom_io_vector, ioc[nr_chunks]));
	iovec->nr_chunks = nr_chunks;
	if (iovec->nr_chunks > 0)
		memcpy(iovec->ioc, con->ioc, sizeof(strom_io_chunk) * con->io_index);
#if 0
	/* for debug - dump the i/o vector */
	{
		elog(INFO, "nchunks = %d", iovec->nr_chunks);
		for (int j=0; j < iovec->nr_chunks; j++)
		{
			strom_io_chunk *ioc = &iovec->ioc[j];

			elog(INFO, "io[%d] [ m_offset=%lu, f_read=%lu...%lu, nr_pages=%u}",
				 j,
				 ioc->m_offset,
				 ioc->fchunk_id * PAGE_SIZE,
				 (ioc->fchunk_id + ioc->nr_pages) * PAGE_SIZE,
				 ioc->nr_pages);
		}

		elog(INFO, "kds {length=%zu nitems=%u typeid=%u typmod=%u table_oid=%u}",
			 kds->length, kds->nitems,
			 kds->tdtypeid, kds->tdtypmod, kds->table_oid);
		for (int j=0; j < kds->nr_colmeta; j++)
		{
			kern_colmeta *cmeta = &kds->colmeta[j];

			elog(INFO, "%ccol[%d] nullmap=%lu,%lu values=%lu,%lu extra=%lu,%lu",
				 j < kds->ncols ? ' ' : '*', j,
				 cmeta->nullmap_offset,
				 cmeta->nullmap_length,
				 cmeta->values_offset,
				 cmeta->values_length,
				 cmeta->extra_offset,
				 cmeta->extra_length);
		}
	}
#endif
	return iovec;
}

/*
 * arrowFdwLoadRecordBatch
 */
static void
__arrowKdsAssignAttrOptions(kern_data_store *kds,
							kern_colmeta *cmeta,
							RecordBatchFieldState *rb_field)
{
	memcpy(&cmeta->attopts,
		   &rb_field->attopts, sizeof(ArrowTypeOptions));
	if (cmeta->atttypkind == TYPE_KIND__ARRAY)
	{
		Assert(cmeta->idx_subattrs >= kds->ncols &&
			   cmeta->num_subattrs == 1 &&
			   cmeta->idx_subattrs + cmeta->num_subattrs <= kds->nr_colmeta &&
			   rb_field->num_children == 1);
		__arrowKdsAssignAttrOptions(kds,
									&kds->colmeta[cmeta->idx_subattrs],
									&rb_field->children[0]);
	}
	else if (cmeta->atttypkind == TYPE_KIND__COMPOSITE)
	{
		Assert(cmeta->idx_subattrs >= kds->ncols &&
			   cmeta->num_subattrs == rb_field->num_children &&
			   cmeta->idx_subattrs + cmeta->num_subattrs <= kds->nr_colmeta);
		for (int j=0; j < cmeta->num_subattrs; j++)
		{
			__arrowKdsAssignAttrOptions(kds,
										&kds->colmeta[cmeta->idx_subattrs + j],
										&rb_field->children[j]);
		}
	}
}

static void
__arrowKdsAssignVirtualColumns(kern_data_store *kds,
							   kern_colmeta *cmeta,
							   bool virtual_isnull,
							   Datum virtual_datum,
							   LargeStringInfo chunk_buffer)
{
	if (virtual_isnull)
	{
		cmeta->virtual_offset = -1;
	}
	else
	{
		Assert(chunk_buffer->len == MAXALIGN(chunk_buffer->len));
		cmeta->virtual_offset = (chunk_buffer->data +
								 chunk_buffer->len - (char *)kds);
		if (cmeta->attbyval)
		{
			appendBinaryLargeStringInfo(chunk_buffer,
										(char *)&virtual_datum,
										cmeta->attlen);
		}
		else if (cmeta->attlen > 0)
		{
			appendBinaryLargeStringInfo(chunk_buffer,
										DatumGetPointer(virtual_datum),
										cmeta->attlen);
		}
		else if (cmeta->attlen == -1)
		{
			appendBinaryLargeStringInfo(chunk_buffer,
										DatumGetPointer(virtual_datum),
										VARSIZE_ANY(DatumGetPointer(virtual_datum)));
		}
		else
		{
			elog(ERROR, "unknown type length: %d", cmeta->attlen);
		}
		appendZeroLargeStringInfo(chunk_buffer, 0);
	}
}

static kern_data_store *
__arrowFdwSetupKDSHead(Relation relation,
					   Bitmapset *referenced,
					   RecordBatchState *rb_state,
					   LargeStringInfo chunk_buffer)
{
	ArrowFileState *af_state = rb_state->af_state;
	TupleDesc	tupdesc = RelationGetDescr(relation);
	size_t		head_off = chunk_buffer->len;
	char		kds_format = KDS_FORMAT_ARROW;
	bool		all_fields = bms_is_member(-FirstLowInvalidHeapAttributeNumber, referenced);
	int			nr_loads = 0;
	kern_data_store *kds;

	/*
	 * KDS buffer is marked as KDS_FORMAT_PARQUET if source file is
	 * apache parquet format; that does not support GPU-Direct SQL,
	 * and needs to load data chunks by CPU (libarrow/libparquet).
	 * Thus, it shall not have i/o vector, but filename and row-group
	 * index.
	 */
	if (ArrowMetadataVersionIsParquet(af_state->version))
		kds_format = KDS_FORMAT_PARQUET;

	/* setup KDS and I/O-vector */
	enlargeLargeStringInfo(chunk_buffer, estimate_kern_data_store(tupdesc));
	kds = (kern_data_store *)(chunk_buffer->data + head_off);
	setup_kern_data_store(kds, tupdesc, 0, kds_format);
	kds->nitems = rb_state->rb_nitems;
	kds->table_oid = RelationGetRelid(relation);
	chunk_buffer->len += KDS_HEAD_LENGTH(kds);

	Assert(kds->ncols == af_state->ncols);
	for (int j=0; j < kds->ncols; j++)
	{
		int		field_index = af_state->attrs[j].field_index;

		if (field_index >= 0)
		{
			int		k = j - FirstLowInvalidHeapAttributeNumber;

			Assert(field_index < rb_state->nfields);
			__arrowKdsAssignAttrOptions(kds,
										&kds->colmeta[j],
										&rb_state->fields[field_index]);
			if (all_fields || bms_is_member(k+1, referenced))
			{
				kds->colmeta[j].field_index = field_index;
				nr_loads++;
			}
			else
			{
				kds->colmeta[j].field_index = -1;	/* not referenced */
			}
		}
		else if (field_index == __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE)
		{
			__arrowKdsAssignVirtualColumns(kds,
										   &kds->colmeta[j],
										   af_state->attrs[j].virtual_isnull,
										   af_state->attrs[j].virtual_datum,
										   chunk_buffer);
			/*
			 * 'chunk_buffer' may be expanded during assignment of virtual
			 * columns, because repalloc() may change the base address,
			 * so kds must be refreshed.
			 */
			kds = (kern_data_store *)(chunk_buffer->data + head_off);
			kds->colmeta[j].field_index = -1;		/* no physical field */
		}
		else if (field_index < __FIELD_INDEX_SPECIAL__VIRTUAL_PER_FILE)
		{
			int		k = __FIELD_INDEX_SPECIAL__VIRTUAL_PER_RECORD_BATCH(field_index);

			assert(k >= 0 && k < rb_state->virtual_nitems);
			__arrowKdsAssignVirtualColumns(kds,
										   &kds->colmeta[j],
										   rb_state->virtual_isnull[k],
										   rb_state->virtual_values[k],
										   chunk_buffer);
			/* see the comment above */
			kds = (kern_data_store *)(chunk_buffer->data + head_off);
			kds->colmeta[j].field_index = -1;		/* no physical field */
		}
		else
		{
			elog(ERROR, "Bug? unexpected field-index (%d)", field_index);
		}
	}
	/*
	 * Special parameter setting for Parquet mode
	 */
	if (kds_format == KDS_FORMAT_PARQUET)
	{
		/*
		 * turn on multi-threading read of parquet::arrow::FileReader,
		 * if number of columns exceeds the threshold. (in case when small
		 * number of columns are loaded, multi-threading is not efficient
		 * so much.)
		 */
		if (parquet_parallel_read_threshold >= 0 &&
			nr_loads >= parquet_parallel_read_threshold)
			kds->parquet_parallel_load = true;
		/*
		 * User can control usage of Parquet-cache
		 */
		if (af_state->parquet_cache == 0)
			kds->parquet_cache_enabled = false;
		else if (af_state->parquet_cache > 0)
			kds->parquet_cache_enabled = true;
		else
			kds->parquet_cache_enabled = default_parquet_cache_enabled;
	}
	kds->parquet_row_group = rb_state->rb_index;
	kds->arrow_virtual_usage = (chunk_buffer->len
								- (head_off + KDS_HEAD_LENGTH(kds)));
	return kds;
}

static inline strom_io_vector *
arrowFdwLoadRecordBatch(Relation relation,
						Bitmapset *referenced,
						RecordBatchState *rb_state,
						LargeStringInfo chunk_buffer)
{
	kern_data_store *kds = __arrowFdwSetupKDSHead(relation,
												  referenced,
												  rb_state,
												  chunk_buffer);
	return arrowFdwSetupIOvector(rb_state, referenced, kds);
}

static kern_data_store *
arrowFdwFillupRecordBatch(Relation relation,
						  Bitmapset *referenced,
						  RecordBatchState *rb_state,
						  LargeStringInfo chunk_buffer)
{
	ArrowFileState	*af_state = rb_state->af_state;
	kern_data_store	*kds;
	strom_io_vector	*iovec;
	char	   *base;
	File		filp;

	resetLargeStringInfo(chunk_buffer);
	iovec = arrowFdwLoadRecordBatch(relation,
									referenced,
									rb_state,
									chunk_buffer);
	kds = (kern_data_store *)chunk_buffer->data;
	enlargeLargeStringInfo(chunk_buffer, kds->length);
	kds = (kern_data_store *)chunk_buffer->data;
	filp = PathNameOpenFile(af_state->filename, O_RDONLY | PG_BINARY);
	base = (char *)kds + KDS_HEAD_LENGTH(kds) + kds->arrow_virtual_usage;
	for (int i=0; i < iovec->nr_chunks; i++)
	{
		strom_io_chunk *ioc = &iovec->ioc[i];
		char	   *dest = base + ioc->m_offset;
		off_t		f_pos = (size_t)ioc->fchunk_id * PAGE_SIZE;
		size_t		len = (size_t)ioc->nr_pages * PAGE_SIZE;
		ssize_t		sz;

		while (len > 0)
		{
			CHECK_FOR_INTERRUPTS();

			sz = FileRead(filp, dest, len, f_pos,
						  WAIT_EVENT_REORDER_BUFFER_READ);
			if (sz > 0)
			{
				Assert(sz <= len);
				dest  += sz;
				f_pos += sz;
				len   -= sz;
			}
			else if (sz == 0)
			{
				/*
				 * Due to the page_sz alignment, we may try to read the file
				 * over its tail. So, pread(2) may tell us unable to read
				 * any more. The expected scenario happend only when remained
				 * length is less than PAGE_SIZE.
				 */
				memset(dest, 0, len);
				break;
			}
			else if (errno != EINTR)
			{
				assert(false);
				elog(ERROR, "failed on FileRead('%s', pos=%lu, len=%lu): %m",
					 af_state->filename, f_pos, len);
			}
		}
	}
	chunk_buffer->len += kds->length;
	FileClose(filp);

	pfree(iovec);

	return kds;
}

/*
 * parquetFillupRowGroup
 */
static void *
__parquetFillupAllocBuffer(void *__priv, size_t sz)
{
	LargeStringInfo buf = __priv;
	void	   *result;

	PG_TRY();
	{
		enlargeLargeStringInfo(buf, sz);
		result = buf->data + buf->len;
	}
	PG_CATCH();
	{
		/* should not raise longjump during C++ code execution */
		FlushErrorState();
		result = NULL;
	}
	PG_END_TRY();

	return result;
}

static kern_data_store *
parquetFillupRowGroup(Relation relation,
					  Bitmapset *referenced,
					  RecordBatchState *rb_state,
					  LargeStringInfo chunk_buffer)
{
	kern_data_store *kds_head;
	kern_data_store *kds;
	uint32_t	npages_direct_read = 0;
	uint32_t	npages_vfs_read = 0;
	uint32_t	nchunks_parquet_read = 0;
	uint32_t	ncaches_parquet_load = 0;
	char		error_message[320];

	/* prepare the KDS buffer */
	resetLargeStringInfo(chunk_buffer);
	__arrowFdwSetupKDSHead(relation, referenced, rb_state, chunk_buffer);
	kds_head = alloca(chunk_buffer->len);
	memcpy(kds_head, chunk_buffer->data, chunk_buffer->len);
	Assert(kds_head->format == KDS_FORMAT_PARQUET);

	/* read a row-group of the Parquet file */
	resetLargeStringInfo(chunk_buffer);
	kds = parquetReadOneRowGroup(rb_state->af_state->filename,
								 kds_head,
								 __parquetFillupAllocBuffer,
								 (void *)chunk_buffer,
								 &npages_direct_read,
								 &npages_vfs_read,
								 &nchunks_parquet_read,
								 &ncaches_parquet_load,
								 error_message,
								 sizeof(error_message));
	if (!kds)
		elog(ERROR, "Unable to load row-group %d of the parquet file '%s': %s",
			 rb_state->rb_index,
			 rb_state->af_state->filename,
			 error_message);
	return kds;
}

/*
 * disk_cost_arrow_fdw
 */
Cost
disk_cost_arrow_fdw(PlannerInfo *root,
					RelOptInfo *baserel,
					double *p_setup_cost)
{
	/*
	 * Arrow- and Parquet-style columnar formats reduce disk I/O by loading only
	 * the columns actually referenced by a query. Nevertheless, when generating
	 * query execution plans, there is currently no case in which one candidate
	 * plan would load a referenced column X while another candidate plan would
	 * avoid loading that same column. Therefore, adjusting disk_cost based
	 * on the set or number of referenced columns is not meaningful in the current
	 * implementation.
	 * For this reason, arrow_fdw does not make disk_cost depend on the number of
	 * referenced columns.
	 * This may change in a future revision of the design.
	 */
	double	spc_seq_page_cost;

	get_tablespace_page_costs(baserel->reltablespace,
							  NULL,
							  &spc_seq_page_cost);
	return (double)baserel->pages *
		(spc_seq_page_cost * (1.0 - baserel->allvisfrac) +
		 pgstrom_gpu_direct_seq_page_cost * baserel->allvisfrac);
}

/*
 * ArrowGetForeignRelSize
 */
static void
ArrowGetForeignRelSize(PlannerInfo *root,
					   RelOptInfo *baserel,
					   Oid foreigntableid)
{
	ForeignTable   *ft = GetForeignTable(foreigntableid);
	Relation		frel = table_open(foreigntableid, NoLock);
	List		   *filesList;
	List		   *sourceFields;
	List		   *virtualColumnsList;
	List		   *results = NIL;
	Bitmapset	   *referenced;
	ListCell	   *lc1, *lc2;
	size_t			vfs_length = 0;
	size_t			gds_length = 0;
	double			ntuples = 0.0;
	double			allvisfrac = 0.0;
	int				parallel_nworkers;
	int				parquet_cache;
	char			on_missing_fields;

	/* columns to be referenced */
	referenced = pickup_outer_referenced(root, baserel);
	foreach (lc1, baserel->baserestrictinfo)
	{
		RestrictInfo   *rinfo = lfirst(lc1);

		pull_varattnos((Node *)rinfo->clause, baserel->relid, &referenced);
	}

	/* read arrow-file metadta */
	filesList = arrowFdwExtractFilesList(ft->options,
										 &virtualColumnsList,
										 &parallel_nworkers,
										 &parquet_cache,
										 &on_missing_fields);
	sourceFields = arrowFdwExtractSourceFields(frel, on_missing_fields);
	forboth (lc1, filesList,
			 lc2, virtualColumnsList)
	{
		ArrowFileState *af_state;
		const char *fname = strVal(lfirst(lc1));
		List	   *virtual_columns = lfirst(lc2);
		ListCell   *cell;

		af_state = BuildArrowFileState(frel, fname,
									   sourceFields,
									   virtual_columns,
									   parquet_cache,
									   NULL);
		if (!af_state)
			continue;

		/*
		 * Size calculation based the record-batch metadata
		 */
		foreach (cell, af_state->rb_list)
		{
			RecordBatchState *rb_state = lfirst(cell);
			gpumask_t		__optimal_gpus;
			size_t			__length = 0;

			//XXX - fix to support column-field mapping

			/* whole-row reference? */
			if (bms_is_member(-FirstLowInvalidHeapAttributeNumber, referenced))
			{
				__length += rb_state->rb_length;
			}
			else
			{
				int		i, j, k;

				for (k = bms_next_member(referenced, -1);
					 k >= 0;
					 k = bms_next_member(referenced, k))
				{
					j = k + FirstLowInvalidHeapAttributeNumber;
					if (j <= 0 || j > af_state->ncols)
						continue;
					i = af_state->attrs[j-1].field_index;
					if (i >= 0 && i < rb_state->nfields)
						__length += rb_state->fields[i].disk_length;
				}
			}
			ntuples += rb_state->rb_nitems;
			/* Is GPU-Direct SQL supported? */
			__optimal_gpus = GetOptimalGpuForFile(af_state->filename);
			if (__optimal_gpus == 0 || __optimal_gpus == INVALID_GPUMASK)
				vfs_length += __length;
			else
				gds_length += __length;
		}
		results = lappend(results, af_state);
	}
	table_close(frel, NoLock);

	/* setup baserel */
	if (vfs_length + gds_length > 0)
		allvisfrac = (double)gds_length / (double)(vfs_length + gds_length);

	baserel->rel_parallel_workers = parallel_nworkers;
	baserel->fdw_private = list_make2(results, referenced);
	baserel->pages = (vfs_length + gds_length + BLCKSZ - 1) / BLCKSZ;
	baserel->tuples = ntuples;
	baserel->allvisfrac = allvisfrac;
	baserel->rows = ntuples *
		clauselist_selectivity(root,
							   baserel->baserestrictinfo,
							   0,
							   JOIN_INNER,
							   NULL);
}

/*
 * cost_arrow_fdw_seqscan
 */
static void
cost_arrow_fdw_seqscan(Path *path,
					   PlannerInfo *root,
					   RelOptInfo *baserel,
					   ParamPathInfo *param_info,
					   int num_workers)
{
	Cost		startup_cost = 0.0;
	Cost		disk_run_cost = 0.0;
	Cost		cpu_run_cost = 0.0;
	QualCost	qcost;
	double		nrows;
	double		spc_seq_page_cost;

	if (param_info)
		nrows = param_info->ppi_rows;
	else
		nrows = baserel->rows;

	/* arrow_fdw.enabled */
	if (!arrow_fdw_enabled)
		startup_cost += disable_cost;

	/*
	 * Storage costs
	 *
	 * XXX - smaller number of columns to read shall have less disk cost
	 * because of columnar format. Right now, we don't discount cost for
	 * the pages not to be read.
	 */
	get_tablespace_page_costs(baserel->reltablespace,
							  NULL,
							  &spc_seq_page_cost);
	disk_run_cost = spc_seq_page_cost * baserel->pages;

	/* CPU costs */
	if (param_info)
	{
		cost_qual_eval(&qcost, param_info->ppi_clauses, root);
		qcost.startup += baserel->baserestrictcost.startup;
        qcost.per_tuple += baserel->baserestrictcost.per_tuple;
	}
	else
		qcost = baserel->baserestrictcost;
	startup_cost += qcost.startup;
	cpu_run_cost = (cpu_tuple_cost + qcost.per_tuple) * baserel->tuples;

	/* tlist evaluation costs */
	startup_cost += path->pathtarget->cost.startup;
	cpu_run_cost += path->pathtarget->cost.per_tuple * path->rows;

	/* adjust cost for CPU parallelism */
	if (num_workers > 0)
	{
		double		leader_contribution;
		double		parallel_divisor = (double) num_workers;

		/* see get_parallel_divisor() */
		leader_contribution = 1.0 - (0.3 * (double)num_workers);
		parallel_divisor += Max(leader_contribution, 0.0);

		/* The CPU cost is divided among all the workers. */
		cpu_run_cost /= parallel_divisor;

		/* Estimated row count per background worker process */
		nrows = clamp_row_est(nrows / parallel_divisor);
	}
	path->rows = nrows;
	path->startup_cost = startup_cost;
	path->total_cost = startup_cost + cpu_run_cost + disk_run_cost;
	path->parallel_workers = num_workers;
}

/*
 * ArrowGetForeignPaths
 */
static void
ArrowGetForeignPaths(PlannerInfo *root,
                     RelOptInfo *baserel,
                     Oid foreigntableid)
{
	ForeignPath	   *fpath;
	ParamPathInfo  *param_info;
	Relids			required_outer = baserel->lateral_relids;

	param_info = get_baserel_parampathinfo(root, baserel, required_outer);
	fpath = create_foreignscan_path(root,
									baserel,
									NULL,	/* default pathtarget */
									-1.0,	/* dummy */
									arrow_fdw_enabled ? 1 : 0,	/* disabled_nodes */
									-1.0,	/* dummy */
									-1.0,	/* dummy */
									NIL,	/* no pathkeys */
									required_outer,
									NULL,	/* no extra plan */
									NIL,	/* no restrict-info of Join push-down */
									NIL);	/* no particular private */
	cost_arrow_fdw_seqscan(&fpath->path,
						   root,
						   baserel,
						   param_info, 0);
	add_path(baserel, &fpath->path);

	if (baserel->consider_parallel)
	{
		int		num_workers =
			compute_parallel_worker(baserel,
									baserel->pages, -1.0,
									max_parallel_workers_per_gather);
		if (num_workers == 0)
			return;

		fpath = create_foreignscan_path(root,
										baserel,
										NULL,	/* default pathtarget */
										-1.0,	/* dummy */
										arrow_fdw_enabled ? 0 : 1,	/* disabled_nodes */
										-1.0,	/* dummy */
										-1.0,	/* dummy */
										NIL,	/* no pathkeys */
										required_outer,
										NULL,	/* no extra plan */
										NIL,	/* no restrict-info of Join push-down */
										NIL);	/* no particular private */
		fpath->path.parallel_aware = true;
		fpath->path.parallel_workers = num_workers;
		cost_arrow_fdw_seqscan(&fpath->path,
							   root,
							   baserel,
							   param_info,
							   num_workers);
		add_partial_path(baserel, (Path *)fpath);
	}
}

/*
 * ArrowGetForeignPlan
 */
static ForeignScan *
ArrowGetForeignPlan(PlannerInfo *root,
					RelOptInfo *baserel,
					Oid foreigntableid,
					ForeignPath *best_path,
					List *tlist,
					List *scan_clauses,
					Plan *outer_plan)
{
	Bitmapset  *referenced = lsecond(baserel->fdw_private);
	List	   *ref_list = NIL;
	int			k;

	for (k = bms_next_member(referenced, -1);
		 k >= 0;
		 k = bms_next_member(referenced, k))
	{
		ref_list = lappend_int(ref_list, k);
	}
	return make_foreignscan(tlist,
							extract_actual_clauses(scan_clauses, false),
							baserel->relid,
							NIL,	/* no expressions to evaluate */
							ref_list, /* list of referenced attnums */
							NIL,	/* no custom tlist */
							NIL,	/* no remote quals */
							outer_plan);
}

/* ----------------------------------------------------------------
 *
 * Routines related to Arrow datum fetch
 *
 * ----------------------------------------------------------------
 */
static void		pg_datum_arrow_ref(kern_data_store *kds,
								   kern_colmeta *cmeta,
								   size_t index,
								   Datum *p_datum,
								   bool *p_isnull);
static Datum
pg_varlena32_arrow_ref(kern_data_store *kds,
					   kern_colmeta *cmeta,
					   size_t index, bool *p_isnull)
{
	struct varlena *res = NULL;
	const void *addr;
	int			length;

	addr = KDS_ARROW_REF_VARLENA32_DATUM(kds, cmeta, index, &length);
	if (!addr)
		*p_isnull = true;
	else
	{
		*p_isnull = false;
		res = palloc(VARHDRSZ + length);
		memcpy(res->vl_dat, addr, length);
		SET_VARSIZE(res, VARHDRSZ + length);
	}
	return PointerGetDatum(res);
}

static Datum
pg_varlena64_arrow_ref(kern_data_store *kds,
					   kern_colmeta *cmeta,
					   size_t index, bool *p_isnull)
{
	struct varlena *res = NULL;
	const void *addr;
	int			length;

	addr = KDS_ARROW_REF_VARLENA64_DATUM(kds, cmeta, index, &length);
	if (!addr)
		*p_isnull = true;
	else
	{
		*p_isnull = false;
		res = palloc(VARHDRSZ + length);
		memcpy(res->vl_dat, addr, length);
		SET_VARSIZE(res, VARHDRSZ + length);
	}
	return PointerGetDatum(res);
}

static Datum
pg_bpchar_arrow_ref(kern_data_store *kds,
					kern_colmeta *cmeta, size_t index)
{
	char	   *values = ((char *)kds + cmeta->values_offset);
	size_t		length = cmeta->values_length;
	int32_t		unitsz = cmeta->attopts.fixed_size_binary.byteWidth;
	struct varlena *res;

	if (unitsz <= 0)
		elog(ERROR, "CHAR(%d) is not expected", unitsz);
	if (unitsz * index >= length)
		elog(ERROR, "corruption? bpchar points out of range");
	res = palloc(VARHDRSZ + unitsz);
	memcpy((char *)res + VARHDRSZ, values + unitsz * index, unitsz);
	SET_VARSIZE(res, VARHDRSZ + unitsz);

	return PointerGetDatum(res);
}

static Datum
pg_bool_arrow_ref(kern_data_store *kds,
				  kern_colmeta *cmeta, size_t index)
{
	uint8_t	   *bitmap = (uint8_t *)kds + cmeta->values_offset;
	size_t		length = cmeta->values_length;
	bool		rv;

	if (sizeof(uint8_t) * (index>>3) >= length)
		elog(ERROR, "corruption? bool points out of range");
	rv = ((bitmap[index>>3] & (1<<(index&7))) != 0);
	return BoolGetDatum(rv);
}

static Datum
pg_simple_arrow_ref(kern_data_store *kds,
					kern_colmeta *cmeta, size_t index)
{
	int32_t		unitsz = cmeta->attopts.unitsz;
	char	   *values = (char *)kds + cmeta->values_offset;
	size_t		length = cmeta->values_length;
	Datum		retval = 0;

	Assert(unitsz > 0 && unitsz <= sizeof(Datum));
	if (unitsz * index >= length)
		elog(ERROR, "corruption? simple int8 points out of range");
	memcpy(&retval, values + unitsz * index, unitsz);
	return retval;
}

static Datum
pg_numeric_arrow_ref(kern_data_store *kds,
					 kern_colmeta *cmeta, size_t index)
{
	char	   *result = palloc0(sizeof(struct NumericData));
	char	   *base = (char *)kds + cmeta->values_offset;
	size_t		length = cmeta->values_length;
	int			dscale = cmeta->attopts.decimal.scale;
	uint8_t		kind = XPU_NUMERIC_KIND__VALID;
	int128_t	ival;

	if (sizeof(int128_t) * index >= length)
		elog(ERROR, "corruption? numeric points out of range");
	ival = ((int128_t *)base)[index];
	__decimal_to_varlena(result, kind, dscale, ival);

	return PointerGetDatum(result);
}

static Datum
pg_date_arrow_ref(kern_data_store *kds,
				  kern_colmeta *cmeta, size_t index)
{
	char	   *base = (char *)kds + cmeta->values_offset;
	size_t		length = cmeta->values_length;
	DateADT		dt;

	switch (cmeta->attopts.date.unit)
	{
		case ArrowDateUnit__Day:
			if (sizeof(uint32) * index >= length)
				elog(ERROR, "corruption? Date[day] points out of range");
			dt = ((uint32 *)base)[index];
			break;
		case ArrowDateUnit__MilliSecond:
			if (sizeof(uint64) * index >= length)
				elog(ERROR, "corruption? Date[ms] points out of range");
			dt = ((uint64 *)base)[index] / 1000;
			break;
		default:
			elog(ERROR, "Bug? unexpected unit of Date type");
	}
	/* convert UNIX epoch to PostgreSQL epoch */
	dt -= (POSTGRES_EPOCH_JDATE - UNIX_EPOCH_JDATE);
	return DateADTGetDatum(dt);
}

static Datum
pg_time_arrow_ref(kern_data_store *kds,
				  kern_colmeta *cmeta, size_t index)
{
	char	   *base = (char *)kds + cmeta->values_offset;
	size_t		length = cmeta->values_length;
	TimeADT		tm;

	switch (cmeta->attopts.time.unit)
	{
		case ArrowTimeUnit__Second:
			if (sizeof(uint32) * index >= length)
				elog(ERROR, "corruption? Time[sec] points out of range");
			tm = ((uint32 *)base)[index] * 1000000L;
			break;
		case ArrowTimeUnit__MilliSecond:
			if (sizeof(uint32) * index >= length)
				elog(ERROR, "corruption? Time[ms] points out of range");
			tm = ((uint32 *)base)[index] * 1000L;
			break;
		case ArrowTimeUnit__MicroSecond:
			if (sizeof(uint64) * index >= length)
				elog(ERROR, "corruption? Time[us] points out of range");
			tm = ((uint64 *)base)[index];
			break;
		case ArrowTimeUnit__NanoSecond:
			if (sizeof(uint64) * index >= length)
				elog(ERROR, "corruption? Time[ns] points out of range");
			tm = ((uint64 *)base)[index] / 1000L;
			break;
		default:
			elog(ERROR, "Bug? unexpected unit of Time type");
			break;
	}
	return TimeADTGetDatum(tm);
}

static Datum
pg_timestamp_arrow_ref(kern_data_store *kds,
					   kern_colmeta *cmeta, size_t index)
{
	char	   *base = (char *)kds + cmeta->values_offset;
	size_t		length = cmeta->values_length;
	Timestamp	ts;

	switch (cmeta->attopts.timestamp.unit)
	{
		case ArrowTimeUnit__Second:
			if (sizeof(uint64) * index >= length)
				elog(ERROR, "corruption? Timestamp[sec] points out of range");
			ts = ((uint64 *)base)[index] * 1000000UL;
			break;
		case ArrowTimeUnit__MilliSecond:
			if (sizeof(uint64) * index >= length)
				elog(ERROR, "corruption? Timestamp[ms] points out of range");
			ts = ((uint64 *)base)[index] * 1000UL;
			break;
		case ArrowTimeUnit__MicroSecond:
			if (sizeof(uint64) * index >= length)
				elog(ERROR, "corruption? Timestamp[us] points out of range");
			ts = ((uint64 *)base)[index];
			break;
		case ArrowTimeUnit__NanoSecond:
			if (sizeof(uint64) * index >= length)
				elog(ERROR, "corruption? Timestamp[ns] points out of range");
			ts = ((uint64 *)base)[index] / 1000UL;
			break;
		default:
			elog(ERROR, "Bug? unexpected unit of Timestamp type");
			break;
	}
	/* convert UNIX epoch to PostgreSQL epoch */
	ts -= (POSTGRES_EPOCH_JDATE -
		   UNIX_EPOCH_JDATE) * USECS_PER_DAY;
	return TimestampGetDatum(ts);
}

static Datum
pg_interval_arrow_ref(kern_data_store *kds,
					  kern_colmeta *cmeta, size_t index)
{
	char	   *base = (char *)kds + cmeta->values_offset;
	size_t		length = cmeta->values_length;
	Interval   *iv = palloc0(sizeof(Interval));

	switch (cmeta->attopts.interval.unit)
	{
		case ArrowIntervalUnit__Year_Month:
			/* 32bit: number of months */
			if (sizeof(uint32) * index >= length)
				elog(ERROR, "corruption? Interval[Year/Month] points out of range");
			iv->month = ((uint32 *)base)[index];
			break;
		case ArrowIntervalUnit__Day_Time:
			/* 32bit+32bit: number of days and milliseconds */
			if (2 * sizeof(uint32) * index >= length)
				elog(ERROR, "corruption? Interval[Day/Time] points out of range");
			iv->day  = ((int32 *)base)[2 * index];
			iv->time = ((int32 *)base)[2 * index + 1] * 1000;
			break;
		default:
			elog(ERROR, "Bug? unexpected unit of Interval type");
	}
	return PointerGetDatum(iv);
}

static Datum
pg_macaddr_arrow_ref(kern_data_store *kds,
					 kern_colmeta *cmeta, size_t index)
{
	char   *base = (char *)kds + cmeta->values_offset;
	size_t	length = cmeta->values_length;

	if (cmeta->attopts.fixed_size_binary.byteWidth != sizeof(macaddr))
		elog(ERROR, "Bug? wrong FixedSizeBinary::byteWidth(%d) for macaddr",
			 cmeta->attopts.fixed_size_binary.byteWidth);
	if (sizeof(macaddr) * index >= length)
		elog(ERROR, "corruption? Binary[macaddr] points out of range");

	return PointerGetDatum(base + sizeof(macaddr) * index);
}

static Datum
pg_inet_arrow_ref(kern_data_store *kds,
				  kern_colmeta *cmeta, size_t index)
{
	char   *base = (char *)kds + cmeta->values_offset;
	size_t	length = cmeta->values_length;
	inet   *ip = palloc(sizeof(inet));

	if (cmeta->attopts.fixed_size_binary.byteWidth == 4)
	{
		if (4 * index >= length)
			elog(ERROR, "corruption? Binary[inet4] points out of range");
		ip->inet_data.family = PGSQL_AF_INET;
		ip->inet_data.bits = 32;
		memcpy(ip->inet_data.ipaddr, base + 4 * index, 4);
	}
	else if (cmeta->attopts.fixed_size_binary.byteWidth == 16)
	{
		if (16 * index >= length)
			elog(ERROR, "corruption? Binary[inet6] points out of range");
		ip->inet_data.family = PGSQL_AF_INET6;
		ip->inet_data.bits = 128;
		memcpy(ip->inet_data.ipaddr, base + 16 * index, 16);
	}
	else
		elog(ERROR, "Bug? wrong FixedSizeBinary::byteWidth(%d) for inet",
			 cmeta->attopts.fixed_size_binary.byteWidth);

	SET_INET_VARSIZE(ip);
	return PointerGetDatum(ip);
}

static Datum
pg_array_arrow_ref(kern_data_store *kds,
				   kern_colmeta *smeta,
				   uint32_t start, uint32_t end)
{
	ArrayType  *res;
	size_t		sz;
	uint32_t	i, nitems = end - start;
	uint8	   *nullmap = NULL;
	size_t		usage, __usage;

	/* sanity checks */
	if (start > end)
		elog(ERROR, "Bug? array index has reversed order [%u..%u]", start, end);

	/* allocation of the result buffer */
	if (smeta->nullmap_offset != 0)
		sz = ARR_OVERHEAD_WITHNULLS(1, nitems);
	else
		sz = ARR_OVERHEAD_NONULLS(1);

	if (smeta->attlen > 0)
	{
		sz += TYPEALIGN(smeta->attalign,
						smeta->attlen) * nitems;
	}
	else if (smeta->attlen == -1)
	{
		sz += 400;		/* tentative allocation */
	}
	else
		elog(ERROR, "Bug? corrupted kernel column metadata");

	res = palloc0(sz);
	res->ndim = 1;
	if (smeta->nullmap_offset != 0)
	{
		res->dataoffset = ARR_OVERHEAD_WITHNULLS(1, nitems);
		nullmap = ARR_NULLBITMAP(res);
	}
	res->elemtype = smeta->atttypid;
	ARR_DIMS(res)[0] = nitems;
	ARR_LBOUND(res)[0] = 1;
	usage = ARR_DATA_OFFSET(res);
	for (i=0; i < nitems; i++)
	{
		Datum	datum;
		bool	isnull;

		pg_datum_arrow_ref(kds, smeta, start+i, &datum, &isnull);
		if (isnull)
		{
			if (!nullmap)
				elog(ERROR, "Bug? element item should not be NULL");
		}
		else if (smeta->attlen > 0)
		{
			if (nullmap)
				nullmap[i>>3] |= (1<<(i&7));
			__usage = TYPEALIGN(smeta->attalign, usage);
			while (__usage + smeta->attlen > sz)
			{
				sz += sz;
				res = repalloc(res, sz);
			}
			if (__usage > usage)
				memset((char *)res + usage, 0, __usage - usage);
			memcpy((char *)res + __usage, &datum, smeta->attlen);
			usage = __usage + smeta->attlen;
		}
		else if (smeta->attlen == -1)
		{
			int32_t		vl_len = VARSIZE(DatumGetPointer(datum));

			if (nullmap)
				nullmap[i>>3] |= (1<<(i&7));
			__usage = TYPEALIGN(smeta->attalign, usage);
			while (__usage + vl_len > sz)
			{
				sz += sz;
				res = repalloc(res, sz);
			}
			if (__usage > usage)
				memset((char *)res + usage, 0, __usage - usage);
			memcpy((char *)res + __usage, DatumGetPointer(datum), vl_len);
			usage = __usage + vl_len;

			pfree(DatumGetPointer(datum));
		}
		else
			elog(ERROR, "Bug? corrupted kernel column metadata");
	}
	SET_VARSIZE(res, usage);

	return PointerGetDatum(res);
}

/*
 * pg_datum_arrow_ref
 */
static void
pg_datum_arrow_ref(kern_data_store *kds,
				   kern_colmeta *cmeta,
				   size_t index,
				   Datum *p_datum,
				   bool *p_isnull)
{
	Datum		datum = 0;
	bool		isnull = false;

	if (cmeta->virtual_offset != 0)
	{
		if (cmeta->virtual_offset < 0)
			isnull = true;
		else if (cmeta->attbyval)
		{
			void   *addr = ((char *)kds + cmeta->virtual_offset);

			switch (cmeta->attlen)
			{
				case 1:	datum = *((uint8_t  *)addr); break;
				case 2: datum = *((uint16_t *)addr); break;
				case 4: datum = *((uint32_t *)addr); break;
				case 8: datum = *((uint64_t *)addr); break;
				default:
					elog(ERROR, "unexpected inline type length: %d", cmeta->attlen);
			}
		}
		else
			datum = PointerGetDatum((char *)kds + cmeta->virtual_offset);
		goto out;
	}

	if (KDS_ARROW_CHECK_ISNULL(kds, cmeta, index))
	{
		isnull = true;
		goto out;
	}

	switch (cmeta->attopts.tag)
	{
		case ArrowType__Int:
		case ArrowType__FloatingPoint:
			datum = pg_simple_arrow_ref(kds, cmeta, index);
			break;
		case ArrowType__Bool:
			datum = pg_bool_arrow_ref(kds, cmeta, index);
			break;
		case ArrowType__Decimal:
			datum = pg_numeric_arrow_ref(kds, cmeta, index);
			break;
		case ArrowType__Date:
			datum = pg_date_arrow_ref(kds, cmeta, index);
			break;
		case ArrowType__Time:
			datum = pg_time_arrow_ref(kds, cmeta, index);
			break;
		case ArrowType__Timestamp:
			datum = pg_timestamp_arrow_ref(kds, cmeta, index);
			break;
		case ArrowType__Interval:
			datum = pg_interval_arrow_ref(kds, cmeta, index);
			break;
		case ArrowType__Utf8:
		case ArrowType__Binary:
			datum = pg_varlena32_arrow_ref(kds, cmeta, index, &isnull);
			break;
		case ArrowType__LargeUtf8:
		case ArrowType__LargeBinary:
			datum = pg_varlena64_arrow_ref(kds, cmeta, index, &isnull);
			break;

		case ArrowType__FixedSizeBinary:
			switch (cmeta->atttypid)
			{
				case MACADDROID:
					datum = pg_macaddr_arrow_ref(kds, cmeta, index);
					break;
				case INETOID:
					datum = pg_inet_arrow_ref(kds, cmeta, index);
					break;
				case BPCHAROID:
					datum = pg_bpchar_arrow_ref(kds, cmeta, index);
					break;
				default:
					elog(ERROR, "unknown FixedSizeBinary mapping");
					break;
			}
			break;
			
		case ArrowType__List:
			{
				kern_colmeta   *smeta;
				uint32_t	   *offset;

				if (cmeta->num_subattrs != 1 ||
					cmeta->idx_subattrs < kds->ncols ||
					cmeta->idx_subattrs >= kds->nr_colmeta)
					elog(ERROR, "Bug? corrupted kernel column metadata");
				if (sizeof(uint32_t) * (index+2) > cmeta->values_length)
					elog(ERROR, "Bug? array index is out of range");
				smeta = &kds->colmeta[cmeta->idx_subattrs];
				offset = (uint32_t *)((char *)kds + cmeta->values_offset);
				datum = pg_array_arrow_ref(kds, smeta,
										   offset[index],
										   offset[index+1]);
				isnull = false;
			}
			break;

		case ArrowType__LargeList:
			{
				kern_colmeta   *smeta;
				uint64_t	   *offset;

				if (cmeta->num_subattrs != 1 ||
					cmeta->idx_subattrs < kds->ncols ||
					cmeta->idx_subattrs >= kds->nr_colmeta)
					elog(ERROR, "Bug? corrupted kernel column metadata");
				if (sizeof(uint64_t) * (index+2) > cmeta->values_length)
					elog(ERROR, "Bug? array index is out of range");
				smeta = &kds->colmeta[cmeta->idx_subattrs];
				offset = (uint64_t *)((char *)kds + cmeta->values_offset);
				datum = pg_array_arrow_ref(kds, smeta,
										   offset[index],
										   offset[index+1]);
				isnull = false;
			}
			break;

		case ArrowType__Struct:
			{
				TupleDesc	tupdesc = lookup_rowtype_tupdesc(cmeta->atttypid, -1);
				Datum	   *sub_values = alloca(sizeof(Datum) * tupdesc->natts);
				bool	   *sub_isnull = alloca(sizeof(bool)  * tupdesc->natts);
				HeapTuple	htup;

				if (tupdesc->natts != cmeta->num_subattrs)
					elog(ERROR, "Struct definition is conrrupted?");
				if (cmeta->idx_subattrs < kds->ncols ||
					cmeta->idx_subattrs + cmeta->num_subattrs > kds->nr_colmeta)
					elog(ERROR, "Bug? strange kernel column metadata");
				for (int j=0; j < tupdesc->natts; j++)
				{
					kern_colmeta *sub_meta = &kds->colmeta[cmeta->idx_subattrs + j];

					pg_datum_arrow_ref(kds, sub_meta, index,
									   sub_values + j,
									   sub_isnull + j);
				}
				htup = heap_form_tuple(tupdesc, sub_values, sub_isnull);

				ReleaseTupleDesc(tupdesc);

				datum = PointerGetDatum(htup->t_data);
				isnull = false;
			}
			break;
		default:
			/* TODO: custom data type support here */
			elog(ERROR, "arrow_fdw: unknown or unsupported type");
	}
out:
	*p_datum  = datum;
	*p_isnull = isnull;
}

/*
 * KDS_fetch_tuple_arrow
 */
bool
kds_arrow_fetch_tuple(TupleTableSlot *slot,
					  kern_data_store *kds,
					  size_t index,
					  const Bitmapset *referenced)
{
	int		j, k;

	if (index >= kds->nitems)
		return false;
	ExecStoreAllNullTuple(slot);
	for (k = bms_next_member(referenced, -1);
		 k >= 0;
		 k = bms_next_member(referenced, k))
	{
		j = k + FirstLowInvalidHeapAttributeNumber - 1;
		if (j < 0)
			continue;
		pg_datum_arrow_ref(kds,
						   &kds->colmeta[j],
						   index,
						   slot->tts_values + j,
						   slot->tts_isnull + j);
	}
	return true;
}

/* ----------------------------------------------------------------
 *
 * Executor callbacks
 *
 * ----------------------------------------------------------------
 */

/*
 * __arrowFdwExecInit
 */
static ArrowFdwState *
__arrowFdwExecInit(ScanState *ss,
				   Relation frel,
				   List *outer_quals,
				   const Bitmapset *outer_refs,
				   pgstromTaskScanState *ptss)
{
	TupleDesc		tupdesc = RelationGetDescr(frel);
	ForeignTable   *ft = GetForeignTable(RelationGetRelid(frel));
	Bitmapset	   *referenced = NULL;
	Bitmapset	   *stat_attrs = NULL;
	gpumask_t		optimal_gpus = 0UL;
	bool			whole_row_ref = false;
	char			on_missing_fields;
	List		   *filesList;
	List		   *sourceFields;
	List		   *virtualColumnsList;
	List		   *af_states_list = NIL;
	uint32_t		rb_nrooms = 0;
	uint32_t		rb_nitems = 0;
	ArrowFdwState  *arrow_state;
	ListCell	   *lc1, *lc2;

	Assert(RelationIsArrowFdw(frel));
	/* expand 'referenced' if it has whole-row reference */
	if (bms_is_member(-FirstLowInvalidHeapAttributeNumber, outer_refs))
		whole_row_ref = true;
	for (int j=0; j < tupdesc->natts; j++)
	{
		Form_pg_attribute attr = TupleDescAttr(tupdesc, j);
		int		k = attr->attnum - FirstLowInvalidHeapAttributeNumber;

		if (attr->attisdropped)
			continue;
		if (whole_row_ref || bms_is_member(k, outer_refs))
			referenced = bms_add_member(referenced, k);
	}

	/* setup ArrowFileState */
	filesList = arrowFdwExtractFilesList(ft->options,
										 &virtualColumnsList,
										 NULL, NULL,
										 &on_missing_fields);
	sourceFields = arrowFdwExtractSourceFields(frel, on_missing_fields);
	forboth (lc1, filesList,
			 lc2, virtualColumnsList)
	{
		char	   *fname = strVal(lfirst(lc1));
		List	   *virtual_columns = lfirst(lc2);
		ArrowFileState *af_state;

		af_state = BuildArrowFileState(frel, fname,
									   sourceFields,
									   virtual_columns,
									   -1,
									   &stat_attrs);
		if (af_state)
		{
			rb_nrooms += list_length(af_state->rb_list);
			optimal_gpus |= af_state->optimal_gpus;

			af_states_list = lappend(af_states_list, af_state);
		}
	}

	/* setup ArrowFdwState */
	arrow_state = palloc0(offsetof(ArrowFdwState, rb_states[rb_nrooms]));
	arrow_state->referenced = referenced;
	if (arrow_fdw_stats_hint_enabled)
		arrow_state->stats_hint = execInitArrowStatsHint(ss, outer_quals, stat_attrs);
	arrow_state->rbatch_index = &arrow_state->__rbatch_index_local;
	arrow_state->rbatch_nload = &arrow_state->__rbatch_nload_local;
	arrow_state->rbatch_nskip = &arrow_state->__rbatch_nskip_local;
	arrow_state->nchunks_parquet_read = &arrow_state->__nchunks_parquet_read;
	arrow_state->ncaches_parquet_load = &arrow_state->__ncaches_parquet_load;
	initLargeStringInfo(&arrow_state->chunk_buffer);
	arrow_state->curr_filp  = -1;
	arrow_state->curr_kds   = NULL;
	arrow_state->curr_index = 0;
	arrow_state->af_states_list = af_states_list;
	foreach (lc1, af_states_list)
	{
		ArrowFileState *af_state = lfirst(lc1);

		foreach (lc2, af_state->rb_list)
		{
			RecordBatchState *rb_state = lfirst(lc2);

			arrow_state->rb_states[rb_nitems++] = rb_state;
		}
	}
	Assert(rb_nrooms == rb_nitems);
	arrow_state->rb_nitems = rb_nitems;
	if (ptss)
		ptss->optimal_gpus = optimal_gpus;
	return arrow_state;
}

/*
 * pgstromArrowFdwExecInit
 */
void
pgstromArrowFdwExecInit(pgstromTaskState *pts,
						pgstromTaskScanState *ptss,
						List *outer_quals,
						const Bitmapset *outer_refs)
{
	Assert(RelationIsArrowFdw(ptss->scan_rel));
	ptss->arrow_state = __arrowFdwExecInit(&pts->css.ss,
										   ptss->scan_rel,
										   outer_quals,
										   outer_refs,
										   ptss);
}

/*
 * ArrowBeginForeignScan
 */
static void
ArrowBeginForeignScan(ForeignScanState *node, int eflags)
{
	ForeignScan	   *fscan = (ForeignScan *)node->ss.ps.plan;
	Bitmapset	   *referenced = NULL;
	ListCell	   *lc;

	foreach (lc, fscan->fdw_private)
	{
		int		k = lfirst_int(lc);

		referenced = bms_add_member(referenced, k);
	}
	node->fdw_state = __arrowFdwExecInit(&node->ss,
										 node->ss.ss_currentRelation,
										 fscan->scan.plan.qual,
										 referenced,
										 NULL);
}

/*
 * ExecArrowScanChunk
 */
static inline RecordBatchState *
__arrowFdwNextRecordBatch(ArrowFdwState *arrow_state)
{
	RecordBatchState *rb_state;
	uint32_t	rb_index;

retry:
	rb_index = pg_atomic_fetch_add_u32(arrow_state->rbatch_index, 1);
	if (rb_index >= arrow_state->rb_nitems)
		return NULL;	/* no more chunks to load */
	rb_state = arrow_state->rb_states[rb_index];
	if (arrow_state->stats_hint)
	{
		if (execCheckArrowStatsHint(arrow_state->stats_hint, rb_state))
		{
			pg_atomic_fetch_add_u32(arrow_state->rbatch_nskip, 1);
			goto retry;
		}
		pg_atomic_fetch_add_u32(arrow_state->rbatch_nload, 1);
	}
	return rb_state;
}

/*
 * pgstromScanChunkArrowFdw
 */
XpuCommand *
pgstromScanChunkArrowFdw(pgstromTaskState *pts,
						 pgstromTaskScanState *ptss,
						 struct iovec *xcmd_iov, int *xcmd_iovcnt)
{
	ArrowFdwState  *arrow_state = ptss->arrow_state;
	LargeStringInfo	chunk_buffer = &arrow_state->chunk_buffer;
	RecordBatchState *rb_state;
	ArrowFileState *af_state;
	XpuCommand *xcmd;
	kern_data_store *kds_src;
	uint32_t	kds_src_offset = 0;
	uint32_t	kds_src_iovec = 0;
	uint32_t	kds_src_pathname;

	rb_state = __arrowFdwNextRecordBatch(arrow_state);
	if (!rb_state)
	{
		pts->curr_scan_rel++;
		return NULL;
	}
	af_state = rb_state->af_state;

	/* XpuCommand header */
	kds_src_offset = offsetof(XpuCommand, u.task.data);
	resetLargeStringInfo(chunk_buffer);
	enlargeLargeStringInfo(chunk_buffer, kds_src_offset);
	memset(chunk_buffer->data, 0, kds_src_offset);
	chunk_buffer->len = kds_src_offset;
	/* kds_src (arrow or parquet) */
	kds_src = __arrowFdwSetupKDSHead(ptss->scan_rel,
									 arrow_state->referenced,
									 rb_state,
									 chunk_buffer);
	if (kds_src->format == KDS_FORMAT_ARROW)
	{
		/* related i/o vector */
		strom_io_vector *iovec;
		size_t		iovec_sz;

		iovec = arrowFdwSetupIOvector(rb_state,
									  arrow_state->referenced,
									  kds_src);
		iovec_sz = offsetof(strom_io_vector, ioc[iovec->nr_chunks]);
		kds_src_iovec = appendBinaryLargeStringInfo(chunk_buffer,
													iovec, iovec_sz);
	}
	else
	{
		/*
		 * A Parquet row-group is decoded here (libparquet) into an Arrow-style
		 * store that carries its column buffers; the service reads it from the
		 * task itself (no i/o vector).
		 */
		kern_data_store *kds_head;
		kern_data_store *kds_rg;
		uint32_t	npages_direct_read = 0;
		uint32_t	npages_vfs_read = 0;
		uint32_t	nchunks_parquet_read = 0;
		uint32_t	ncaches_parquet_load = 0;
		char		error_message[320];
		size_t		head_len = chunk_buffer->len - kds_src_offset;

		Assert(kds_src->format == KDS_FORMAT_PARQUET);
		kds_head = alloca(head_len);
		memcpy(kds_head, (char *)kds_src, head_len);
		Assert(kds_head->format == KDS_FORMAT_PARQUET);
		chunk_buffer->len = kds_src_offset;
		kds_rg = parquetReadOneRowGroup(af_state->filename,
										kds_head,
										__parquetFillupAllocBuffer,
										(void *)chunk_buffer,
										&npages_direct_read,
										&npages_vfs_read,
										&nchunks_parquet_read,
										&ncaches_parquet_load,
										error_message,
										sizeof(error_message));
		if (!kds_rg)
			elog(ERROR, "Unable to load row-group %d of the parquet file '%s': %s",
				 rb_state->rb_index, af_state->filename, error_message);
		Assert((char *)kds_rg == chunk_buffer->data + kds_src_offset);
		chunk_buffer->len = kds_src_offset + kds_rg->length;
		pg_atomic_fetch_add_u32(arrow_state->nchunks_parquet_read, nchunks_parquet_read);
		pg_atomic_fetch_add_u32(arrow_state->ncaches_parquet_load, ncaches_parquet_load);
	}
	/* arrow/parquet filename */
	kds_src_pathname = chunk_buffer->len;
	appendStringLargeStringInfo(chunk_buffer, af_state->filename);
	/* assign offset of XpuCommand */
	xcmd = (XpuCommand *)chunk_buffer->data;
	xcmd->magic  = XpuCommandMagicNumber;
	xcmd->tag    = XpuCommandTag__XpuTaskExec;
	xcmd->length = chunk_buffer->len;
	xcmd->gpumask = af_state->optimal_gpus;
	xcmd->u.task.scan_relidx      = ptss->scan_relidx;
	xcmd->u.task.kds_src_pathname = kds_src_pathname;
	xcmd->u.task.kds_src_iovec    = kds_src_iovec;
	xcmd->u.task.kds_src_offset   = kds_src_offset;
	xcmd_iov->iov_base = xcmd;
	xcmd_iov->iov_len  = xcmd->length;
	*xcmd_iovcnt = 1;

	return xcmd;
}

/*
 * ArrowIterateForeignScan
 */
static TupleTableSlot *
ArrowIterateForeignScan(ForeignScanState *node)
{
	ArrowFdwState *arrow_state = node->fdw_state;
	TupleTableSlot *slot = node->ss.ss_ScanTupleSlot;
	kern_data_store *kds;

	while ((kds = arrow_state->curr_kds) == NULL ||
		   arrow_state->curr_index >= kds->nitems)
	{
		RecordBatchState *rb_state;

		arrow_state->curr_index = 0;
		arrow_state->curr_kds = NULL;
		rb_state = __arrowFdwNextRecordBatch(arrow_state);
		if (!rb_state)
			return NULL;
		if (ArrowMetadataVersionIsParquet(rb_state->af_state->version))
		{
			arrow_state->curr_kds
				= parquetFillupRowGroup(node->ss.ss_currentRelation,
										arrow_state->referenced,
										rb_state,
										&arrow_state->chunk_buffer);
		}
		else
		{
			arrow_state->curr_kds
				= arrowFdwFillupRecordBatch(node->ss.ss_currentRelation,
											arrow_state->referenced,
											rb_state,
											&arrow_state->chunk_buffer);
		}
	}
	Assert(kds && arrow_state->curr_index < kds->nitems);
	if (kds_arrow_fetch_tuple(slot, kds,
							  arrow_state->curr_index++,
							  arrow_state->referenced))
		return slot;
	return NULL;
}

/*
 * ArrowReScanForeignScan
 */
void
pgstromArrowFdwExecReset(ArrowFdwState *arrow_state)
{
	pg_atomic_write_u32(arrow_state->rbatch_index, 0);
	if (arrow_state->curr_kds)
		pfree(arrow_state->curr_kds);
	arrow_state->curr_kds = NULL;
	arrow_state->curr_index = 0;
}

static void
ArrowReScanForeignScan(ForeignScanState *node)
{
	pgstromArrowFdwExecReset(node->fdw_state);
}

/*
 * ExecEndArrowScan
 */
void
pgstromArrowFdwExecEnd(ArrowFdwState *arrow_state)
{
	if (arrow_state->curr_filp >= 0)
		FileClose(arrow_state->curr_filp);
	if (arrow_state->stats_hint)
		execEndArrowStatsHint(arrow_state->stats_hint);
}

static void
ArrowEndForeignScan(ForeignScanState *node)
{
	pgstromArrowFdwExecEnd(node->fdw_state);
}

/*
 * arrowFdwUpdateExecStats
 */
void
arrowFdwUpdateExecStats(ArrowFdwState *arrow_state, const kern_exec_results *kresults)
{
	pg_atomic_fetch_add_u32(arrow_state->nchunks_parquet_read,
							kresults->nchunks_parquet_read);
	pg_atomic_fetch_add_u32(arrow_state->ncaches_parquet_load,
							kresults->ncaches_parquet_load);
}

/*
 * ArrowIsForeignScanParallelSafe
 */
static bool
ArrowIsForeignScanParallelSafe(PlannerInfo *root,
							   RelOptInfo *rel,
							   RangeTblEntry *rte)
{
	return true;
}

/*
 * ArrowEstimateDSMForeignScan
 */
Size
pgstromArrowFdwEstimateDSM(ArrowFdwState *arrow_state)
{
	return MAXALIGN(sizeof(pgstromSharedScanState));
}

static Size
ArrowEstimateDSMForeignScan(ForeignScanState *node,
							ParallelContext *pcxt)
{
	return pgstromArrowFdwEstimateDSM(node->fdw_state);
}

/*
 * ArrowInitializeDSMForeignScan
 */
Size
pgstromArrowFdwInitDSM(ArrowFdwState *arrow_state,
					   pgstromSharedScanState *psss)
{
	arrow_state->rbatch_index = &psss->arrow_rbatch_index;
	arrow_state->rbatch_nload = &psss->arrow_rbatch_nload;
	arrow_state->rbatch_nskip = &psss->arrow_rbatch_nskip;
	arrow_state->nchunks_parquet_read = &psss->nchunks_parquet_read;
	arrow_state->ncaches_parquet_load = &psss->ncaches_parquet_load;
	return pgstromArrowFdwEstimateDSM(arrow_state);
}

static void
ArrowInitializeDSMForeignScan(ForeignScanState *node,
                              ParallelContext *pcxt,
                              void *coordinate)
{
	pgstromSharedScanState *psss = (pgstromSharedScanState *)coordinate;

	memset(psss, 0, sizeof(pgstromSharedScanState));
	pgstromArrowFdwInitDSM(node->fdw_state, psss);
}

/*
 * ArrowInitializeWorkerForeignScan
 */
Size
pgstromArrowFdwAttachDSM(ArrowFdwState *arrow_state,
						 pgstromSharedScanState *psss)
{
	return pgstromArrowFdwInitDSM(arrow_state, psss);
}

static void
ArrowInitializeWorkerForeignScan(ForeignScanState *node,
								 shm_toc *toc,
								 void *coordinate)
{
	pgstromSharedScanState *psss = (pgstromSharedScanState *)coordinate;

	pgstromArrowFdwAttachDSM(node->fdw_state, psss);
}

/*
 * ArrowShutdownForeignScan
 */
Size
pgstromArrowFdwShutdownDSM(ArrowFdwState *arrow_state)
{
	uint32		temp;

	temp = pg_atomic_read_u32(arrow_state->rbatch_index);
	pg_atomic_write_u32(&arrow_state->__rbatch_index_local, temp);
	arrow_state->rbatch_index = &arrow_state->__rbatch_index_local;

	temp = pg_atomic_read_u32(arrow_state->rbatch_nload);
	pg_atomic_write_u32(&arrow_state->__rbatch_nload_local, temp);
	arrow_state->rbatch_nload = &arrow_state->__rbatch_nload_local;

	temp = pg_atomic_read_u32(arrow_state->rbatch_nskip);
	pg_atomic_write_u32(&arrow_state->__rbatch_nskip_local, temp);
	arrow_state->rbatch_nskip = &arrow_state->__rbatch_nskip_local;

	temp = pg_atomic_read_u32(arrow_state->nchunks_parquet_read);
	pg_atomic_write_u32(&arrow_state->__nchunks_parquet_read, temp);
	arrow_state->nchunks_parquet_read = &arrow_state->__nchunks_parquet_read;

	temp = pg_atomic_read_u32(arrow_state->ncaches_parquet_load);
	pg_atomic_write_u32(&arrow_state->__ncaches_parquet_load, temp);
	arrow_state->ncaches_parquet_load = &arrow_state->__ncaches_parquet_load;

	return pgstromArrowFdwEstimateDSM(arrow_state);
}

static void
ArrowShutdownForeignScan(ForeignScanState *node)
{
	pgstromArrowFdwShutdownDSM(node->fdw_state);
}

#if 1
/*
 * fixup_danger_expression_for_explain
 *
 * NOTE: pgstromArrowFdwExplain() called via ExplainForeignScan() of FDW
 * does not carry 'ancestors' information, so extension cannot deparse
 * some kind of expressions, like Param which refers upper node.
 * It eventually causes assertion failed, so we have to fixup them.
 *
 * NOTE: we want this API design is revised in the future PostgreSQL version...
 *       details are described at #974
 */
static Node *
fixup_danger_expression_for_explain(Node *node, void *data)
{
	if (!node)
		return node;
	if (IsA(node, Param))
	{
		Param  *param = (Param *)node;
		char	buf[100];
		int		bufsz;

		bufsz = sprintf(buf, "****Param(%s, ID: %d)",
						param->paramkind == PARAM_EXTERN  ? "PARAM_EXTERN" :
						param->paramkind == PARAM_EXEC    ? "PARAM_EXEC" :
						param->paramkind == PARAM_SUBLINK ? "PARAM_SUBLINK" :
						param->paramkind == PARAM_MULTIEXPR ? "PARAM_MULTIEXPR" : "???",
						param->paramid + 1);
		SET_VARSIZE(buf, bufsz);
		return (Node *)makeConst(TEXTOID,	/* consttype */
								 -1,		/* consttypmod */
								 InvalidOid,/* constcollid */
								 -1,		/* constlen */
								 PointerGetDatum(pmemdup(buf, bufsz)),
								 false,		/* constisnull */
								 false);	/* constbyval */
	}
	return expression_tree_mutator(node, fixup_danger_expression_for_explain, data);
}
#endif

/*
 * pgstromExplainRefColumns
 */
void
pgstromExplainRefColumns(Relation frel,
						 const Bitmapset *outer_refs,
						 ExplainState *es,
						 List *dcontext)
{
	TupleDesc	tupdesc = RelationGetDescr(frel);
	bool		wholerow = false;
	StringInfoData buf;

	initStringInfo(&buf);
	for (int j=0; j < tupdesc->natts; j++)
	{
		int		k = j - FirstLowInvalidHeapAttributeNumber;

		if (j == 0)
			wholerow = bms_is_member(k, outer_refs);
		else if (wholerow || bms_is_member(k, outer_refs))
		{
			Form_pg_attribute attr = TupleDescAttr(tupdesc, j-1);
			const char *attname = NameStr(attr->attname);

			if (attr->attisdropped)
				continue;	/* should not happen */
			if (buf.len > 0)
				appendStringInfoString(&buf, ", ");
			appendStringInfoString(&buf, quote_identifier(attname));
		}
	}
	ExplainPropertyText("referenced", buf.data, es);
	pfree(buf.data);
}

/*
 * pgstromArrowFdwExplainHint
 */
void
pgstromExplainArrowFdwHint(ScanState *ss,	/* Foreign or Custom */
						   ArrowFdwState *arrow_state,
						   ExplainState *es,
						   List *dcontext,
						   const char *prefix)
{
	arrowStatsHint *stats_hint = arrow_state->stats_hint;
	StringInfoData	buf;
	char			label[100];
	ListCell	   *lc;

	if (!stats_hint)
		return;
	initStringInfo(&buf);
	foreach (lc, stats_hint->orig_quals)
	{
		Node   *qual = lfirst(lc);
		char   *temp;

		/*
		 * FIXME: deparse_context by ForeignScanState does not carry
		 * 'ancestors' (probably, wrong API design...), so we cannot
		 * deparse expressions for human readable form.
		 * So, we replace Param expression for safety.
		 */
		if (IsA(ss, ForeignScanState))
			qual = fixup_danger_expression_for_explain(qual, ss);
		temp = deparse_expression(qual, dcontext, es->verbose, false);
		if (buf.len > 0)
			appendStringInfoString(&buf, ", ");
		appendStringInfoString(&buf, temp);
		pfree(temp);
	}
	if (es->analyze)
		appendStringInfo(&buf, "  [loaded: %u, skipped: %u]",
						 pg_atomic_read_u32(arrow_state->rbatch_nload),
						 pg_atomic_read_u32(arrow_state->rbatch_nskip));
	if (!prefix)
		strcpy(label, "Stats-Hint");
	else
		snprintf(label, sizeof(label), "%s-stats-hint", prefix);

	ExplainPropertyText(label, buf.data, es);
	pfree(buf.data);
}

/*
 * pgstromExplainArrowFdwFiles
 */
void
pgstromExplainArrowFdwFiles(ScanState *ss,
							List *arrow_state_list,
							ExplainState *es,
							List *dcontext)
{
	Relation	base_rel = ss->ss_currentRelation;
	TupleDesc	tupdesc = RelationGetDescr(base_rel);
	int			total_nfiles = 0;
	int			files_count = 0;
	size_t	   *chunk_sz;
	ListCell   *lc1, *lc2, *lc3;
	char		label[100];
	StringInfoData buf;

	initStringInfo(&buf);
	chunk_sz = alloca(sizeof(size_t) * (tupdesc->natts + 1));	/* indexed by attnum 1..natts */
	memset(chunk_sz, 0, sizeof(size_t) * (tupdesc->natts + 1));
	foreach (lc1, arrow_state_list)
	{
		ArrowFdwState *arrow_state = lfirst(lc1);

		total_nfiles += list_length(arrow_state->af_states_list);
	}
	foreach (lc1, arrow_state_list)
	{
		ArrowFdwState *arrow_state = lfirst(lc1);

		foreach (lc2, arrow_state->af_states_list)
		{
			ArrowFileState *af_state = lfirst(lc2);
			const char *filename = af_state->filename;
			size_t	total_sz = af_state->stat_buf.st_size;
			size_t	read_sz = 0;

			foreach (lc3, af_state->rb_list)
			{
				RecordBatchState *rb_state = lfirst(lc3);
				bool	wholeref = false;

				for (int j=0; j <= tupdesc->natts; j++)
				{
					int	k = j - FirstLowInvalidHeapAttributeNumber;

					if (j==0 && bms_is_member(k, arrow_state->referenced))
						wholeref = true;
					else if (wholeref || bms_is_member(k, arrow_state->referenced))
					{
						int		f_index = af_state->attrs[j-1].field_index;
						if (f_index >= 0 && f_index < rb_state->nfields)
						{
							size_t	sz = rb_state->fields[f_index].disk_length;
							read_sz += sz;
							chunk_sz[j] += sz;
						}
					}
				}
			}
			/* displays only basename if regression test mode */
			if (pgstrom_regression_test_mode)
				filename = basename(pstrdup(filename));
			/* file size and read size */
			if (!pgstrom_explain_developer_mode &&
				total_nfiles >= 6 &&
				files_count >= 2 && files_count < total_nfiles-2)
			{
				if (es->format == EXPLAIN_FORMAT_TEXT && files_count == 2)
					ExplainPropertyText("    :\t\t\t", "\t\t\t:", es);
			}
			else if (es->format == EXPLAIN_FORMAT_TEXT)
			{
				resetStringInfo(&buf);
				appendStringInfo(&buf, "%s (read: %s, size: %s)",
								 filename,
								 format_bytesz(read_sz),
								 format_bytesz(total_sz));
				snprintf(label, sizeof(label), "file%d", files_count);
				ExplainPropertyText(label, buf.data, es);
			}
			else
			{
				snprintf(label, sizeof(label), "file%d", files_count);
				ExplainPropertyText(label, filename, es);
				snprintf(label, sizeof(label), "file%d-read", files_count);
				ExplainPropertyText(label, format_bytesz(read_sz), es);
				snprintf(label, sizeof(label), "file%d-size", files_count);
				ExplainPropertyText(label, format_bytesz(total_sz), es);
			}
			files_count++;
		}
	}
}

/*
 * ArrowExplainForeignScan
 */
static void
ArrowExplainForeignScan(ForeignScanState *node, ExplainState *es)
{
	Relation	frel = node->ss.ss_currentRelation;
	ArrowFdwState *arrow_state = node->fdw_state;
	List	   *dcontext;

	dcontext = set_deparse_context_plan(es->deparse_cxt,
										node->ss.ps.plan,
										NULL);
	pgstromExplainRefColumns(frel, arrow_state->referenced, es, dcontext);
	pgstromExplainArrowFdwHint(&node->ss, arrow_state, es, dcontext, NULL);
	pgstromExplainArrowFdwFiles(&node->ss, list_make1(arrow_state), es, dcontext);
}

/*
 * ArrowAnalyzeForeignTable
 */
static int
RecordBatchAcquireSampleRows(Relation relation,
							 RecordBatchState *rb_state,
							 HeapTuple *rows,
							 int nsamples)
{
	TupleDesc		tupdesc = RelationGetDescr(relation);
	kern_data_store *kds;
	Bitmapset	   *referenced = NULL;
	LargeStringInfoData buffer;
	Datum		   *values;
	bool		   *isnull;
	int				count;
	uint32_t		index;

	/* ANALYZE needs to fetch all the attributes */
	referenced = bms_make_singleton(-FirstLowInvalidHeapAttributeNumber);
	initLargeStringInfo(&buffer);
	/* Load an example KDS buffer */
	if (ArrowMetadataVersionIsParquet(rb_state->af_state->version))
		kds = parquetFillupRowGroup(relation, referenced, rb_state, &buffer);
	else
		kds = arrowFdwFillupRecordBatch(relation, referenced, rb_state, &buffer);
	/* Extract the tuple */
	values = alloca(sizeof(Datum) * tupdesc->natts);
	isnull = alloca(sizeof(bool)  * tupdesc->natts);
	for (count = 0; count < nsamples; count++)
	{
		/* fetch a row randomly */
		index = (double)kds->nitems * drand48();
		Assert(index < kds->nitems);

		for (int j=0; j < kds->ncols; j++)
		{
			kern_colmeta   *cmeta = &kds->colmeta[j];

			pg_datum_arrow_ref(kds,
							   cmeta,
							   index,
							   values + j,
							   isnull + j);
		}
		rows[count] = heap_form_tuple(tupdesc, values, isnull);
	}
	pfree(buffer.data);

	return count;
}

static int
ArrowAcquireSampleRows(Relation relation,
					   int elevel,
					   HeapTuple *rows,
					   int nrooms,
					   double *p_totalrows,
					   double *p_totaldeadrows)
{
	ForeignTable   *ft = GetForeignTable(RelationGetRelid(relation));
	List		   *filesList;
	List		   *virtualColumnsList;
	List		   *sourceFields;
	List		   *rb_state_list = NIL;
	ListCell	   *lc1, *lc2;
	int64			total_nrows = 0;
	int64			count_nrows = 0;
	int				nsamples_min = nrooms / 100;
	int				nitems = 0;
	char			on_missing_fields;

	filesList = arrowFdwExtractFilesList(ft->options,
										 &virtualColumnsList,
										 NULL, NULL,
										 &on_missing_fields);
	sourceFields = arrowFdwExtractSourceFields(relation, on_missing_fields);
	forboth (lc1, filesList,
			 lc2, virtualColumnsList)
	{
		ArrowFileState *af_state;
		char	   *fname = strVal(lfirst(lc1));
		List	   *virtual_columns = lfirst(lc2);
		ListCell   *cell;

		af_state = BuildArrowFileState(relation, fname,
									   sourceFields,
									   virtual_columns,
									   -1,
									   NULL);
		if (!af_state)
			continue;
		foreach (cell, af_state->rb_list)
		{
			RecordBatchState *rb_state = lfirst(cell);

			if (rb_state->rb_nitems == 0)
				continue;	/* not reasonable to sample, skipped */
			total_nrows += rb_state->rb_nitems;
			rb_state_list = lappend(rb_state_list, rb_state);
		}
	}
	nrooms = Min(nrooms, total_nrows);

	/* fetch samples for each record-batch */
	foreach (lc1, rb_state_list)
	{
		RecordBatchState *rb_state = lfirst(lc1);
		int			nsamples;

		count_nrows += rb_state->rb_nitems;
		nsamples = (double)nrooms * ((double)count_nrows /
									 (double)total_nrows) - nitems;
		if (nitems + nsamples > nrooms)
			nsamples = nrooms - nitems;
		if (nsamples > nsamples_min)
			nitems += RecordBatchAcquireSampleRows(relation,
												   rb_state,
												   rows + nitems,
												   nsamples);
	}
	*p_totalrows = total_nrows;
	*p_totaldeadrows = 0.0;

	return nitems;
}

/*
 * ArrowAnalyzeForeignTable
 */
static bool
ArrowAnalyzeForeignTable(Relation frel,
						 AcquireSampleRowsFunc *p_sample_rows_func,
						 BlockNumber *p_totalpages)
{
	ForeignTable   *ft = GetForeignTable(RelationGetRelid(frel));
	List		   *filesList;
	List		   *virtualColumnsList;
	ListCell	   *lc;
	size_t			totalpages = 0;

	filesList = arrowFdwExtractFilesList(ft->options,
										 &virtualColumnsList,
										 NULL, NULL, NULL);
	foreach (lc, filesList)
	{
		const char	   *fname = strVal(lfirst(lc));
		struct stat		stat_buf;

		if (stat(fname, &stat_buf) != 0)
		{
			elog(NOTICE, "failed on stat('%s') on behalf of '%s', skipped",
				 fname, get_rel_name(ft->relid));
			continue;
		}
		totalpages += (stat_buf.st_size + BLCKSZ - 1) / BLCKSZ;
	}
	if (totalpages > MaxBlockNumber)
		totalpages = MaxBlockNumber;

	*p_sample_rows_func = ArrowAcquireSampleRows;
	*p_totalpages = totalpages;

	return true;
}

/*
 * ensureUniqueFieldNames
 */
static const char **
ensureUniqueFieldNames(ArrowSchema *schema, List *virtual_columns)
{
	const char **column_names;
	int			k, count = 2;
	ListCell   *lc;

	column_names = palloc0(sizeof(char *) * (schema->_num_fields + 1 +
											 list_length(virtual_columns)));
	for (k=0; k < schema->_num_fields; k++)
	{
		const char *cname = schema->fields[k].name;
	retry:
		for (int j=0; j < k; j++)
		{
			if (strcasecmp(cname, column_names[j]) == 0)
			{
				cname = psprintf("__%s_%d", schema->fields[k].name, count++);
				goto retry;
			}
		}
		if (schema->fields[k].name != cname)
			elog(NOTICE, "Arrow::field[%d] '%s' meets a duplicated field name, so renamed to '%s'",
				 k, schema->fields[k].name, cname);
		column_names[k] = cname;
	}

	foreach (lc, virtual_columns)
	{
		virtualColumnDef *vcdef = lfirst(lc);
		const char *cname = vcdef->key;
	again:
		for (int j=0; j < k; j++)
		{
			if (strcasecmp(cname, column_names[j]) == 0)
			{
				cname = psprintf("__%s_%d", vcdef->key, count++);
				goto again;
			}
		}
		if (vcdef->key != cname)
			elog(NOTICE, "Arrow virtual column '%s' meets a duplicated field name, so renamed to '%s'",
				 vcdef->key, cname);
		column_names[k++] = cname;
	}
	Assert(column_names[k] == NULL);
	return column_names;
}

/*
 * ArrowImportForeignSchema
 */
static List *
ArrowImportForeignSchema(ImportForeignSchemaStmt *stmt, Oid serverOid)
{
	ArrowSchema	schema;
	List	   *virtual_columns_prime = NIL;
	List	   *filesList;
	List	   *virtualColumnsList;
	ListCell   *lc1, *lc2;
	const char **column_names;
	int			i;
	StringInfoData	cmd;

	/* sanity checks */
	switch (stmt->list_type)
	{
		case FDW_IMPORT_SCHEMA_ALL:
			break;
		case FDW_IMPORT_SCHEMA_LIMIT_TO:
			elog(ERROR, "arrow_fdw does not support LIMIT TO clause");
			break;
		case FDW_IMPORT_SCHEMA_EXCEPT:
			elog(ERROR, "arrow_fdw does not support EXCEPT clause");
			break;
		default:
			elog(ERROR, "arrow_fdw: Bug? unknown list-type");
			break;
	}
	filesList = arrowFdwExtractFilesList(stmt->options,
										 &virtualColumnsList,
										 NULL, NULL, NULL);
	if (filesList == NIL)
		ereport(ERROR,
				(errmsg("No valid apache arrow files are specified"),
				 errhint("Use 'file' or 'dir' option to specify apache arrow files on behalf of the foreign table")));

	/* read the schema */
	memset(&schema, 0, sizeof(ArrowSchema));
	forboth (lc1, filesList,
			 lc2, virtualColumnsList)
	{
		ArrowFileInfo af_info;
		const char *fname = strVal(lfirst(lc1));

		readArrowFile(fname, &af_info, false);
		if (lc1 == list_head(filesList))
		{
			copyArrowNode(&schema.node, &af_info.footer.schema.node);
			virtual_columns_prime = lfirst(lc2);
		}
		else
		{
			/* compatibility checks */
			ArrowSchema	   *stemp = &af_info.footer.schema;

			if (schema.endianness != stemp->endianness ||
				schema._num_fields != stemp->_num_fields)
				elog(ERROR, "file '%s' has incompatible schema definition", fname);
			for (int j=0; j < schema._num_fields; j++)
			{
				bool	found = false;

				for (int k=0; k < stemp->_num_fields; k++)
				{
					if (strcmp(schema.fields[j].name,
							   stemp->fields[k].name) == 0)
					{
						if (equalArrowNode(&schema.fields[j].type.node,
										   &stemp->fields[k].type.node))
						{
							found = true;
							break;
						}
						elog(ERROR, "field '%s' of '%s' has incompatible data type",
							 schema.fields[j].name, fname);
					}
				}
				if (!found)
					elog(ERROR, "field '%s' was not found in the file '%s'",
						 schema.fields[j].name, fname);
			}
		}
	}
	/* ensure the field-names are unique */
	column_names = ensureUniqueFieldNames(&schema, virtual_columns_prime);

	/* makes a command to define foreign table */
	initStringInfo(&cmd);
	appendStringInfo(&cmd, "CREATE FOREIGN TABLE %s (\n",
					 quote_identifier(stmt->remote_schema));
	for (i=0; i < schema._num_fields; i++)
	{
		ArrowField *field = &schema.fields[i];
		Oid				type_oid;
		int32			type_mod;
		char		   *schema;
		HeapTuple		htup;
		Form_pg_type	__type;

		__arrowFieldTypeToPGType(field, &type_oid, &type_mod, NULL);
		if (!OidIsValid(type_oid))
			elog(ERROR, "unable to map Arrow type on any PG type");
		htup = SearchSysCache1(TYPEOID, ObjectIdGetDatum(type_oid));
		if (!HeapTupleIsValid(htup))
			elog(ERROR, "cache lookup failed for type %u", type_oid);
		__type = (Form_pg_type) GETSTRUCT(htup);
		schema = get_namespace_name(__type->typnamespace);
		if (!schema)
			elog(ERROR, "cache lookup failed for schema %u", __type->typnamespace);
		if (i > 0)
			appendStringInfo(&cmd, ",\n");
		if (type_mod < 0)
		{
			appendStringInfo(&cmd, "  %s %s.%s",
							 quote_identifier(column_names[i]),
							 quote_identifier(schema),
							 NameStr(__type->typname));
		}
		else
		{
			Assert(type_mod >= VARHDRSZ);
			appendStringInfo(&cmd, "  %s %s.%s(%d)",
							 quote_identifier(column_names[i]),
							 quote_identifier(schema),
							 NameStr(__type->typname),
							 type_mod - VARHDRSZ);
		}
		if (field->name != column_names[i])
			appendStringInfo(&cmd, " options (field '%s')", field->name);		
		ReleaseSysCache(htup);
	}

	foreach (lc1,  virtual_columns_prime)
	{
		virtualColumnDef *vcdef = lfirst(lc1);
		const char	   *label;

		Assert(column_names[i] != NULL);
		if (i > 0)
			appendStringInfo(&cmd, ",\n");
		if (vcdef->kind == '@')
			label = "pg_catalog.int8";
		else if (vcdef->kind == '$')
			label = "pg_catalog.text";
		else
			 elog(ERROR, "arrow_fdw: Bug? unknown virtual column type '%c'", vcdef->kind);

		appendStringInfo(&cmd, "  %s %s options(virtual '%s')",
						 quote_identifier(column_names[i]),
						 label,
						 vcdef->key);
		i++;
	}
	Assert(column_names[i] == NULL);
	appendStringInfo(&cmd,
					 "\n"
					 ") SERVER %s\n"
					 "  OPTIONS (", stmt->server_name);
	foreach (lc1, stmt->options)
	{
		DefElem	   *defel = lfirst(lc1);

		if (lc1 != list_head(stmt->options))
			appendStringInfo(&cmd, ",\n           ");
		appendStringInfo(&cmd, "%s '%s'",
						 defel->defname,
						 strVal(defel->arg));
	}
	appendStringInfo(&cmd, ")");

	return list_make1(cmd.data);
}

/*
 * pgstrom_arrow_fdw_import_file
 *
 * NOTE: Due to historical reason, PostgreSQL does not allow to define
 * columns more than MaxHeapAttributeNumber (1600) for foreign-tables also,
 * not only heap-tables. This restriction comes from NULL-bitmap length
 * in HeapTupleHeaderData and width of t_hoff.
 * However, it is not a reasonable restriction for foreign-table, because
 * it does not use heap-format internally.
 */
PG_FUNCTION_INFO_V1(pgstrom_arrow_fdw_import_file);
static void
__insertPgAttributeTuple(Relation pg_attr_rel,
						 CatalogIndexState pg_attr_index,
						 Oid ftable_oid,
						 AttrNumber attnum,
						 const char *attname,
						 ArrowField *field)
{
	Oid			type_oid;
	int32		type_mod;
	int16		type_len;
	bool		type_byval;
	char		type_align;
	int32		type_ndims;
	char		type_storage;
	Datum		values[Natts_pg_attribute];
	bool		isnull[Natts_pg_attribute];
	HeapTuple	tup;
	ObjectAddress myself, referenced;

	__arrowFieldTypeToPGType(field, &type_oid, &type_mod, NULL);
	get_typlenbyvalalign(type_oid,
						 &type_len,
						 &type_byval,
						 &type_align);
	type_ndims = (type_is_array(type_oid) ? 1 : 0);
	type_storage = get_typstorage(type_oid);

	memset(values, 0, sizeof(values));
	memset(isnull, 0, sizeof(isnull));

	values[Anum_pg_attribute_attrelid - 1] = ObjectIdGetDatum(ftable_oid);
	values[Anum_pg_attribute_attname - 1] = CStringGetDatum(attname);
	values[Anum_pg_attribute_atttypid - 1] = ObjectIdGetDatum(type_oid);
	values[Anum_pg_attribute_attstattarget - 1] = Int32GetDatum(-1);
	values[Anum_pg_attribute_attlen - 1] = Int16GetDatum(type_len);
	values[Anum_pg_attribute_attnum - 1] = Int16GetDatum(attnum);
	values[Anum_pg_attribute_attndims - 1] = Int32GetDatum(type_ndims);
#if PG_VERSION_NUM < 180000
	/*
	 * MEMO: PG18 removed pg_attribute.attcacheoff because its role was
	 * moved to CompactAttribute of TupleDesc.
	 * git: 02a8d0c45253eb54e57b1974c8627e5be3e1d852
	 */
	values[Anum_pg_attribute_attcacheoff - 1] = Int32GetDatum(-1);
#endif
	values[Anum_pg_attribute_atttypmod - 1] = Int32GetDatum(type_mod);
	values[Anum_pg_attribute_attbyval - 1] = BoolGetDatum(type_byval);
	values[Anum_pg_attribute_attstorage - 1] = CharGetDatum(type_storage);
	values[Anum_pg_attribute_attalign - 1] = CharGetDatum(type_align);
	values[Anum_pg_attribute_attnotnull - 1] = BoolGetDatum(!field->nullable);
	values[Anum_pg_attribute_attislocal - 1] = BoolGetDatum(true);
	isnull[Anum_pg_attribute_attacl - 1] = true;
	isnull[Anum_pg_attribute_attoptions - 1] = true;
	isnull[Anum_pg_attribute_attfdwoptions - 1] = true;
	isnull[Anum_pg_attribute_attmissingval - 1] = true;

	tup = heap_form_tuple(RelationGetDescr(pg_attr_rel), values, isnull);
	CatalogTupleInsertWithInfo(pg_attr_rel, tup, pg_attr_index);

	/* add dependency */
	myself.classId = RelationRelationId;
	myself.objectId = ftable_oid;
	myself.objectSubId = attnum;
	referenced.classId = TypeRelationId;
	referenced.objectId = type_oid;
	referenced.objectSubId = 0;
	recordDependencyOn(&myself, &referenced, DEPENDENCY_NORMAL);

	heap_freetuple(tup);
}

PUBLIC_FUNCTION(Datum)
pgstrom_arrow_fdw_import_file(PG_FUNCTION_ARGS)
{
	CreateForeignTableStmt stmt;
	ArrowSchema	schema;
	List	   *tableElts = NIL;
	char	   *ftable_name;
	char	   *file_name;
	char	   *namespace_name;
	const char **column_names;
	DefElem	   *defel;
	int			nfields;
	Oid			ftable_oid;
	ObjectAddress myself;
	ArrowFileInfo af_info;

	/* read schema of the file */
	if (PG_ARGISNULL(0))
		elog(ERROR, "foreign table name is not supplied");
	ftable_name = text_to_cstring(PG_GETARG_TEXT_PP(0));

	if (PG_ARGISNULL(1))
		elog(ERROR, "arrow filename is not supplied");
	file_name = text_to_cstring(PG_GETARG_TEXT_PP(1));
	defel = makeDefElem("file", (Node *)makeString(file_name), -1);

	if (PG_ARGISNULL(2))
		namespace_name = NULL;
	else
		namespace_name = text_to_cstring(PG_GETARG_TEXT_PP(2));

	readArrowFile(file_name, &af_info, false);
	copyArrowNode(&schema.node, &af_info.footer.schema.node);
	if (schema._num_fields > SHRT_MAX)
		elog(ERROR, "Arrow file '%s' has too much fields: %d",
			 file_name, schema._num_fields);
	column_names = ensureUniqueFieldNames(&schema, NIL);

	/* setup CreateForeignTableStmt */
	memset(&stmt, 0, sizeof(CreateForeignTableStmt));
	NodeSetTag(&stmt, T_CreateForeignTableStmt);
	stmt.base.relation = makeRangeVar(namespace_name, ftable_name, -1);

	nfields = Min(schema._num_fields, 100);
	for (int j=0; j < nfields; j++)
	{
		ColumnDef  *cdef;
		Oid			type_oid;
		int32_t		type_mod;

		__arrowFieldTypeToPGType(&schema.fields[j],
								 &type_oid,
								 &type_mod,
								 NULL);
		cdef = makeColumnDef(column_names[j],
							 type_oid,
							 type_mod,
							 InvalidOid);
		tableElts = lappend(tableElts, cdef);
	}
	stmt.base.tableElts = tableElts;
	stmt.base.oncommit = ONCOMMIT_NOOP;
	stmt.servername = "arrow_fdw";
	stmt.options = list_make1(defel);

	myself = DefineRelation(&stmt.base,
							RELKIND_FOREIGN_TABLE,
							InvalidOid,
							NULL,
							__FUNCTION__);
	ftable_oid = myself.objectId;
	CreateForeignTable(&stmt, ftable_oid);

	if (nfields < schema._num_fields)
	{
		Relation	c_rel = table_open(RelationRelationId, RowExclusiveLock);
		Relation	a_rel = table_open(AttributeRelationId, RowExclusiveLock);
		CatalogIndexState c_index = CatalogOpenIndexes(c_rel);
		CatalogIndexState a_index = CatalogOpenIndexes(a_rel);
		HeapTuple	tup;

		tup = SearchSysCacheCopy1(RELOID, ObjectIdGetDatum(ftable_oid));
		if (!HeapTupleIsValid(tup))
			elog(ERROR, "cache lookup failed for relation %u", ftable_oid);

		for (int j=nfields; j < schema._num_fields; j++)
		{
			__insertPgAttributeTuple(a_rel,
									 a_index,
									 ftable_oid,
									 j+1,
									 column_names[j],
                                     &schema.fields[j]);
		}
		/* update relnatts also */
		((Form_pg_class) GETSTRUCT(tup))->relnatts = schema._num_fields;
		CatalogTupleUpdate(c_rel, &tup->t_self, tup);

		CatalogCloseIndexes(a_index);
		CatalogCloseIndexes(c_index);
		table_close(a_rel, RowExclusiveLock);
		table_close(c_rel, RowExclusiveLock);

		CommandCounterIncrement();
	}
	PG_RETURN_VOID();
}

/*
 * handler of Arrow_Fdw
 */
PG_FUNCTION_INFO_V1(pgstrom_arrow_fdw_handler);
PUBLIC_FUNCTION(Datum)
pgstrom_arrow_fdw_handler(PG_FUNCTION_ARGS)
{
	PG_RETURN_POINTER(&pgstrom_arrow_fdw_routine);
}

/*
 * validator of Arrow_Fdw
 */
PG_FUNCTION_INFO_V1(pgstrom_arrow_fdw_validator);
PUBLIC_FUNCTION(Datum)
pgstrom_arrow_fdw_validator(PG_FUNCTION_ARGS)
{
	List   *options = untransformRelOptions(PG_GETARG_DATUM(0));
	Oid		catalog = PG_GETARG_OID(1);

	if (catalog == ForeignTableRelationId)
	{
		List	   *filesList;
		List	   *virtualColumnsList;
		ListCell   *lc;

		filesList = arrowFdwExtractFilesList(options,
											 &virtualColumnsList,
											 NULL, NULL, NULL);
		foreach (lc, filesList)
		{
			const char *fname = strVal(lfirst(lc));
			ArrowFileInfo af_info;

			readArrowFile(fname, &af_info, true);
		}
	}
	else if (catalog == AttributeRelationId)
	{
		bool		meet_field = false;
		bool		meet_virtual = false;
		bool		meet_virtual_metadata = false;
		bool		meet_virtual_metadata_split = false;
		ListCell   *lc;

		foreach (lc, options)
		{
			DefElem	   *defel = lfirst(lc);

			if (strcmp(defel->defname, "field") == 0)
			{
				if (strlen(strVal(defel->arg)) >= NAMEDATALEN-1)
					elog(ERROR, "arrow_fdw: column option '%s' is too long [%s]",
						 defel->defname, strVal(defel->arg));
				meet_field = true;
			}
			else if (strcmp(defel->defname, "virtual") == 0)
				meet_virtual = true;
			else if (strcmp(defel->defname, "virtual_metadata") == 0)
				meet_virtual_metadata = true;
			else if (strcmp(defel->defname, "virtual_metadata_split") == 0)
				meet_virtual_metadata_split = true;
			else if (strcmp(defel->defname, "on_missing_field") == 0)
			{
				const char *sval = strVal(defel->arg);

				if (strcmp(sval, "null") != 0 &&
					strcmp(sval, "error") != 0)
					elog(ERROR, "arrow_fdw: column option 'on_missing_field' must be either 'error' or 'null', but '%s' was supplied", sval);
			}
			else
			{
				elog(ERROR, "arrow_fdw: column option '%s' is unknown",
					 defel->defname);
			}
		}
		if ((meet_field ? 1 : 0) +
			(meet_virtual ? 1 : 0) +
			(meet_virtual_metadata ? 1 : 0) +
			(meet_virtual_metadata_split ? 1 : 0) > 1)
			elog(ERROR, "arrow_fdw: column option 'field', 'virtual', 'virtual_metadata' and 'virtual_metadata_split' are mutually exclusive");
	}
	else if (options != NIL)
	{
		const char *label;

		switch (catalog)
		{
			case ForeignDataWrapperRelationId:
				label = "FOREIGN DATA WRAPPER";
				break;
			case ForeignServerRelationId:
				label = "SERVER";
				break;
			case UserMappingRelationId:
				label = "USER MAPPING";
				break;
			default:
				label = "????";
				break;
		}
		elog(ERROR, "Arrow_Fdw does not support any options for %s", label);
	}
	PG_RETURN_VOID();
}

/*
 * pgstrom_arrow_fdw_precheck_schema
 */
PG_FUNCTION_INFO_V1(pgstrom_arrow_fdw_precheck_schema);
PUBLIC_FUNCTION(Datum)
pgstrom_arrow_fdw_precheck_schema(PG_FUNCTION_ARGS)
{
	EventTriggerData *trigdata;
	Relation	frel = NULL;
	ListCell   *lc1, *lc2;
	bool		check_schema_compatibility = false;

	if (!CALLED_AS_EVENT_TRIGGER(fcinfo))
		elog(ERROR, "%s: must be called as EventTrigger", __FUNCTION__);
	trigdata = (EventTriggerData *) fcinfo->context;
	if (strcmp(trigdata->event, "ddl_command_end") != 0)
		elog(ERROR, "%s: must be called on ddl_command_end event", __FUNCTION__);

	if (strcmp(GetCommandTagName(trigdata->tag),
			   "CREATE FOREIGN TABLE") == 0)
	{
		CreateStmt *stmt = (CreateStmt *)trigdata->parsetree;

		frel = relation_openrv_extended(stmt->relation, NoLock, true);
		if (frel && RelationIsArrowFdw(frel))
			check_schema_compatibility = true;
	}
	else if (strcmp(GetCommandTagName(trigdata->tag),
					"ALTER FOREIGN TABLE") == 0 &&
			 IsA(trigdata->parsetree, AlterTableStmt))
	{
		AlterTableStmt *stmt = (AlterTableStmt *)trigdata->parsetree;

		frel = relation_openrv_extended(stmt->relation, NoLock, true);
		if (frel && RelationIsArrowFdw(frel))
		{
			foreach (lc1, stmt->cmds)
			{
				AlterTableCmd  *cmd = lfirst(lc1);

				if (cmd->subtype == AT_AddColumn ||
					cmd->subtype == AT_DropColumn ||
					cmd->subtype == AT_AlterColumnType)
				{
					check_schema_compatibility = true;
					break;
				}
			}
		}
	}

	if (check_schema_compatibility)
	{
		ForeignTable *ft = GetForeignTable(RelationGetRelid(frel));
		List	   *filesList;
		List	   *sourceFields;
		List	   *virtualColumnsList;
		char		on_missing_fields;

		filesList = arrowFdwExtractFilesList(ft->options,
											 &virtualColumnsList,
											 NULL, NULL,
											 &on_missing_fields);
		sourceFields = arrowFdwExtractSourceFields(frel, on_missing_fields);
		forboth (lc1, filesList,
				 lc2, virtualColumnsList)
		{
			const char *fname = strVal(lfirst(lc1));
			List	   *virtual_columns = lfirst(lc2);

			(void)BuildArrowFileState(frel, fname,
									  sourceFields,
									  virtual_columns,
									  -1,
									  NULL);
		}
	}
	if (frel)
		relation_close(frel, NoLock);
	PG_RETURN_NULL();
}

/*
 * pgstrom_check_pattern
 */
PG_FUNCTION_INFO_V1(pgstrom_arrow_fdw_check_pattern);
PUBLIC_FUNCTION(Datum)
pgstrom_arrow_fdw_check_pattern(PG_FUNCTION_ARGS)
{
	text	   *t = PG_GETARG_TEXT_P(0);
	text	   *p = PG_GETARG_TEXT_P(1);
	List	   *attrKinds = NIL;
	List	   *attrKeys = NIL;
	List	   *attrValues = NIL;
	ListCell   *lc1, *lc2, *lc3;
	bool		retval;
	StringInfoData buf;

	retval = pathNameMatchByPattern(text_to_cstring(t),
									text_to_cstring(p),
									&attrKinds,
									&attrKeys,
									&attrValues);
	initStringInfo(&buf);
	if (retval)
	{
		bool	need_comma = false;

		appendStringInfo(&buf, "true");
		forthree (lc1, attrKinds,
				  lc2, attrKeys,
				  lc3, attrValues)
		{
			if (!need_comma)
				appendStringInfo(&buf, " {");
			else
				appendStringInfo(&buf, ", ");
			appendStringInfo(&buf, "%c[%s]=[%s]",
							 (int)lfirst_int(lc1),
							 (char *)lfirst(lc2),
							 (char *)lfirst(lc3));
			need_comma = true;
		}
		if (need_comma)
			appendStringInfo(&buf, "}");
	}
	else
	{
		appendStringInfo(&buf, "false");
	}
	PG_RETURN_TEXT_P(cstring_to_text(buf.data));
}

/*
 * pgstrom_arrow_fdw_metadata_info
 */
typedef struct arrowFdwMetadataInfo
{
	dlist_node	chain;
	Oid			frelid;
	text	   *filename;
	text	   *field;
	text	   *key;
	text	   *value;
} arrowFdwMetadataInfo;

static void
__build_arrow_fdw_metadata_info(dlist_head *md_info_dlist,
								Oid frelid, const char *filename,
								arrowMetadataFieldCache *fcache,
								const char *prefix,
								arrowMetadataKeyValueCache *custom_metadata)
{
	arrowFdwMetadataInfo *md_info;
	arrowMetadataKeyValueCache *mc_kv;

	for (mc_kv = custom_metadata; mc_kv != NULL; mc_kv = mc_kv->next)
	{
		md_info = palloc0(sizeof(arrowFdwMetadataInfo));
		md_info->frelid = frelid;
		md_info->filename = cstring_to_text(filename);
		if (fcache)
		{
			char   *s = psprintf("XXXX%s%s", prefix, fcache->attname);
			md_info->field = (text *)s;
			SET_VARSIZE(md_info->field, strlen(s));
		}
		md_info->key = cstring_to_text(mc_kv->key);
		md_info->value = cstring_to_text(mc_kv->value);
		dlist_push_tail(md_info_dlist, &md_info->chain);
	}

	if (fcache)
	{
		dlist_iter	iter;
		char	   *__prefix = NULL;

		dlist_foreach (iter, &fcache->children)
		{
			arrowMetadataFieldCache *__fcache =
				dlist_container(arrowMetadataFieldCache, chain, iter.cur);
			if (!__prefix)
			{
				__prefix = alloca(strlen(prefix) +
								  strlen(fcache->attname) + 10);
				sprintf(__prefix, "%s%s.", prefix, fcache->attname);
			}
			__build_arrow_fdw_metadata_info(md_info_dlist,
											frelid, filename,
											__fcache,
											__prefix,
											fcache->custom_metadata);
		}
	}
}

static dlist_head *
__setup_arrow_fdw_metadata_info(Oid frelid)
{
	ForeignTable   *ft = GetForeignTable(frelid);
	List		   *filesList = arrowFdwExtractFilesList(ft->options, NULL, NULL, NULL, NULL);
	ListCell	   *lc;
	dlist_head	   *md_info_dlist = palloc(sizeof(dlist_head));

	dlist_init(md_info_dlist);
	foreach (lc, filesList)
	{
		const char *filename = strVal(lfirst(lc));
		struct stat	stat_buf;
		dlist_iter	iter;
		arrowMetadataCacheBlock *mc_block;

		if (stat(filename, &stat_buf) != 0)
		{
			if (errno == ENOENT)
				continue;	/* file might be removed concurrently */
			elog(ERROR, "failed on stat('%s'): %m", filename);
		}
		LWLockAcquire(&arrow_metadata_cache->mutex, LW_SHARED);
		mc_block = lookupArrowMetadataCache(&stat_buf, false);
		/* if not built yet, construct a metadata cache entry */
		if (!mc_block)
		{
			ArrowFileInfo	af_info;
			ArrowFileState	af_state;

			LWLockRelease(&arrow_metadata_cache->mutex);

			memset(&af_state, 0, sizeof(af_state));
			af_state.filename = filename;
			memcpy(&af_state.stat_buf, &stat_buf, sizeof(struct stat));

			if (!__setupArrowFileStateByFile(&af_state,
											 filename,
											 &af_info,
											 NULL))
				elog(ERROR, "unable to read the arrow file '%s'", filename);
			LWLockAcquire(&arrow_metadata_cache->mutex, LW_EXCLUSIVE);
			mc_block = lookupArrowMetadataCache(&af_state.stat_buf, true);
			if (!mc_block)
			{
				mc_block = __buildArrowMetadataCacheNoLock(&af_state, &af_info);
				if (!mc_block)
					elog(ERROR, "unable to build arrow metadata cache, consider to expand 'arrow_fdw.metadata_cache_size'");
			}
		}
		/* copy the metadata info */
		__build_arrow_fdw_metadata_info(md_info_dlist,
										frelid,
										filename,
										NULL, "",
										mc_block->custom_metadata);
		dlist_foreach (iter, &mc_block->mcache_head.fields)
		{
			arrowMetadataFieldCache *fcache
				= dlist_container(arrowMetadataFieldCache,
								  chain, iter.cur);
			__build_arrow_fdw_metadata_info(md_info_dlist,
											frelid,
											filename,
											fcache, "",
											fcache->custom_metadata);
		}
		LWLockRelease(&arrow_metadata_cache->mutex);
	}
	return md_info_dlist;
}

PG_FUNCTION_INFO_V1(pgstrom_arrow_fdw_metadata_info);
PUBLIC_FUNCTION(Datum)
pgstrom_arrow_fdw_metadata_info(PG_FUNCTION_ARGS)
{
	FuncCallContext *fncxt;
	arrowFdwMetadataInfo *md_info;
	Datum		values[5];
	bool		isnull[5];
	HeapTuple	tuple;
	dlist_head *md_info_dlist;

	if (SRF_IS_FIRSTCALL())
	{
		Oid				frelid = PG_GETARG_OID(0);
		TupleDesc		tupdesc;
		MemoryContext	oldcxt;

		fncxt = SRF_FIRSTCALL_INIT();
		oldcxt = MemoryContextSwitchTo(fncxt->multi_call_memory_ctx);

		tupdesc = CreateTemplateTupleDesc(5);
		TupleDescInitEntry(tupdesc, (AttrNumber) 1, "relid",
						   OIDOID, -1, 0);
		TupleDescInitEntry(tupdesc, (AttrNumber) 2, "filename",
						   TEXTOID, -1, 0);
		TupleDescInitEntry(tupdesc, (AttrNumber) 3, "field",
						   TEXTOID, -1, 0);
		TupleDescInitEntry(tupdesc, (AttrNumber) 4, "key",
						   TEXTOID, -1, 0);
		TupleDescInitEntry(tupdesc, (AttrNumber) 5, "value",
						   TEXTOID, -1, 0);
		fncxt->tuple_desc = BlessTupleDesc(tupdesc);

		fncxt->user_fctx = __setup_arrow_fdw_metadata_info(frelid);

		MemoryContextSwitchTo(oldcxt);
	}
	fncxt = SRF_PERCALL_SETUP();
	md_info_dlist = fncxt->user_fctx;
	if (dlist_is_empty(md_info_dlist))
		SRF_RETURN_DONE(fncxt);
	md_info = dlist_container(arrowFdwMetadataInfo, chain,
							  dlist_pop_head_node(md_info_dlist));

	memset(isnull, 0, sizeof(isnull));
	values[0] = ObjectIdGetDatum(md_info->frelid);
	values[1] = PointerGetDatum(md_info->filename);
	if (md_info->field)
		values[2] = PointerGetDatum(md_info->field);
	else
		isnull[2] = true;
	values[3] = PointerGetDatum(md_info->key);
	values[4] = PointerGetDatum(md_info->value);
	tuple = heap_form_tuple(fncxt->tuple_desc, values, isnull);
	SRF_RETURN_NEXT(fncxt, HeapTupleGetDatum(tuple));
}

PG_FUNCTION_INFO_V1(pgstrom_arrow_fdw_metadata_stats);
PUBLIC_FUNCTION(Datum)
pgstrom_arrow_fdw_metadata_stats(PG_FUNCTION_ARGS)
{
	StringInfoData buf;
	size_t		total_cache_sz;
	size_t		total_cache_alloc;
	size_t		total_cache_usage;
	uint32_t	num_total_blocks;
    uint32_t	num_active_blocks;
    uint32_t	num_file_entries;
    struct timeval tm_last_allocate;
    struct timeval tm_last_reclaimed;
	struct tm *tm;

	/* fetch statistics */
	total_cache_sz = TYPEALIGN(ARROW_METADATA_BLOCKSZ,
							   (size_t)arrow_metadata_cache_size_kb << 10);
	num_total_blocks = total_cache_sz / ARROW_METADATA_BLOCKSZ;
	LWLockAcquire(&arrow_metadata_cache->mutex, LW_SHARED);
	total_cache_usage = arrow_metadata_cache->total_cache_usage;
	num_active_blocks = arrow_metadata_cache->num_active_blocks;
	num_file_entries  = arrow_metadata_cache->num_file_entries;
	total_cache_alloc = ARROW_METADATA_BLOCKSZ * (size_t)num_active_blocks;
	memcpy(&tm_last_allocate,
		   &arrow_metadata_cache->tm_last_allocate,
		   sizeof(struct timeval));
	memcpy(&tm_last_reclaimed,
		   &arrow_metadata_cache->tm_last_reclaimed,
		   sizeof(struct timeval));
	LWLockRelease(&arrow_metadata_cache->mutex);
	/* build the result JSON */
	initStringInfo(&buf);
	appendStringInfoSpaces(&buf, VARHDRSZ);
	appendStringInfo(&buf,
					 "{ \"total_cache_sz\" : %lu"
					 ", \"total_cache_allocated\" : %lu"
					 ", \"total_cache_usage\" : %lu"
					 ", \"num_file_entries\" : %u"
					 ", \"cache_usage_efficiency\" : %.6f"
					 ", \"cache_num_blocks\" : %u"
					 ", \"cache_active_blocks\" : %u"
					 ", \"cache_free_blocks\" : %u"
					 ", \"cache_used_ratio\" : %.6f",
					 total_cache_sz,
					 total_cache_alloc,
					 total_cache_usage,
					 num_file_entries,
					 (total_cache_alloc > 0
					  ? (double)total_cache_usage / (double)total_cache_alloc
					  : 1.0),
					 num_total_blocks,
					 num_active_blocks,
					 num_total_blocks - num_active_blocks,
					 (num_total_blocks > 0
					  ? (double)num_active_blocks / (double)num_total_blocks
					  : 0.0));
	if (tm_last_allocate.tv_sec != 0)
	{
		tm = localtime(&tm_last_allocate.tv_sec);
		appendStringInfo(&buf,
						 " \"last_allocate_timestamp\""
						 " : \"%04d-%02d-%02d %02d:%02d:%02d.%03d\"",
						 tm->tm_year+1900,
						 tm->tm_mon+1,
						 tm->tm_mday,
						 tm->tm_hour,
						 tm->tm_min,
						 tm->tm_sec,
						 (int)(tm_last_allocate.tv_usec / 1000));
	}
	if (tm_last_reclaimed.tv_sec != 0)
	{
		tm = localtime(&tm_last_reclaimed.tv_sec);
		appendStringInfo(&buf,
						 " \"last_reclaim_timestamp\""
						 " : \"%04d-%02d-%02d %02d:%02d:%02d.%03d\"",
						 tm->tm_year+1900,
						 tm->tm_mon+1,
						 tm->tm_mday,
						 tm->tm_hour,
						 tm->tm_min,
						 tm->tm_sec,
						 (int)(tm_last_allocate.tv_usec / 1000));
	}
	appendStringInfo(&buf, " }");
	SET_VARSIZE(buf.data, buf.len);
	PG_RETURN_POINTER(buf.data);
}

/*
 * pgstrom_request_arrow_fdw
 */
static void
pgstrom_request_arrow_fdw(void)
{
	size_t	sz;

	if (shmem_request_next)
		shmem_request_next();
	sz = TYPEALIGN(ARROW_METADATA_BLOCKSZ,
				   (size_t)arrow_metadata_cache_size_kb << 10);
	RequestAddinShmemSpace(MAXALIGN(sizeof(arrowMetadataCacheHead)) + sz);
}

/*
 * pgstrom_startup_arrow_fdw
 */
static void
pgstrom_startup_arrow_fdw(void)
{
	char	   *buffer;
	bool		found;
	size_t		n, sz;

	if (shmem_startup_next)
		(*shmem_startup_next)();

	arrow_metadata_cache = ShmemInitStruct("arrowMetadataCache(head)",
										   MAXALIGN(sizeof(arrowMetadataCacheHead)),
										   &found);
	Assert(!found);

	memset(arrow_metadata_cache, 0, sizeof(arrowMetadataCacheHead));
	LWLockInitialize(&arrow_metadata_cache->mutex,
					 LWLockNewTrancheId("arrowMetadataCache"));
	SpinLockInit(&arrow_metadata_cache->lru_lock);
	dlist_init(&arrow_metadata_cache->lru_list);
	dlist_init(&arrow_metadata_cache->free_blocks);
	for (int i=0; i < ARROW_METADATA_HASH_NSLOTS; i++)
		dlist_init(&arrow_metadata_cache->hash_slots[i]);
	/* arrowMetadataCacheBlock allocation  */
	sz = TYPEALIGN(ARROW_METADATA_BLOCKSZ,
				   (size_t)arrow_metadata_cache_size_kb << 10);
	n = sz / ARROW_METADATA_BLOCKSZ;
	buffer = ShmemInitStruct("arrowMetadataCache(body)", sz, &found);
	Assert(!found);
	for (int i=0; i < n; i++)
	{
		arrowMetadataCacheBlock *mc_block = (arrowMetadataCacheBlock *)buffer;

		memset(mc_block, 0, offsetof(arrowMetadataCacheBlock, mcache_head));
		dlist_push_tail(&arrow_metadata_cache->free_blocks, &mc_block->chain);
		buffer += ARROW_METADATA_BLOCKSZ;
	}
}

/*
 * pgstrom_init_arrow_fdw
 */
void
pgstrom_init_arrow_fdw(void)
{
	FdwRoutine *r = &pgstrom_arrow_fdw_routine;

	memset(r, 0, sizeof(FdwRoutine));
	NodeSetTag(r, T_FdwRoutine);
	/* SCAN support */
	r->GetForeignRelSize			= ArrowGetForeignRelSize;
	r->GetForeignPaths				= ArrowGetForeignPaths;
	r->GetForeignPlan				= ArrowGetForeignPlan;
	r->BeginForeignScan				= ArrowBeginForeignScan;
	r->IterateForeignScan			= ArrowIterateForeignScan;
	r->ReScanForeignScan			= ArrowReScanForeignScan;
	r->EndForeignScan				= ArrowEndForeignScan;
	/* EXPLAIN support */
	r->ExplainForeignScan			= ArrowExplainForeignScan;
	/* ANALYZE support */
	r->AnalyzeForeignTable			= ArrowAnalyzeForeignTable;
	/* CPU Parallel support */
	r->IsForeignScanParallelSafe	= ArrowIsForeignScanParallelSafe;
	r->EstimateDSMForeignScan		= ArrowEstimateDSMForeignScan;
	r->InitializeDSMForeignScan		= ArrowInitializeDSMForeignScan;
	//r->ReInitializeDSMForeignScan	= ArrowReInitializeDSMForeignScan;
	r->InitializeWorkerForeignScan	= ArrowInitializeWorkerForeignScan;
	r->ShutdownForeignScan			= ArrowShutdownForeignScan;
	/* IMPORT FOREIGN SCHEMA support */
	r->ImportForeignSchema			= ArrowImportForeignSchema;

	/*
	 * Turn on/off arrow_fdw
	 */
	DefineCustomBoolVariable("arrow_fdw.enabled",
							 "Enables the planner's use of Arrow_Fdw",
							 NULL,
							 &arrow_fdw_enabled,
							 true,
							 PGC_USERSET,
							 GUC_NOT_IN_SAMPLE,
							 NULL, NULL, NULL);
	/*
	 * Turn on/off min/max statistics hint
	 */
	DefineCustomBoolVariable("arrow_fdw.stats_hint_enabled",
							 "Enables min/max statistics hint, if any",
							 NULL,
							 &arrow_fdw_stats_hint_enabled,
							 true,
							 PGC_USERSET,
                             GUC_NOT_IN_SAMPLE,
                             NULL, NULL, NULL);
	/*
	 * Configurations for arrow_fdw metadata cache
	 */
	DefineCustomIntVariable("arrow_fdw.metadata_cache_size",
							"size of shared metadata cache for arrow files",
							NULL,
							&arrow_metadata_cache_size_kb,
							512 * 1024,		/* 512MB */
							32 * 1024,		/* 32MB */
							INT_MAX,
							PGC_POSTMASTER,
							GUC_NOT_IN_SAMPLE | GUC_UNIT_KB,
							NULL, NULL, NULL);
	/*
	 * Threshold of using threadpool for parquet read
	 */
	DefineCustomIntVariable("arrow_fdw.parquet_parallel_read_threshold",
							"minimum number of loaded columns using thread-pool for Parquet read",
							NULL,
							&parquet_parallel_read_threshold,
							8,		/* default 8 columns */
							-1,		/* -1 : disabled, 0 : always */
							INT_MAX,
							PGC_USERSET,
							GUC_NOT_IN_SAMPLE,
							NULL, NULL, NULL);
	/*
	 * Default behavior of Parquet cache usage
	 */
	DefineCustomBoolVariable("arrow_fdw.parquet_cache_enabled",
							 "Enables the planner's use of Parquet cache",
							 NULL,
							 &default_parquet_cache_enabled,
							 true,
							 PGC_USERSET,
							 GUC_NOT_IN_SAMPLE,
							 NULL, NULL, NULL);
	/* shared memory size */
	shmem_request_next = shmem_request_hook;
	shmem_request_hook = pgstrom_request_arrow_fdw;
	shmem_startup_next = shmem_startup_hook;
	shmem_startup_hook = pgstrom_startup_arrow_fdw;
}




