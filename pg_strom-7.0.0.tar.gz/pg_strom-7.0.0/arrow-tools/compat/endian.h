/*
 * endian.h - the glibc names on macOS (arrow-tools only; the Makefile adds this
 * directory to the include path on Darwin). Also supplies loff_t and basename().
 */
#ifndef ARROW_TOOLS_COMPAT_ENDIAN_H
#define ARROW_TOOLS_COMPAT_ENDIAN_H
#include <sys/types.h>
#include <libgen.h>
#include <libkern/OSByteOrder.h>

#define htobe16(x) OSSwapHostToBigInt16(x)
#define htole16(x) OSSwapHostToLittleInt16(x)
#define be16toh(x) OSSwapBigToHostInt16(x)
#define le16toh(x) OSSwapLittleToHostInt16(x)
#define htobe32(x) OSSwapHostToBigInt32(x)
#define htole32(x) OSSwapHostToLittleInt32(x)
#define be32toh(x) OSSwapBigToHostInt32(x)
#define le32toh(x) OSSwapLittleToHostInt32(x)
#define htobe64(x) OSSwapHostToBigInt64(x)
#define htole64(x) OSSwapHostToLittleInt64(x)
#define be64toh(x) OSSwapBigToHostInt64(x)
#define le64toh(x) OSSwapLittleToHostInt64(x)

typedef off_t loff_t;
#endif	/* ARROW_TOOLS_COMPAT_ENDIAN_H */
